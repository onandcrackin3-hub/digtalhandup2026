// simple test script

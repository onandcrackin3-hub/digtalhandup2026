const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

const regex = /\{lightboxIndex !== null && userPhotos\[lightboxIndex\] && \([\s\S]*?<\/div>\n\s*<\/div>\n\s*\)\}/g;

let count = 0;
code = code.replace(regex, (match, offset) => {
  count++;
  if (count === 1) {
    return match; // Keep the first one which should be in renderPhotoGallery
  } else {
    return ''; // Remove the others
  }
});

fs.writeFileSync('src/App.tsx', code);
console.log('Removed', count - 1, 'extra occurrences');

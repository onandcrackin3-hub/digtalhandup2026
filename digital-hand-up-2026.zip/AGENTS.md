# Project: Digital Hand Up

## Brand Guidelines
- **Official Name**: Digital Hand Up
- **Motto/Tagline**: Hand Up
- **Visual Identity**:
  - **Logo**: Circular emblem.
  - **Outer Ring**: Dark Green (#14532d) with Yellow/Gold (#fbbf24) text.
  - **Top Text**: "HAND UP" (Yellow, bold, uppercase).
  - **Bottom Text**: "DIGITAL HAND UP" (Yellow, bold, uppercase).
  - **Center Graphic**: A handshake between two people of different skin tones over a light brown tent against a blue sky.
- **Brand Colors**: 
  - Green (Primary): #14532d (brand-green)
  - Yellow (Accent): #fbbf24 (brand-yellow)
  - Sky Blue (Background accent): #7dd3fc

## Design Principles
- Focus on unity, direct action, and community support.
- Avoid using "OKC" branding only unless referring to the specific local chapter, but the platform name is "Digital Hand Up".
- Always use the "Hand Up" motto in conjunction with the project name.

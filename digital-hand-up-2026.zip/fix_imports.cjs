const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

const lines = code.split('\n');
lines.splice(24, 1); // line 25 is index 24

fs.writeFileSync('src/App.tsx', lines.join('\n'));

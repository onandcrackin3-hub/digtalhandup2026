const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

const regex = /<div className="grid grid-cols-3 sm:grid-cols-4 gap-2 mb-2">\s*\{previewUrls\.map\(\(url, i\) => \(\s*<div key=\{i\} className="relative aspect-square rounded-lg overflow-hidden border border-neutral-200">\s*<img src=\{url\} alt="Preview" className="w-full h-full object-cover" \/>\s*<button onClick=\{\(\) => setPhotoFiles\(prev => prev\.filter\(\(_, idx\) => idx !== i\)\)\} className="absolute top-1 right-1 bg-black\/50 text-white rounded-full p-1 hover:bg-black\/70">\s*<X className="w-3 h-3" \/>\s*<\/button>\s*<\/div>\s*\)\)\}\s*<\/div>\s*<textarea/g;

let count = 0;
code = code.replace(regex, (match, offset) => {
  count++;
  if (count === 1) {
    return match; // Keep the first one which is for the photo gallery
  } else {
    return '<textarea';
  }
});

fs.writeFileSync('src/App.tsx', code);
console.log('Replaced', count, 'occurrences');

import { initializeApp } from 'firebase/app';
import { getFirestore, collection, query, orderBy, getDocs } from 'firebase/firestore';
import fs from 'fs';

const config = JSON.parse(fs.readFileSync('./firebase-applet-config.json', 'utf8'));
const app = initializeApp(config);
const db = getFirestore(app, config.firestoreDatabaseId);

async function test() {
  try {
    const q1 = query(collection(db, 'requests'), orderBy('timestamp', 'desc'));
    const d1 = await getDocs(q1);
    console.log("Success requests", d1.size);

    const q2 = query(collection(db, 'community_posts'), orderBy('timestamp', 'desc'));
    const d2 = await getDocs(q2);
    console.log("Success community_posts", d2.size);
  } catch(e) {
    console.error("SDK Error:", e.code, e.message);
  }
  process.exit(0);
}
test();

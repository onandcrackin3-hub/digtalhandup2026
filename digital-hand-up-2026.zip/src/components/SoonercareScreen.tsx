import React from 'react';
import { motion } from 'motion/react';
import { ChevronLeft, Activity } from 'lucide-react';
import SoonercareAssistant from './SoonercareAssistant';

interface SoonercareScreenProps {
  onBack: () => void;
  user: any;
  profile: any;
}

export default function SoonercareScreen({ onBack, user, profile }: SoonercareScreenProps) {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <button 
          onClick={onBack}
          className="bg-white hover:bg-neutral-50 p-2 rounded-full border border-neutral-200 transition-colors shadow-sm"
        >
          <ChevronLeft className="w-5 h-5 text-neutral-600" />
        </button>
        <div>
          <h2 className="text-2xl font-black text-brand-green italic uppercase tracking-tighter">Adults SoonerCare</h2>
          <p className="text-[10px] font-black text-brand-yellow uppercase tracking-widest bg-brand-green px-2 py-0.5 rounded-full inline-block">Medicaid Expansion</p>
        </div>
      </div>

      <SoonercareAssistant user={user} profile={profile} />
    </div>
  );
}

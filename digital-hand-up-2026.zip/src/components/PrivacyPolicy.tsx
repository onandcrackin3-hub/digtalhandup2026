import React from 'react';
import { ChevronLeft, Shield, Lock, Eye, Globe, CreditCard } from 'lucide-react';
import { motion } from 'motion/react';

interface PrivacyPolicyProps {
  onBack: () => void;
}

export default function PrivacyPolicy({ onBack }: PrivacyPolicyProps) {
  return (
    <div className="min-h-screen bg-neutral-50 font-sans text-neutral-900 pb-10">
      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-neutral-200 px-4 py-4 flex items-center gap-4">
        <button 
          onClick={onBack}
          className="p-2 hover:bg-neutral-100 rounded-full transition-colors"
        >
          <ChevronLeft className="w-6 h-6 text-brand-green" />
        </button>
        <h1 className="text-xl font-black text-brand-green tracking-tighter uppercase italic">Privacy Policy</h1>
      </header>

      <main className="max-w-2xl mx-auto p-6 space-y-8">
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-4"
        >
          <div className="flex items-center gap-3 text-brand-green mb-2">
            <Shield className="w-8 h-8" />
            <h2 className="text-2xl font-black tracking-tighter uppercase italic underline decoration-brand-yellow decoration-4 underline-offset-4">Your Privacy Matters</h2>
          </div>
          <p className="text-neutral-600 leading-relaxed font-medium">
            Digital Hand Up is built on trust. This policy explains how we collect, use, and protect your data as we work together to bridge our community.
          </p>
          <p className="text-xs text-neutral-400 font-bold uppercase tracking-widest">Effective Date: May 14, 2026</p>
        </motion.div>

        <section className="bg-white p-8 rounded-[2rem] shadow-sm border border-neutral-100 space-y-6">
          <div className="flex items-start gap-4">
            <div className="bg-emerald-50 p-3 rounded-2xl">
              <Globe className="w-6 h-6 text-brand-green" />
            </div>
            <div className="space-y-2">
              <h3 className="font-black text-lg text-brand-green uppercase tracking-tighter">Location Data</h3>
              <p className="text-sm text-neutral-600 leading-relaxed">
                As part of our pilot program, we use **ACCESS_FINE_LOCATION** permissions to help you find local resources (shelters, pantries) nearby. Your specific location is used locally on your device to display map markers and is not stored permanently on our servers unless you explicitly post a resource at that location.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-4">
            <div className="bg-brand-yellow/10 p-3 rounded-2xl">
              <CreditCard className="w-6 h-6 text-brand-green" />
            </div>
            <div className="space-y-2">
              <h3 className="font-black text-lg text-brand-green uppercase tracking-tighter">Financial Transactions & Sponsorships</h3>
              <p className="text-sm text-neutral-600 leading-relaxed">
                We facilitate direct community sponsorships. When you contribute, third-party payment services and processors collect your payment configurations. Digital Hand Up does not store your credit card or sensitive financial wallet details; we only receive confirmation of the transaction to update community impact metrics.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-4">
            <div className="bg-neutral-900/5 p-3 rounded-2xl">
              <Lock className="w-6 h-6 text-neutral-600" />
            </div>
            <div className="space-y-2">
              <h3 className="font-black text-lg text-brand-green uppercase tracking-tighter">Anonymized Interactions</h3>
              <p className="text-sm text-neutral-600 leading-relaxed">
                Our **AI Gateway** logs interactions to improve the platform. However, these logs are anonymized to remove personally identifiable information, remaining compliant with standard privacy practices for community-driven applications.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-4">
            <div className="bg-blue-50 p-3 rounded-2xl">
              <Eye className="w-6 h-6 text-blue-600" />
            </div>
            <div className="space-y-2">
              <h3 className="font-black text-lg text-brand-green uppercase tracking-tighter">Information We Collect</h3>
              <ul className="text-sm text-neutral-600 space-y-2 list-disc ml-4">
                <li>**Account Info:** Your name, email, and photo from Google Sign-In.</li>
                <li>**Profile Data:** Story/bio, goals, and neighborhood info you choose to shared.</li>
                <li>**Support Requests:** Items you need and their general location for fulfillment.</li>
              </ul>
            </div>
          </div>
        </section>

        <section className="bg-brand-green text-white p-8 rounded-[2rem] shadow-xl space-y-4">
          <h3 className="font-black text-xl italic uppercase tracking-tighter text-brand-yellow">Contact Us</h3>
          <p className="text-sm opacity-90 leading-relaxed font-medium">
            If you have any questions about this Privacy Policy or how we handle your data on the Galaxy Tab S9 Ultra or other devices, please contact us at:
          </p>
          <div className="bg-white/10 p-4 rounded-xl border border-white/20">
            <p className="font-black text-brand-yellow">support@handup.community</p>
            <p className="text-xs font-bold opacity-60 mt-1 uppercase tracking-widest">Oklahoma City, OK</p>
          </div>
        </section>

        <div className="text-center pt-4">
          <button 
            onClick={onBack}
            className="text-brand-green font-black uppercase text-xs tracking-[0.2em] hover:underline"
          >
            Back to Application
          </button>
        </div>
      </main>
    </div>
  );
}

import React, { useState } from 'react';
import { 
  Bus, 
  MapPin, 
  PhoneCall, 
  ArrowRight, 
  AlertCircle, 
  Sparkles, 
  CheckCircle2, 
  Compass,
  Lock,
  Loader2,
  Calendar,
  Building2,
  Info,
  Route,
  ArrowRightLeft,
  BookOpen,
  CalendarDays,
  CheckSquare
} from 'lucide-react';
import { db, handleFirestoreError, OperationType } from '../lib/backend';
import { collection, addDoc, serverTimestamp } from '../lib/backend';
import { type User as AuthUser } from '../lib/backend';
import { cn } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';

interface BusPassAssistantProps {
  user: AuthUser | null;
  profile: any;
  onHelpSubmitted?: () => void;
}

export default function BusPassAssistant({ user, profile, onHelpSubmitted }: BusPassAssistantProps) {
  const [activeStep, setActiveStep] = useState<number>(1);
  const [requestSubmitted, setRequestSubmitted] = useState<boolean>(false);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Form states for bus pass advocate dispatch
  const [contactName, setContactName] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [reason, setReason] = useState('Medical Appointment / Pharmacy');
  const [contactMethod, setContactMethod] = useState<'phone' | 'text' | 'shelter'>('phone');
  const [preferredShelter, setPreferredShelter] = useState('Homeless Alliance Day Center (1220 W 4th St)');

  // Step checklist memory (self-guided progress)
  const [stepsCompleted, setStepsCompleted] = useState<Record<number, boolean>>({
    1: false,
    2: false,
    3: false,
    4: false
  });

  const toggleStepComplete = (stepId: number) => {
    setStepsCompleted(prev => ({ ...prev, [stepId]: !prev[stepId] }));
  };

  const stepsDetails = [
    {
      id: 1,
      title: "Know Your Free or Discounted Fare Eligibility",
      badge: "Step 1: Fare Types",
      short: "Confirm which programs offer you free or half-priced EMBARK passes.",
      content: (
        <div className="space-y-4">
          <p className="text-xs text-neutral-600 leading-relaxed font-medium">
            Oklahoma City's public transit system, <strong>EMBARK</strong>, offers several programs that make riding either 100% free or extremely affordable (Half Flight fares) for folks facing structural barriers:
          </p>

          <div className="space-y-2">
            <div className="p-3 bg-white border border-neutral-150 rounded-xl space-y-1.5 shadow-sm">
              <span className="bg-emerald-100 text-emerald-800 text-[8px] font-black uppercase px-2 py-0.5 rounded">100% Free Rides</span>
              <h5 className="text-xs font-black uppercase text-neutral-900 flex items-center gap-1.5">
                Children & Youths (Ages 18 and Under)
              </h5>
              <p className="text-[10px] text-neutral-500 font-medium leading-relaxed">
                Under EMBARK's youth access initiative, children and youths up to 18 years old can ride **all standard bus services for 100% free**. No fare ticket is required! You might just need to show a student ID or age documentation if asked.
              </p>
            </div>

            <div className="p-3 bg-white border border-neutral-150 rounded-xl space-y-1.5 shadow-sm">
              <span className="bg-amber-100 text-amber-800 text-[8px] font-black uppercase px-2 py-0.5 rounded">50% Half-Fare Discounts</span>
              <h5 className="text-xs font-black uppercase text-neutral-900 flex items-center gap-1.5">
                Low-Income, Seniors, and Individuals with Disabilities
              </h5>
              <p className="text-[10px] text-neutral-500 font-medium leading-relaxed">
                Eligible passengers can purchase Single Trip tickets for <strong>$0.75</strong> (instead of $3.00 for normal daily fare passes), or a Monthly Pass for <strong>$25.00</strong> (instead of $50.00). This applies to:
              </p>
              <ul className="text-[9px] text-neutral-600 font-semibold pl-4 list-disc space-y-1">
                <li>Seniors aged 60 or older (show Medicare card or state ID)</li>
                <li>Individuals with physical, cognitive, or psychiatric disabilities</li>
                <li>Medicare cardholders</li>
              </ul>
            </div>

            <div className="p-3 bg-emerald-50/50 border border-brand-green/10 rounded-xl text-xs text-neutral-700 font-medium leading-relaxed">
              ⭐ <strong>Universal Free Access:</strong> If you are transient or currently unhoused, you do not need to pay! Case managers at local day shelters hold special allocations of free bus tokens or continuous passes so you can travel to critical appointments.
            </div>
          </div>
        </div>
      )
    },
    {
      id: 2,
      title: "Where to Get Free Bus Passes in OKC",
      badge: "Step 2: Pickup Locations",
      short: "A directory of daytime shelters and services distributing free ride tickets.",
      content: (
        <div className="space-y-4">
          <p className="text-xs text-neutral-600 leading-relaxed font-semibold">
            The following physical locations in Oklahoma City distribute daily EMBARK transit passes to clients of their services. Be sure to check in during operational intake hours to request support:
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Homeless Alliance */}
            <div className="p-4 rounded-xl bg-white border border-neutral-100 shadow-sm space-y-1.5">
              <span className="bg-emerald-100 text-emerald-800 text-[8px] font-black uppercase px-2 py-0.5 rounded">Daily Distribution</span>
              <h5 className="text-xs font-black uppercase text-neutral-900">Homeless Alliance Day Shelter</h5>
              <p className="text-[10px] text-neutral-500 font-medium leading-relaxed">
                Provides free EMBARK daily bus passes during check-in to clients who have verified doctor consultations, job interviews, housing searches, or court dates.
              </p>
              <div className="pt-1.5 border-t border-neutral-100 flex flex-col gap-0.5 text-[9px] text-neutral-500 font-semibold">
                <span className="flex items-center gap-1"><MapPin className="w-3 h-3 text-brand-green" /> 1220 W 4th St, OKC</span>
                <span className="flex items-center gap-1"><PhoneCall className="w-3 h-3 text-brand-green" /> (405) 415-8410</span>
              </div>
            </div>

            {/* City Rescue Mission */}
            <div className="p-4 rounded-xl bg-white border border-neutral-100 shadow-sm space-y-1.5">
              <span className="bg-blue-100 text-blue-800 text-[8px] font-black uppercase px-2 py-0.5 rounded">Active Participants</span>
              <h5 className="text-xs font-black uppercase text-neutral-900">City Rescue Mission</h5>
              <p className="text-[10px] text-neutral-500 font-medium leading-relaxed">
                Distributes free transport bus tickets to active participants of their program classes and clients actively coordinating with a workforce specialist to obtain job positions.
              </p>
              <div className="pt-1.5 border-t border-neutral-100 flex flex-col gap-0.5 text-[9px] text-neutral-500 font-semibold">
                <span className="flex items-center gap-1"><MapPin className="w-3 h-3 text-brand-green" /> 800 W California Ave, OKC</span>
                <span className="flex items-center gap-1"><PhoneCall className="w-3 h-3 text-brand-green" /> (405) 232-0631</span>
              </div>
            </div>

            {/* Salvation Army */}
            <div className="p-4 rounded-xl bg-white border border-neutral-100 shadow-sm space-y-1.5">
              <span className="bg-amber-100 text-amber-800 text-[8px] font-black uppercase px-2 py-0.5 rounded">Weekly Allocations</span>
              <h5 className="text-xs font-black uppercase text-neutral-900">Salvation Army Central Corps</h5>
              <p className="text-[10px] text-neutral-500 font-medium leading-relaxed">
                Offers emergency transportation assistance, including free monthly bus ride tokens and gas cards on a localized case-by-case basis.
              </p>
              <div className="pt-1.5 border-t border-neutral-100 flex flex-col gap-0.5 text-[9px] text-neutral-500 font-semibold">
                <span className="flex items-center gap-1"><MapPin className="w-3 h-3 text-brand-green" /> 1001 Penn Ave, OKC</span>
                <span className="flex items-center gap-1"><PhoneCall className="w-3 h-3 text-brand-green" /> (405) 246-1100</span>
              </div>
            </div>

            {/* EMBARK Transit Center */}
            <div className="p-4 rounded-xl bg-white border border-neutral-100 shadow-sm space-y-1.5">
              <span className="bg-purple-100 text-purple-800 text-[8px] font-black uppercase px-2 py-0.5 rounded">Half-Fare Applications</span>
              <h5 className="text-xs font-black uppercase text-neutral-900">EMBARK Downtown Transit Center</h5>
              <p className="text-[10px] text-neutral-500 font-medium leading-relaxed">
                Apply here for senior/low-income/disability cards. Bring your clinical diagnosis form or Medicare letter to get a permanent half-price ID.
              </p>
              <div className="pt-1.5 border-t border-neutral-100 flex flex-col gap-0.5 text-[9px] text-neutral-500 font-semibold">
                <span className="flex items-center gap-1"><MapPin className="w-3 h-3 text-brand-green" /> 420 NW 5th St, OKC</span>
                <span className="flex items-center gap-1"><PhoneCall className="w-3 h-3 text-brand-green" /> (405) 235-7433</span>
              </div>
            </div>
          </div>
        </div>
      )
    },
    {
      id: 3,
      title: "Key OKC EMBARK Bus Routes & Map Connections",
      badge: "Step 3: Bus Routing",
      short: "Browse important bus lines connecting shelters to clinics and employment centers.",
      content: (
        <div className="space-y-4">
          <p className="text-xs text-neutral-600 leading-relaxed font-semibold">
            Knowing which bus line to ride saves you time and stress. Here are the primary EMBARK routes serving OKC support clinics, shelters, and job centers:
          </p>

          <div className="space-y-2">
            {[
              {
                route: "Route 011 (NW 23rd & Villa)",
                desc: "Direct connection with standard frequency. Links Homeless Alliance (at W 4th), City Care shelters, and NorthCare clinics."
              },
              {
                route: "Route 022 (MLK Line)",
                desc: "Runs from primary downtown transit hub eastward. Accesses behavioral clinics, DHS offices, and jobs on the NE side."
              },
              {
                route: "Route 013 (S Western Ave)",
                desc: "Excellent north-south corridor line. Serves medical outreach points, drug stores, and West Capitol Hill communities."
              },
              {
                route: "Route 009 (West Reno Corridor)",
                desc: "Stops right outside major shelter and job spots, including the City Rescue Mission and local grocery access points."
              }
            ].map((item, idx) => (
              <div key={idx} className="p-3 bg-neutral-50 rounded-xl border border-neutral-150 flex items-start gap-2.5">
                <div className="w-6 h-6 shrink-0 bg-brand-green text-brand-yellow font-black text-[10px] rounded-lg flex items-center justify-center">
                  <Route className="w-3.5 h-3.5" />
                </div>
                <div>
                  <h6 className="text-[11px] font-black uppercase text-neutral-850 leading-none mb-1">{item.route}</h6>
                  <p className="text-[10px] text-neutral-500 font-semibold leading-relaxed">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="p-3 bg-amber-50 rounded-xl border border-amber-200/50 text-xs text-amber-900 flex items-center gap-2">
            <Info className="w-4 h-4 shrink-0" />
            <span><strong>Pro-Tip:</strong> EMBARK buses are fully climate-controlled and equipped with heavy-duty secure bike racks, so you can bring a bicycle along for longer commutes.</span>
          </div>
        </div>
      )
    },
    {
      id: 4,
      title: "How to File an Application and Request Passes",
      badge: "Step 4: Request Form",
      short: "Understand the proper documentation steps or request digital dispatch assistance.",
      content: (
        <div className="space-y-4">
          <p className="text-xs text-neutral-600 leading-relaxed font-semibold">
            When you request a pass inside physical shelters, follow these simple rules to ensure instantaneous approval:
          </p>

          <ul className="space-y-2.5 text-xs text-neutral-600 font-medium">
            <li className="flex items-start gap-2.5">
              <span className="text-brand-green font-bold shrink-0">✔</span>
              <span><strong>Bring Appointment Cards/Proof:</strong> Try to show an appointment slip, court summons packet, clinic scheduler, or a printout verifying the date and route of your commute.</span>
            </li>
            <li className="flex items-start gap-2.5">
              <span className="text-brand-green font-bold shrink-0">✔</span>
              <span><strong>File Ahead of Time:</strong> Request your passes during early morning day shelter check-in hours, rather than right before your bus leaves, as supply takes some minutes to prepare.</span>
            </li>
            <li className="flex items-start gap-2.5">
              <span className="text-brand-green font-bold shrink-0">✔</span>
              <span><strong>Keep It Safe:</strong> Daily and monthly cards cannot be re-issued if lost or stolen, so store them in a secure plastic ziplock container.</span>
            </li>
          </ul>

          <div className="p-4 bg-brand-green/5 border border-brand-green/10 rounded-2xl flex items-center justify-between gap-3 text-xs">
            <div className="space-y-0.5">
              <span className="font-black text-brand-green uppercase text-[10px] block">Submit a Transport Ticket Below</span>
              <span className="text-neutral-500 font-medium text-[10px]">Unhoused or in transit? Log a request and our advocate partners will pull a free bus ticket packet for your next meeting.</span>
            </div>
            <button
              onClick={() => setActiveStep(99)}
              className="text-[10px] font-black bg-brand-yellow text-brand-green px-3 py-1.5 rounded-xl uppercase tracking-wider shrink-0"
            >
              Start Request Form
            </button>
          </div>
        </div>
      )
    }
  ];

  const handleBusPassRequestSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!user) {
      setErrorMessage("Please sign in to submit a free bus pass ticket.");
      return;
    }

    if (!contactName.trim()) {
      setErrorMessage("Please enter your name.");
      return;
    }

    if (contactMethod !== 'shelter' && !contactPhone.trim()) {
      setErrorMessage("Please provide a contact phone number or message point.");
      return;
    }

    setIsSubmitting(true);

    try {
      const summaryMsg = `[FREE BUS PASS / EMBARK TRANSIT TICKET]
Name: ${contactName}
Contact Method: ${contactMethod.toUpperCase()} (${contactPhone || 'Shelter client'})
Reason for Free Pass: ${reason}
${contactMethod === 'shelter' ? `Target Shelter Location: ${preferredShelter}` : ''}
Verified dispatch request for emergency transport assistance.`;

      // 1. Submit to general queue (requests compilation)
      await addDoc(collection(db, 'requests'), {
        userId: user.uid,
        type: 'Transport',
        title: `EMBARK Pass: ${contactName}`,
        location: contactMethod === 'shelter' ? (preferredShelter.split(' (')[0]) : `OKC - ${contactPhone}`,
        description: summaryMsg,
        timestamp: serverTimestamp(),
        urgent: true,
        status: 'open'
      });

      // 2. Submit to dedicated bus_passes_requests collection
      await addDoc(collection(db, 'bus_passes_requests'), {
        userId: user.uid,
        userName: contactName,
        phone: contactPhone || 'Shelter Walk-in',
        reason: reason,
        status: 'pending',
        timestamp: serverTimestamp()
      });

      setRequestSubmitted(true);
      setContactName('');
      setContactPhone('');
      
      if (onHelpSubmitted) {
        onHelpSubmitted();
      }
    } catch (err: any) {
      console.error("Error submitting free bus pass request:", err);
      try {
        handleFirestoreError(err, OperationType.WRITE, 'bus_passes_requests');
      } catch (adapted: any) {
        setErrorMessage(`Failed to submit request. Details: ${adapted.message}`);
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="bg-white rounded-[2.5rem] border-2 border-brand-green/10 shadow-sm overflow-hidden flex flex-col">
      {/* Header Banner */}
      <div className="bg-brand-green text-white p-6 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-brand-yellow/10 rounded-full blur-2xl -mr-10 -mt-10"></div>
        <div className="flex items-center gap-3 relative z-10">
          <div className="p-3 bg-brand-yellow/10 border border-brand-yellow/30 rounded-2xl text-brand-yellow">
            <Bus className="w-8 h-8" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="bg-brand-yellow text-brand-green text-[9px] font-black tracking-widest uppercase px-2 py-0.5 rounded-md">EMBARK Transit Portal</span>
              <span className="text-[9px] text-emerald-300 font-black tracking-[0.15em] uppercase">Hand Up Program</span>
            </div>
            <h3 className="text-xl font-black font-mission tracking-tight text-white uppercase leading-none mt-1">EMBARK Free Bus Passes & Commute Guide</h3>
            <p className="text-[11px] text-emerald-200/90 font-medium tracking-tight mt-0.5">Learn how to easily ride for free or half-fare to clinics and job locations in OKC</p>
          </div>
        </div>
      </div>

      <div className="p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Hand: Checklist of navigation steps */}
        <div className="lg:col-span-5 space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-neutral-100">
            <span className="text-[10px] font-black text-neutral-400 uppercase tracking-wider">Tutorial & Resources</span>
            <span className="text-[9px] font-black text-brand-green bg-emerald-50 px-2 py-0.5 rounded-md">FREE FARES</span>
          </div>

          <div className="space-y-2">
            {stepsDetails.map(step => {
              const isActive = activeStep === step.id;
              const isDone = stepsCompleted[step.id];
              return (
                <div 
                  key={step.id}
                  className={cn(
                    "p-3 rounded-2xl border transition-all cursor-pointer flex items-start gap-3",
                    isActive 
                      ? "bg-brand-green/5 border-brand-green text-brand-green shadow-sm"
                      : "bg-white hover:bg-neutral-50/50 border-neutral-150"
                  )}
                  onClick={() => setActiveStep(step.id)}
                >
                  <div 
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleStepComplete(step.id);
                    }}
                    className={cn(
                      "w-4 h-4 rounded-md border flex items-center justify-center transition-colors shrink-0 mt-0.5 cursor-pointer",
                      isDone 
                        ? "bg-brand-green border-brand-green text-brand-yellow" 
                        : "border-neutral-300 bg-white"
                    )}
                  >
                    {isDone && <CheckSquare className="w-3.5 h-3.5" />}
                  </div>
                  <div className="space-y-0.5 animate-fade-in">
                    <div className="flex items-center gap-1.5 leading-none">
                      <span className="text-[9px] font-bold text-neutral-400 uppercase">{step.badge}</span>
                    </div>
                    <h5 className={cn("text-xs font-black uppercase tracking-tight leading-snug", isActive ? "text-brand-green" : "text-neutral-800")}>{step.title}</h5>
                    <p className="text-[10px] text-neutral-400 font-medium leading-normal line-clamp-1">{step.short}</p>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="bg-neutral-50 p-4 rounded-[1.75rem] border border-neutral-150 space-y-2 text-center">
            <span className="text-[9px] font-black text-neutral-400 uppercase tracking-widest block">Need a Free Emergency Pass?</span>
            <p className="text-[10px] text-neutral-500 font-medium leading-relaxed">
              If you have an upcoming interview, clinic consult, or shelter transition, apply for a pass online.
            </p>
            <button
              onClick={() => setActiveStep(99)}
              className={cn(
                "w-full py-2 px-3 rounded-xl font-black text-[10px] uppercase tracking-wider transition-all flex items-center justify-center gap-1.5",
                activeStep === 99 
                  ? "bg-brand-green text-brand-yellow" 
                  : "bg-brand-yellow text-brand-green hover:bg-yellow-400"
              )}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Request Free Bus Pass</span>
            </button>
          </div>
        </div>

        {/* Right Hand: Active step rendering */}
        <div className="lg:col-span-12 xl:col-span-7 bg-neutral-50 p-6 rounded-[2rem] border border-neutral-200/50">
          <AnimatePresence mode="wait">
            {activeStep !== 99 ? (
              <motion.div
                key={activeStep}
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                transition={{ duration: 0.2 }}
                className="space-y-4"
              >
                {/* Header elements */}
                <div className="pb-3 border-b border-neutral-250 flex items-center justify-between">
                  <div>
                    <span className="bg-brand-green text-brand-yellow text-[9px] font-black uppercase px-2 py-0.5 rounded-md tracking-wider">
                      {stepsDetails[activeStep - 1].badge}
                    </span>
                    <h4 className="font-black text-neutral-900 text-sm uppercase mt-1 leading-snug">
                      {stepsDetails[activeStep - 1].title}
                    </h4>
                  </div>
                  <button
                    onClick={() => toggleStepComplete(activeStep)}
                    className={cn(
                      "px-3 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-wider transition-all",
                      stepsCompleted[activeStep] 
                        ? "bg-emerald-100 text-brand-green" 
                        : "bg-white text-neutral-500 hover:text-neutral-800 hover:bg-neutral-100 border border-neutral-200"
                    )}
                  >
                    {stepsCompleted[activeStep] ? "Marked Complete" : "Mark Complete"}
                  </button>
                </div>

                {/* Content body */}
                <div>
                  {stepsDetails[activeStep - 1].content}
                </div>

                {/* Navigation options */}
                <div className="pt-4 border-t border-neutral-250 flex justify-between items-center">
                  <span className="text-[10px] font-bold text-neutral-400">Step {activeStep} of 4</span>
                  <div className="flex gap-2">
                    {activeStep > 1 && (
                      <button
                        onClick={() => setActiveStep(activeStep - 1)}
                        className="px-4 py-2 border rounded-xl font-bold text-xs uppercase text-neutral-600 hover:bg-neutral-100 transition-colors"
                      >
                        Prev
                      </button>
                    )}
                    {activeStep < 4 ? (
                      <button
                        onClick={() => setActiveStep(activeStep + 1)}
                        className="px-4 py-2 bg-brand-green hover:bg-emerald-950 text-brand-yellow transition-colors rounded-xl font-black text-xs uppercase tracking-wider flex items-center gap-1"
                      >
                        <span>Next Step</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    ) : (
                      <button
                        onClick={() => setActiveStep(99)}
                        className="px-4 py-2 bg-brand-yellow hover:bg-yellow-400 text-brand-green transition-colors rounded-xl font-black text-xs uppercase tracking-wider flex items-center gap-1 shadow"
                      >
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>Link to Pass Request</span>
                      </button>
                    )}
                  </div>
                </div>
              </motion.div>
            ) : (
              /* Step 99: Live Request Form */
              <motion.div
                key="request-pass-form"
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                className="space-y-4"
              >
                <div className="pb-3 border-b border-neutral-250">
                  <span className="bg-brand-yellow text-brand-green text-[9px] font-black uppercase px-2 py-0.5 rounded-md tracking-wider">
                    Assistance Request Ticket
                  </span>
                  <h4 className="font-black text-neutral-900 text-sm uppercase mt-1 leading-snug">
                    Submit Bus Pass Request Ticket
                  </h4>
                  <p className="text-[11px] text-neutral-500 font-medium">Specify your name and reason for travel. A Homeless Alliance case specialist or street team member will gather emergency bus tokens or passes for you.</p>
                </div>

                {!user ? (
                  <div className="p-5 bg-amber-50 rounded-2xl border border-amber-200 text-center space-y-3">
                    <Lock className="w-8 h-8 text-amber-600 mx-auto" />
                    <p className="text-xs font-bold text-amber-900 leading-relaxed uppercase">
                      You must sign in to submit a bus pass request ticket.
                    </p>
                    <p className="text-[10px] text-neutral-500 font-medium leading-normal max-w-xs mx-auto">
                      This tracks security audits and lets caseworkers safely assign tokens to you. Click "Sign In with Google" at the top of the screen to enter.
                    </p>
                  </div>
                ) : requestSubmitted ? (
                  <motion.div 
                    initial={{ scale: 0.95, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    className="p-6 bg-emerald-50 rounded-3xl border-2 border-emerald-200 text-center space-y-4"
                  >
                    <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center mx-auto text-brand-green shadow-sm">
                      <CheckCircle2 className="w-7 h-7" />
                    </div>
                    <div>
                      <h5 className="font-black text-emerald-950 uppercase text-sm">Bus Pass Ticket Created!</h5>
                      <p className="text-xs text-neutral-600 font-medium leading-relaxed mt-1">
                        We have registered your transit slot. Your request has also been logged into the community bulletin system so peer advocates or shelter staffs can prepare your daily passes instantly.
                      </p>
                    </div>
                    <button 
                      onClick={() => setRequestSubmitted(false)}
                      className="px-4 py-2 bg-white hover:bg-neutral-50 text-neutral-800 border rounded-xl font-bold text-xs uppercase"
                    >
                      Log Another Ticket
                    </button>
                  </motion.div>
                ) : (
                  <form onSubmit={handleBusPassRequestSubmit} className="space-y-3">
                    {errorMessage && (
                      <div className="p-3 bg-red-50 text-red-700 text-xs font-bold rounded-xl border border-red-200 flex items-center gap-2">
                        <AlertCircle className="w-4 h-4 shrink-0" />
                        <span>{errorMessage}</span>
                      </div>
                    )}

                    {/* Full Name */}
                    <div className="space-y-1">
                      <label className="text-[10px] font-black text-neutral-500 uppercase tracking-wider block">Your Full Name</label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Johnathan Miller"
                        value={contactName}
                        onChange={(e) => setContactName(e.target.value)}
                        className="w-full px-3 py-2 bg-white border border-neutral-200 rounded-xl text-xs font-bold focus:outline-none focus:ring-1 focus:ring-brand-green leading-none"
                      />
                    </div>

                    {/* Reason for Pass */}
                    <div className="space-y-1">
                      <label className="text-[10px] font-black text-neutral-500 uppercase tracking-wider block">Reason for Bus Pass / Transit Commute</label>
                      <select
                        value={reason}
                        onChange={(e) => setReason(e.target.value)}
                        className="w-full px-3 py-2 bg-white border border-neutral-200 rounded-xl text-xs font-bold focus:outline-none focus:ring-1 focus:ring-brand-green"
                      >
                        <option value="Medical Appointment / Pharmacy">Medical Appointment / Pharmacy</option>
                        <option value="Psychiatric Evaluation / Counseling">Psychiatric Evaluation / Counseling</option>
                        <option value="Job Interview / Workforce Shift">Job Interview / Workforce Shift</option>
                        <option value="Search for Stable / Transitional Housing">Search for Stable / Transitional Housing</option>
                        <option value="Legal Matters / DHS Court date">Legal Matters / DHS Court date</option>
                        <option value="Shelter Intake Checkin / Transitioning">Shelter Intake Checkin / Transitioning</option>
                      </select>
                    </div>

                    {/* Contact details */}
                    <div className="space-y-1">
                      <label className="text-[10px] font-black text-neutral-500 uppercase tracking-wider block">How to reach you with details</label>
                      <div className="grid grid-cols-3 gap-1.5">
                        {[
                          { id: 'phone', label: 'Call' },
                          { id: 'text', label: 'Text' },
                          { id: 'shelter', label: 'In Shelter' }
                        ].map(m => (
                          <button
                            key={m.id}
                            type="button"
                            onClick={() => setContactMethod(m.id as any)}
                            className={cn(
                              "py-2 rounded-xl border text-[9px] font-black uppercase transition-all text-center",
                              contactMethod === m.id 
                                ? "bg-brand-green text-brand-yellow border-brand-green" 
                                : "bg-white text-neutral-500 border-neutral-200 hover:bg-neutral-50"
                            )}
                          >
                            {m.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Dynamic phone number or target location setup */}
                    {contactMethod !== 'shelter' ? (
                      <div className="space-y-1">
                        <label className="text-[10px] font-black text-neutral-500 uppercase tracking-wider block">Phone Number or Message Box Location</label>
                        <input
                          type="tel"
                          required
                          placeholder="e.g. (405) 555-5555"
                          value={contactPhone}
                          onChange={(e) => setContactPhone(e.target.value)}
                          className="w-full px-3 py-2 bg-white border border-neutral-200 rounded-xl text-xs font-bold focus:outline-none focus:ring-1 focus:ring-brand-green leading-none"
                        />
                      </div>
                    ) : (
                      <div className="space-y-1">
                        <label className="text-[10px] font-black text-neutral-500 uppercase tracking-wider block">Target Intake Day Shelter/Center</label>
                        <select
                          value={preferredShelter}
                          onChange={(e) => setPreferredShelter(e.target.value)}
                          className="w-full px-3 py-2 bg-white border border-neutral-200 rounded-xl text-xs font-bold focus:outline-none focus:ring-1 focus:ring-brand-green"
                        >
                          <option value="Homeless Alliance Day Center (1220 W 4th St)">Homeless Alliance Day Center (1220 W 4th St, OKC)</option>
                          <option value="City Rescue Mission (800 W California Ave)">City Rescue Mission (800 W California Ave, OKC)</option>
                          <option value="Salvation Army Central Corps (1001 Penn Ave)">Salvation Army Central Corps (1001 Penn Ave, OKC)</option>
                          <option value="Sisu Youth Services (3000 N Classen Blvd)">Sisu Youth Services (3000 N Classen Blvd, OKC - Youth Only)</option>
                        </select>
                      </div>
                    )}

                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full flex items-center justify-center gap-1.5 py-3 bg-brand-green hover:bg-emerald-950 transition-colors text-brand-yellow font-black text-xs uppercase tracking-wider rounded-2xl shadow-md disabled:opacity-50"
                    >
                      {isSubmitting ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin" />
                          <span>Submitting Ticket...</span>
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-4 h-4 text-brand-yellow" />
                          <span>Submit Ticket & Request Connection</span>
                        </>
                      )}
                    </button>
                  </form>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}

import React, { useState, useEffect, useRef } from 'react';
import { 
  X, 
  Heart, 
  HelpCircle, 
  Printer, 
  Play, 
  Volume2, 
  VolumeX, 
  Sparkles, 
  CheckCircle2, 
  ChevronRight, 
  QrCode,
  Scissors,
  Smartphone,
  Users,
  TrendingUp,
  Coins,
  Check,
  FileText
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';

interface WelcomeOnboardingModalProps {
  isOpen: boolean;
  onClose: () => void;
  speakText?: (id: string, text: string) => Promise<void>;
  stopSpeaking?: () => void;
  speakingTextId?: string | null;
  isTtsLoading?: boolean;
}

const GUIDE_SECTIONS = [
  {
    id: 'helps',
    title: "1. Solidarity & Support",
    text: "Solidarity and Direct Action. Unlike traditional massive charities, Digital Hand Up ensures that support routes directly and unmitigated in Oklahoma City. We bridge peer-to-peer relationships, promoting genuine unity with zero overhead. One: Direct Wallet Transfers. Supporters scan your custom QR code and transfer funds securely via Venmo, CashApp, PayPal, or Zelle straight to your personal account. No platform cuts. Two: Immediate Material Supplies. Need food, specific clothing sizes, basic toiletries, or specific items? List these needs directly on your profile page so locals can purchase and supply them. Three: Honest Communication Portal. Supporters can chat with you safely and respectfully from the unified in-app Inbox."
  },
  {
    id: 'works',
    title: "2. Simple 3-Step Loop",
    text: "Getting started takes less than three minutes. Follow this basic loop to establish community assistance or start assisting neighbors in transition today. Step one: Create and Connect Wallets. Link your digital handles, Venmo, CashApp, Zelle, or gift registries, under the profile tab. Step two: Print Your QR Handout Flyers. Generate and print your custom four-in-one flyer page from the Flyer Kit section. Each slip features your name, profile card icon, verified goals, and your direct QR code. Step three: Distribute in Oklahoma City. Hand out your physical QR slips, share them on cardboard signs, or stick them onto clothing or backpacks. Supportive neighbors can instantly trigger donations by scanning."
  },
  {
    id: 'step-0',
    title: "3. Step 1: Prepare & Print",
    text: "Step one: Prepare and Print. Log in, open your Profile, and access the 'Flyer Kit'. Tap print to generate four high quality A6 QR Flyers per page directly. Print in standard letter sizes."
  },
  {
    id: 'step-1',
    title: "4. Step 2: Cut Into Bills",
    text: "Step two: Cut out the sheets. Cut along the marked dotted margins to separate the sheets into four durable hand-out mini bills that fit cleanly in a pocket or backpack."
  },
  {
    id: 'step-2',
    title: "5. Step 3: Secure Legal Approach",
    text: "Step three: Secure passive approach law friendly icebreaker. Whether you fly a sign, sell curb side, or use a direct approach: the law frowns on aggressive panhandling. This passive flyer is a peaceful, polite, legal, new way to break the ice with neighbors."
  },
  {
    id: 'step-3',
    title: "6. Step 4: Consistency is Success",
    text: "Step four: Consistency is key! The more flyers you distribute on your daily routes, the higher your chances of success. Each slip is a permanent seed of connection."
  },
  {
    id: 'welcome-encouragement',
    title: "7. You are Welcome Here!",
    text: "We are incredibly happy that you are here on our platform. Digital Hand Up is powered by genuine OKC neighbors rooting for you. We warmly encourage you to create your beautiful profile right now, link your digital wallets, specify your immediate material goals, and launch your supportive campaign today. Hand up!"
  }
];

export default function WelcomeOnboardingModal({ 
  isOpen, 
  onClose,
  speakText,
  stopSpeaking,
  speakingTextId,
  isTtsLoading
}: WelcomeOnboardingModalProps) {
  const [currentReadingIndex, setCurrentReadingIndex] = useState<number>(-1);
  const [isCurrentStepFinished, setIsCurrentStepFinished] = useState<boolean>(false);
  const [elapsedProgress, setElapsedProgress] = useState<number>(0);
  
  const hasStartedSpeakingRef = useRef<boolean>(false);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Keep references to incoming methods and dynamic properties so they do not trigger infinite rendering updates
  const speakTextRef = useRef(speakText);
  const stopSpeakingRef = useRef(stopSpeaking);
  const speakingTextIdRef = useRef(speakingTextId);
  const isTtsLoadingRef = useRef(isTtsLoading);

  useEffect(() => {
    speakTextRef.current = speakText;
  }, [speakText]);

  useEffect(() => {
    stopSpeakingRef.current = stopSpeaking;
  }, [stopSpeaking]);

  useEffect(() => {
    speakingTextIdRef.current = speakingTextId;
  }, [speakingTextId]);

  useEffect(() => {
    isTtsLoadingRef.current = isTtsLoading;
  }, [isTtsLoading]);

  // Auto-duration calculation based on slow 1.9 words-per-second speech pacing
  const getEstimatedDurationMs = (text: string) => {
    const wordCount = text.split(/\s+/).length;
    // Word counts range between 35 and 100.
    // At ~1.9 words per second, this gives 18-50 seconds.
    // Minimum duration is 8 seconds just in case.
    return Math.max(9000, Math.ceil((wordCount / 1.95) * 1000));
  };

  // Main lifecycle controller: triggers when opening or switching steps
  useEffect(() => {
    if (!isOpen) {
      if (currentReadingIndex !== -1) {
        setCurrentReadingIndex(-1);
      }
      setIsCurrentStepFinished(false);
      setElapsedProgress(0);
      hasStartedSpeakingRef.current = false;
      if (stopSpeakingRef.current) stopSpeakingRef.current();
      if (timerRef.current) clearInterval(timerRef.current);
      return;
    }

    // Initialize to index 0 on start
    if (currentReadingIndex < 0) {
      setCurrentReadingIndex(0);
      setIsCurrentStepFinished(false);
      setElapsedProgress(0);
      hasStartedSpeakingRef.current = false;
      return;
    }

    const section = GUIDE_SECTIONS[currentReadingIndex];
    if (section) {
      setIsCurrentStepFinished(false);
      setElapsedProgress(0);
      hasStartedSpeakingRef.current = false;

      // Start synthesis speech immediately
      if (speakTextRef.current) {
        speakTextRef.current(section.id, section.text);
      }

      // Start the progress simulation timer to match exact speech length
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }

      const totalDurationMs = getEstimatedDurationMs(section.text);
      const updateIntervalMs = 150;
      let timeSpentMs = 0;

      timerRef.current = setInterval(() => {
        timeSpentMs += updateIntervalMs;
        const percent = Math.min(100, (timeSpentMs / totalDurationMs) * 100);
        setElapsedProgress(percent);

        // Once the visual progress hits 100%:
        if (percent >= 100) {
          if (timerRef.current) {
            clearInterval(timerRef.current);
          }
          // Mark step finished when voice is no longer active
          if (speakingTextIdRef.current !== section.id && !isTtsLoadingRef.current) {
            setIsCurrentStepFinished(true);
          }
        }
      }, updateIntervalMs);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isOpen, currentReadingIndex]);

  // Sync state when voice synthesis ends early or completes successfully
  useEffect(() => {
    if (currentReadingIndex < 0 || currentReadingIndex >= GUIDE_SECTIONS.length) return;
    const section = GUIDE_SECTIONS[currentReadingIndex];

    if (isTtsLoading || speakingTextId === section.id) {
      hasStartedSpeakingRef.current = true;
    } else if (hasStartedSpeakingRef.current && speakingTextId !== section.id && !isTtsLoading) {
      // Narration completed naturally early! Fast-forward progress bar to 100% and unlock progression
      setElapsedProgress(100);
      setIsCurrentStepFinished(true);
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    }
  }, [speakingTextId, isTtsLoading, currentReadingIndex]);

  if (!isOpen) return null;

  const currentSection = GUIDE_SECTIONS[currentReadingIndex] || GUIDE_SECTIONS[0];

  return (
    <div id="onboarding-modal-root" className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      {/* Soft overlay backdrop */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={() => {
          if (stopSpeakingRef.current) stopSpeakingRef.current();
          onClose();
        }}
        className="absolute inset-0 bg-[#14532d]/45 backdrop-blur-md"
      />

      {/* Cinematic Theater Card */}
      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        transition={{ type: "spring", damping: 26, stiffness: 360 }}
        className="relative w-full max-w-lg bg-neutral-900 text-white rounded-[2.5rem] shadow-2xl border-4 border-[#14532d] overflow-hidden flex flex-col max-h-[92vh]"
      >
        {/* Theater Marquee Header */}
        <div className="bg-[#14532d] p-4 text-white flex items-center justify-between border-b border-[#fbbf24]/30 relative z-10 select-none">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full border-2 border-[#fbbf24] bg-emerald-950 flex items-center justify-center overflow-hidden p-0.5 shadow-md flex-shrink-0">
              <svg viewBox="0 0 100 100" className="w-full h-full">
                <path id="path-top" d="M 12 50 A 38 38 0 1 1 88 50" fill="transparent" />
                <path id="path-bottom" d="M 88 50 A 38 38 0 1 1 12 50" fill="transparent" />
                <circle cx="50" cy="50" r="30" fill="#7dd3fc" />
                <polygon points="50,42 28,70 72,70" fill="#d97706" opacity="0.8" />
                <polygon points="50,42 42,70 58,70" fill="#b45309" />
                <path d="M25,58 Q35,52 45,55" stroke="#f59e0b" strokeWidth="4" strokeLinecap="round" fill="none" />
                <path d="M75,58 Q65,52 55,55" stroke="#78350f" strokeWidth="4" strokeLinecap="round" fill="none" />
                <circle cx="50" cy="55" r="4.5" fill="#f59e0b" />
                <circle cx="47" cy="55" r="4.5" fill="#78350f" opacity="0.9" />
                <text className="font-extrabold text-[12px] tracking-[0.16em]" fill="#fbbf24">
                  <textPath href="#path-top" startOffset="50%" textAnchor="middle">HAND UP</textPath>
                </text>
                <text className="font-extrabold text-[7.5px] tracking-[0.12em]" fill="#fbbf24">
                  <textPath href="#path-bottom" startOffset="50%" textAnchor="middle">DIGITAL HAND UP</textPath>
                </text>
              </svg>
            </div>
            <div>
              <h2 className="text-xs font-black tracking-widest text-[#fbbf24] uppercase">NARRA-PLAY THEATER</h2>
              <p className="text-[9px] font-bold text-emerald-300 tracking-wider">Oklahoma City Solidarity Guide</p>
            </div>
          </div>
          
          <button 
            onClick={() => {
              if (stopSpeakingRef.current) stopSpeakingRef.current();
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-red-500 hover:text-white flex items-center justify-center transition-all text-neutral-300"
            title="Exit Guide"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Linear Step Tracker (Strict Non-interactive Progress Line) */}
        <div className="bg-neutral-950 px-6 py-3 border-b border-neutral-800 flex items-center gap-1.5 select-none text-[9px] font-black tracking-widest text-neutral-500 uppercase">
          {GUIDE_SECTIONS.map((sec, idx) => (
            <React.Fragment key={sec.id}>
              <div className={cn(
                "flex items-center gap-1 transition-colors px-1.5 py-0.5 rounded",
                idx === currentReadingIndex 
                  ? "text-[#fbbf24] bg-[#14532d]/30 font-black" 
                  : idx < currentReadingIndex
                    ? "text-[#14532d] font-bold"
                    : "text-neutral-600"
              )}>
                {idx < currentReadingIndex ? (
                  <Check className="w-3 h-3 text-emerald-500 shrink-0" />
                ) : (
                  <span>{idx + 1}</span>
                )}
              </div>
              {idx < GUIDE_SECTIONS.length - 1 && (
                <div className={cn(
                  "flex-1 h-0.5 rounded transition-colors",
                  idx < currentReadingIndex ? "bg-[#14532d]" : "bg-neutral-800"
                )} />
              )}
            </React.Fragment>
          ))}
        </div>

        {/* Audio / Streaming Wave Form Status Strip */}
        <div className="bg-[#111] text-[#fbbf24] font-black text-[9px] uppercase tracking-widest py-2.5 text-center border-b border-neutral-800 flex items-center justify-center gap-2.5 select-none">
          {speakingTextId === currentSection.id ? (
            <>
              <Volume2 className="w-4 h-4 animate-bounce text-emerald-400 shrink-0" />
              <span className="text-emerald-400">Audio narration active & loaded</span>
              <span className="text-neutral-500">|</span>
              <span className="text-neutral-400">Speaking step {currentReadingIndex + 1} of {GUIDE_SECTIONS.length}...</span>
            </>
          ) : isTtsLoading ? (
            <>
              <div className="w-2 h-2 rounded-full bg-amber-400 animate-ping shrink-0" />
              <span className="text-amber-400 animate-pulse">Streaming crystal-clear voice explanation...</span>
            </>
          ) : (
            <>
              <VolumeX className="w-4 h-4 text-neutral-500 shrink-0" />
              <span className="text-neutral-400">Audio narration idle</span>
            </>
          )}
        </div>

        {/* Dynamic Video Viewport (The center stage of our theater) */}
        <div className="p-6 flex-1 flex flex-col items-stretch space-y-4 overflow-y-auto">
          <div className="bg-neutral-950 rounded-[2rem] border-4 border-[#14532d] overflow-hidden shadow-inner flex flex-col relative aspect-[14/9] shrink-0">
            <div className="flex-1 flex items-center justify-center p-4 relative bg-[#090909] select-none overflow-hidden">
              
              {/* Cinematic Scanline Overlay Effect */}
              <div className="pointer-events-none absolute inset-0 bg-radial-gradient opacity-20 pointer-events-none z-10" />
              
              <AnimatePresence mode="wait">
                {/* Section 0: How It Helps */}
                {currentReadingIndex === 0 && (
                  <motion.div 
                    key="helps-screen"
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className="flex flex-col items-center justify-center text-center space-y-3 w-full"
                  >
                    <div className="relative flex items-center justify-center gap-6">
                      {/* Left Smartphone Transfer Ring */}
                      <div className="w-14 h-24 bg-neutral-800 border-2 border-emerald-500 rounded-xl relative p-1 pb-3 flex flex-col justify-between">
                        <div className="w-4 h-1 bg-neutral-600 rounded mx-auto" />
                        <div className="flex-1 bg-neutral-900 rounded-lg flex flex-col items-center justify-center relative overflow-hidden">
                          <Coins className="w-6 h-6 text-emerald-400 animate-bounce" />
                          <span className="text-[6px] text-emerald-400 font-extrabold mt-1">DIRECT</span>
                        </div>
                        <div className="w-3 h-3 bg-neutral-600 rounded-full mx-auto mt-1" />
                        
                        {/* Floating cash bubble arising */}
                        <motion.div 
                          animate={{ y: [-10, -50], opacity: [0, 1, 0], x: [0, 10, -5] }}
                          transition={{ duration: 2.2, repeat: Infinity, ease: 'easeOut' }}
                          className="absolute -top-4 left-1/2 -translate-x-1/2 w-6 h-6 rounded-full bg-emerald-500 text-white flex items-center justify-center text-xs font-black shadow-lg"
                        >
                          $
                        </motion.div>
                      </div>

                      {/* Right Hand Recipient Solidary */}
                      <div className="w-16 h-20 bg-[#14532d]/40 rounded-2xl border border-[#fbbf24]/30 p-2 flex flex-col items-center justify-center relative">
                        <Heart className="w-7 h-7 text-[#fbbf24] animate-pulse fill-[#fbbf24]" />
                        <span className="text-[8px] text-[#fbbf24] font-black mt-1.5 uppercase tracking-wider block">OKC Unity</span>
                      </div>
                    </div>

                    <div>
                      <p className="text-xs text-[#fbbf24] font-black uppercase tracking-wider">SOLIDARITY & P2P TRANSFERS</p>
                      <p className="text-[10px] text-neutral-400 mt-1 max-w-xs px-2 leading-relaxed">
                        Funds land safely direct in your personal wallets - cash apps or registries. Zero cut, zero interference, pure community warmth.
                      </p>
                    </div>
                  </motion.div>
                )}

                {/* Section 1: How It Works */}
                {currentReadingIndex === 1 && (
                  <motion.div 
                    key="works-screen"
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className="flex flex-col items-center justify-center text-center space-y-4 w-full"
                  >
                    <div className="flex items-center gap-4 justify-center relative">
                      {/* 3 Step icons connecting */}
                      <div className="flex flex-col items-center">
                        <div className="w-8 h-8 rounded-full bg-neutral-800 border border-emerald-500 flex items-center justify-center text-emerald-400">
                          <Smartphone className="w-4 h-4" />
                        </div>
                        <span className="text-[7px] text-neutral-400 mt-1 font-bold">1. Wallet</span>
                      </div>
                      
                      <div className="w-4 h-0.5 bg-neutral-800" />
                      
                      <div className="flex flex-col items-center">
                        <div className="w-8 h-8 rounded-full bg-neutral-800 border border-[#fbbf24] flex items-center justify-center text-[#fbbf24]">
                          <Printer className="w-4 h-4" />
                        </div>
                        <span className="text-[7px] text-neutral-400 mt-1 font-bold">2. Print</span>
                      </div>

                      <div className="w-4 h-0.5 bg-neutral-800" />

                      <div className="flex flex-col items-center">
                        <div className="w-8 h-8 rounded-full bg-neutral-800 border border-[#fbbf24] flex items-center justify-center text-[#fbbf24] relative shadow-lg">
                          <Users className="w-4 h-4" />
                          <motion.div 
                            animate={{ scale: [1, 1.3, 1] }}
                            transition={{ repeat: Infinity, duration: 1.8 }}
                            className="absolute -inset-1 rounded-full border border-emerald-500/45 pointer-events-none"
                          />
                        </div>
                        <span className="text-[7px] text-neutral-400 mt-1 font-bold">3. Handout</span>
                      </div>
                    </div>

                    <div>
                      <p className="text-xs text-brand-yellow font-black uppercase tracking-wider">3-STEP RECURRING OPERATION</p>
                      <p className="text-[10px] text-neutral-400 mt-1 max-w-xs px-2 leading-relaxed">
                        Connect digital handles like CashApp, download high-quality flyers page, cut into slips, and share with direct OKC citizens.
                      </p>
                    </div>
                  </motion.div>
                )}

                {/* Section 2: Step 1 Generate & Print */}
                {currentReadingIndex === 2 && (
                  <motion.div 
                    key="step0-screen"
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className="flex flex-col items-center justify-center text-center space-y-3"
                  >
                    <div className="relative">
                      {/* Printer Core */}
                      <div className="w-24 h-12 bg-neutral-800 border-t-4 border-[#fbbf24] rounded-t-xl shadow-2xl relative flex items-center justify-center text-white">
                        <span className="text-[8px] font-black tracking-widest text-[#fbbf24]">HAND UP PRNT</span>
                      </div>
                      
                      {/* Popout paper flyer */}
                      <motion.div 
                        animate={{ y: [0, 20, 0] }}
                        transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut" }}
                        className="absolute left-1/2 -translate-x-1/2 -bottom-8 w-16 h-12 bg-white rounded border border-neutral-300 shadow p-1 flex flex-col justify-between"
                      >
                        <div className="w-full h-1 bg-emerald-800/20 rounded"></div>
                        <QrCode className="w-5 h-5 text-neutral-900 mx-auto" />
                        <div className="w-full h-1 bg-emerald-800/20 rounded"></div>
                      </motion.div>
                    </div>
                    
                    <div className="pt-8">
                      <p className="text-xs text-[#fbbf24] font-black uppercase tracking-wider">STEP 1: PREPARE & PRINT</p>
                      <p className="text-[10.5px] text-neutral-400 mt-1 max-w-xs leading-relaxed font-semibold">
                        Access 'Flyer Kit' in your Profile, press print, and output your standard letter sheets containing 4 cards each.
                      </p>
                    </div>
                  </motion.div>
                )}

                {/* Section 3: Step 2 Cut Into Bills */}
                {currentReadingIndex === 3 && (
                  <motion.div 
                    key="step1-screen"
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className="flex flex-col items-center justify-center text-center space-y-3"
                  >
                    <div className="relative w-44 h-20 border-2 border-dashed border-neutral-600 rounded-xl p-1 bg-white/5 flex items-center justify-center">
                      <div className="absolute left-1/2 inset-y-0 border-r-2 border-dashed border-[#fbbf24]/50"></div>
                      <div className="absolute inset-x-0 top-1/2 border-t-2 border-dashed border-[#fbbf24]/50"></div>
                      
                      <motion.div 
                        animate={{ x: [-18, 18, -18], y: [-6, 6, -6], rotate: [0, 4, 0] }}
                        transition={{ duration: 2.8, repeat: Infinity }}
                        className="bg-neutral-800 text-[#fbbf24] p-1.5 rounded-full border border-neutral-700 shadow-xl z-20"
                      >
                        <Scissors className="w-4 h-4 text-[#fbbf24]" />
                      </motion.div>

                      <div className="grid grid-cols-2 w-full h-full gap-2 opacity-50">
                        {[1,2,3,4].map(i => (
                          <div key={i} className="bg-emerald-950/30 border border-emerald-500/20 rounded flex flex-col items-center justify-center">
                            <span className="text-[6px] tracking-widest text-[#fbbf24] font-black">MINI CARD</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div>
                      <p className="text-xs text-brand-yellow font-black uppercase tracking-wider">STEP 2: CUT OUT THE SHEET</p>
                      <p className="text-[10.5px] text-neutral-400 mt-1 max-w-xs font-semibold leading-relaxed">
                        Cut along the dotted quadrant lines to separate sheets. Turns 1 page into 4 compact, pocket-ready mini contact bills!
                      </p>
                    </div>
                  </motion.div>
                )}

                {/* Section 4: Step 3 Secure Legal passive approach */}
                {currentReadingIndex === 4 && (
                  <motion.div 
                    key="step2-screen"
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className="flex flex-col items-center justify-center text-center space-y-4 w-full"
                  >
                    <div className="flex items-center gap-4 justify-center">
                      <div className="bg-neutral-900 border border-neutral-700 rounded-xl p-3 shadow-lg flex flex-col items-center text-center">
                        <span className="text-[7px] text-neutral-400 font-extrabold uppercase">AGGRESSIVE PANHANDLING</span>
                        <div className="text-red-500 text-xs font-black mt-1">🚫 WRONG WAY</div>
                      </div>

                      <span className="text-[#fbbf24] text-sm font-black animate-pulse">➡️</span>

                      <div className="bg-[#14532d]/40 border-2 border-emerald-500 rounded-xl p-3 shadow-2xl flex flex-col items-center text-center">
                        <span className="text-[7.5px] text-[#fbbf24] font-black uppercase tracking-widest">PEACEFUL QR FLYER</span>
                        <div className="text-emerald-400 text-xs font-black mt-1">✅ LAW FRIENDLY</div>
                      </div>
                    </div>

                    <div>
                      <p className="text-xs text-[#fbbf24] font-black uppercase tracking-wider">STEP 3: SECURE PASSIVE APPROACH</p>
                      <p className="text-[10px] text-neutral-400 mt-1 max-w-xs px-2 leading-relaxed">
                        Aggressive soliciting faces local hurdles. Handing out clean QR slips provides citizens with a peaceful and perfectly respectful icebreaker.
                      </p>
                    </div>
                  </motion.div>
                )}

                {/* Section 5: Step 4 Scale Success Chart */}
                {currentReadingIndex === 5 && (
                  <motion.div 
                    key="step3-screen"
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className="flex flex-col items-center justify-center text-center space-y-3 w-full px-4"
                  >
                    <div className="flex items-end gap-3 justify-center h-20 w-52 bg-neutral-900/80 p-2.5 rounded-2xl border border-neutral-800">
                      <div className="flex flex-col items-center gap-1.5">
                        <div className="w-6 bg-red-500/20 h-5 rounded-t" />
                        <span className="text-[5.5px] text-neutral-400 font-black">1 FLYER</span>
                      </div>
                      
                      <div className="flex flex-col items-center gap-1.5">
                        <div className="w-6 bg-amber-500/40 h-10 rounded-t" />
                        <span className="text-[5.5px] text-neutral-400 font-black">5 FLYERS</span>
                      </div>

                      <motion.div 
                        animate={{ height: ["12px", "48px", "12px"] }}
                        transition={{ duration: 2.2, repeat: Infinity, ease: "easeInOut" }}
                        className="flex flex-col items-center gap-1.5"
                      >
                        <div className="w-6 bg-brand-yellow h-14 rounded-t border-t border-[#fbbf24] animate-pulse" />
                        <span className="text-[5.5px] text-[#fbbf24] font-black">15+ FLYERS</span>
                      </motion.div>
                      
                      <div className="flex-1 text-right pl-2">
                        <span className="text-[8px] text-emerald-400 font-black tracking-widest block leading-none">RATIO</span>
                        <span className="text-sm text-white font-extrabold block leading-none mt-1">95% ↑</span>
                        <span className="text-[5px] text-neutral-400 block mt-0.5">EST. OUTCOMES</span>
                      </div>
                    </div>

                    <div>
                      <p className="text-xs text-[#fbbf24] font-black uppercase tracking-wider">STEP 4: HAND OUT CONSTANTLY</p>
                      <p className="text-[10px] text-neutral-400 mt-1 max-w-xs leading-relaxed font-semibold">
                        Consistency builds relationships! Distributing slips regularly along your daily paths dramatically ensures community callbacks.
                      </p>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Simulated Player Timeline progress bar */}
            <div className="bg-[#111] border-t border-[#14532d] p-3 flex items-center justify-between gap-4 z-10 select-none">
              <div id="video_timeline_bar_outer" className="flex-1 h-2 bg-neutral-800 rounded-full overflow-hidden relative">
                <div 
                  id="video_timeline_bar_inner"
                  className="h-full bg-gradient-to-r from-emerald-600 to-[#fbbf24] rounded-full transition-all duration-150"
                  style={{ width: `${elapsedProgress}%` }}
                />
              </div>
              <div className="text-[8.5px] font-black text-[#fbbf24] uppercase tracking-wider">
                Video Sequence: Page {currentReadingIndex + 1} of {GUIDE_SECTIONS.length}
              </div>
            </div>
          </div>

          {/* Scrolling Transcript Captions (Makes it very easy to read along as voice speaks slowly) */}
          <div id="cinematic_guide_subtitles" className="p-4 bg-neutral-950 border-2 border-[#14532d] rounded-2.5xl flex gap-3 text-left items-start relative min-h-[92px]">
            <div className="w-8 h-8 rounded-xl bg-[#14532d] text-[#fbbf24] flex items-center justify-center text-xs font-black shrink-0 shadow mt-0.5">
              <FileText className="w-4 h-4" />
            </div>
            
            <div id="cinematic_guide_subtitle_text" className="space-y-1">
              <h4 className="text-[10px] font-extrabold text-[#fbbf24] uppercase tracking-wider flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping shrink-0" />
                Narration Caption Subtitles
              </h4>
              <p className="text-xs text-neutral-200 leading-relaxed font-semibold">
                {currentSection.text}
              </p>
            </div>
          </div>
        </div>

        {/* Widescreen Theater Controller & Progressive Progression Footer */}
        <div className="p-5 bg-[#0a0a0a] border-t border-neutral-800 flex items-center justify-between gap-4">
          <div className="text-left select-none">
            <span className="block text-[8px] font-black text-neutral-500 uppercase tracking-widest leading-none">Our Motto</span>
            <span className="text-[#fbbf24] font-black italic text-base tracking-tight">"Hand Up"</span>
          </div>

          <div className="flex items-center gap-3">
            {!isCurrentStepFinished ? (
              <div className="flex items-center gap-2">
                <div 
                  id="listening_guide_status"
                  className="flex items-center gap-2 px-3 py-2 bg-neutral-900 border border-neutral-800 text-neutral-400 font-extrabold text-[9px] tracking-widest uppercase rounded-xl animate-pulse select-none text-center"
                >
                  <div className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-ping shrink-0" />
                  Speaking...
                </div>
                {currentReadingIndex < GUIDE_SECTIONS.length - 1 ? (
                  <button
                    id="skip_narration_btn"
                    onClick={() => {
                      if (stopSpeakingRef.current) stopSpeakingRef.current();
                      setCurrentReadingIndex(prev => prev + 1);
                    }}
                    className="bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 text-[#fbbf24] font-black px-4 py-2.5 rounded-xl text-[10px] tracking-wider uppercase transition-all flex items-center gap-1 cursor-pointer focus:outline-none"
                    title="Skip speech and advance to next page"
                  >
                    Skip to Next
                    <ChevronRight className="w-3.5 h-3.5 text-[#fbbf24]" />
                  </button>
                ) : (
                  <button
                    id="skip_to_finish_btn"
                    onClick={() => {
                      if (stopSpeakingRef.current) stopSpeakingRef.current();
                      onClose();
                    }}
                    className="bg-[#14532d] hover:bg-emerald-955 border-b-2 border-emerald-950 text-[#fbbf24] font-black px-4 py-2.5 rounded-xl text-[10px] tracking-wider uppercase transition-all flex items-center gap-1.5 cursor-pointer focus:outline-none"
                    title="Skip final text and complete the guide"
                  >
                    Skip & Finish
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#fbbf24]" />
                  </button>
                )}
              </div>
            ) : currentReadingIndex < GUIDE_SECTIONS.length - 1 ? (
              <button
                id="next_guide_page_btn"
                onClick={() => {
                  setCurrentReadingIndex(prev => prev + 1);
                }}
                className="bg-[#14532d] hover:bg-emerald-950 border-b-4 border-emerald-950 hover:border-emerald-950 text-[#fbbf24] font-black px-5 py-3 rounded-2xl text-[11px] tracking-wider uppercase transition-all flex items-center gap-1.5 cursor-pointer hover:scale-102 focus:outline-none select-none shadow-md animate-pulse"
              >
                Go to Next Page
                <ChevronRight className="w-4 h-4 text-[#fbbf24] shrink-0" />
              </button>
            ) : (
              <button
                id="complete_guide_btn"
                onClick={() => {
                  if (stopSpeakingRef.current) stopSpeakingRef.current();
                  onClose();
                }}
                className="bg-[#14532d] hover:bg-emerald-950 border-b-4 border-emerald-950 text-[#fbbf24] font-black px-6 py-3 rounded-2xl text-[11px] tracking-wider uppercase transition-all flex items-center gap-1.5 cursor-pointer hover:scale-102 focus:outline-none select-none shadow-lg"
              >
                <CheckCircle2 className="w-4 h-4 text-[#fbbf24] shrink-0" />
                Finish & Close Guide
              </button>
            )}

            {/* Quick exit option available if user wants to quit early */}
            <button
              id="exit_early_guide_btn"
              onClick={() => {
                if (stopSpeakingRef.current) stopSpeakingRef.current();
                onClose();
              }}
              className="bg-neutral-900 hover:bg-neutral-800 text-neutral-400 font-extrabold px-3 py-3 rounded-2xl text-[10px] tracking-wider uppercase border border-neutral-800 transition-all cursor-pointer flex items-center shrink-0 focus:outline-none"
              title="Close the guide completely at any time"
            >
              Exit
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronLeft, ChevronRight, Heart, MessageCircle, Send, Trash2 } from 'lucide-react';
import { PhotoGalleryItem, PhotoComment } from '../App';
import { doc, updateDoc, arrayUnion, arrayRemove } from 'firebase/firestore';
import { db } from '../lib/backend';

interface PhotoRolodexProps {
  photos: PhotoGalleryItem[];
  isOwner: boolean;
  onDelete: (photo: PhotoGalleryItem) => void;
  currentUser: any;
}

export default function PhotoRolodex({ photos, isOwner, onDelete, currentUser }: PhotoRolodexProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [commentText, setCommentText] = useState('');
  const [showComments, setShowComments] = useState(false);

  if (!photos || photos.length === 0) return null;

  const currentPhoto = photos[currentIndex];
  
  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % photos.length);
    setShowComments(false);
  };
  
  const handlePrev = () => {
    setCurrentIndex((prev) => (prev - 1 + photos.length) % photos.length);
    setShowComments(false);
  };

  const handleLike = async () => {
    if (!currentUser || !currentPhoto) return;
    const photoRef = doc(db, `users/${currentPhoto.userId}/photos`, currentPhoto.id);
    const hasLiked = currentPhoto.likes?.includes(currentUser.uid);
    
    try {
      await updateDoc(photoRef, {
        likes: hasLiked ? arrayRemove(currentUser.uid) : arrayUnion(currentUser.uid)
      });
    } catch (error) {
      console.error("Error updating likes:", error);
    }
  };

  const handleAddComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser || !currentPhoto || !commentText.trim()) return;
    
    const newComment: PhotoComment = {
      id: Math.random().toString(36).substring(2, 15),
      userId: currentUser.uid,
      userName: currentUser.displayName || 'Anonymous',
      text: commentText.trim(),
      timestamp: Date.now()
    };

    const photoRef = doc(db, `users/${currentPhoto.userId}/photos`, currentPhoto.id);
    try {
      await updateDoc(photoRef, {
        comments: arrayUnion(newComment)
      });
      setCommentText('');
    } catch (error) {
      console.error("Error adding comment:", error);
    }
  };

  const hasLiked = currentPhoto.likes?.includes(currentUser?.uid);

  return (
    <div className="relative w-full max-w-2xl mx-auto flex flex-col items-center">
      <div className="relative w-full aspect-[4/3] perspective-1000">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentIndex}
            initial={{ opacity: 0, rotateY: 90, scale: 0.9 }}
            animate={{ opacity: 1, rotateY: 0, scale: 1 }}
            exit={{ opacity: 0, rotateY: -90, scale: 0.9 }}
            transition={{ duration: 0.4, ease: "easeInOut" }}
            className="absolute inset-0 bg-white rounded-3xl shadow-xl border border-neutral-200 overflow-hidden flex flex-col"
            style={{ transformStyle: 'preserve-3d' }}
          >
            <div className="relative flex-1 bg-black/5">
              <img src={currentPhoto.imageUrl} alt={currentPhoto.note} className="w-full h-full object-contain" />
              {isOwner && (
                <button 
                  onClick={() => onDelete(currentPhoto)}
                  className="absolute top-3 right-3 bg-red-600/90 text-white p-2 rounded-full hover:bg-red-600 shadow-sm transition-transform hover:scale-110"
                  title="Delete photo"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
            </div>
            
            <div className="p-4 bg-white border-t border-neutral-100 space-y-3">
              {currentPhoto.note && (
                <p className="text-neutral-700 italic text-center font-medium">"{currentPhoto.note}"</p>
              )}
              
              <div className="flex items-center justify-between border-t border-neutral-50 pt-3">
                <div className="flex items-center gap-4">
                  <button onClick={handleLike} className={`flex items-center gap-1.5 transition-colors ${hasLiked ? 'text-red-500' : 'text-neutral-500 hover:text-red-500'}`}>
                    <Heart className={`w-5 h-5 ${hasLiked ? 'fill-current' : ''}`} />
                    <span className="text-xs font-bold">{currentPhoto.likes?.length || 0}</span>
                  </button>
                  <button onClick={() => setShowComments(!showComments)} className="flex items-center gap-1.5 text-neutral-500 hover:text-brand-green transition-colors">
                    <MessageCircle className="w-5 h-5" />
                    <span className="text-xs font-bold">{currentPhoto.comments?.length || 0}</span>
                  </button>
                </div>
                <div className="text-[10px] text-neutral-400 font-bold uppercase tracking-wider">
                  {currentIndex + 1} OF {photos.length}
                </div>
              </div>

              <AnimatePresence>
                {showComments && (
                  <motion.div 
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden border-t border-neutral-100 mt-2"
                  >
                    <div className="py-3 space-y-3 max-h-40 overflow-y-auto">
                      {currentPhoto.comments?.map((comment) => (
                        <div key={comment.id} className="bg-neutral-50 p-2.5 rounded-xl border border-neutral-100">
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-xs font-bold text-neutral-800">{comment.userName}</span>
                            <span className="text-[9px] text-neutral-400 font-semibold">{new Date(comment.timestamp).toLocaleDateString()}</span>
                          </div>
                          <p className="text-xs text-neutral-600">{comment.text}</p>
                        </div>
                      ))}
                      {(!currentPhoto.comments || currentPhoto.comments.length === 0) && (
                        <p className="text-xs text-neutral-400 italic text-center py-2">No comments yet. Be the first!</p>
                      )}
                    </div>
                    {currentUser && (
                      <form onSubmit={handleAddComment} className="flex items-center gap-2 mt-2">
                        <input 
                          type="text" 
                          placeholder="Add a comment..." 
                          value={commentText}
                          onChange={(e) => setCommentText(e.target.value)}
                          className="flex-1 bg-neutral-100 border-none rounded-full px-4 py-2 text-xs focus:ring-2 focus:ring-brand-green outline-none"
                        />
                        <button type="submit" disabled={!commentText.trim()} className="bg-brand-green text-brand-yellow p-2 rounded-full disabled:opacity-50 hover:bg-green-900 transition-colors">
                          <Send className="w-3.5 h-3.5" />
                        </button>
                      </form>
                    )}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        </AnimatePresence>

        {photos.length > 1 && (
          <>
            <button onClick={handlePrev} className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 md:-translate-x-8 bg-white text-brand-green p-3 rounded-full shadow-lg border border-neutral-100 hover:scale-110 transition-transform z-10">
              <ChevronLeft className="w-6 h-6" />
            </button>
            <button onClick={handleNext} className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 md:translate-x-8 bg-white text-brand-green p-3 rounded-full shadow-lg border border-neutral-100 hover:scale-110 transition-transform z-10">
              <ChevronRight className="w-6 h-6" />
            </button>
          </>
        )}
      </div>
    </div>
  );
}

import React, { useState } from 'react';
import { 
  Activity, 
  FileText, 
  CheckSquare, 
  Users, 
  PhoneCall, 
  ArrowRight, 
  AlertCircle, 
  ExternalLink, 
  Heart, 
  Sparkles, 
  CheckCircle2, 
  Compass,
  MapPin,
  Bus,
  Car,
  Lock,
  Loader2,
  Calendar,
  Building2,
  ListTodo,
  Info
} from 'lucide-react';
import { db, handleFirestoreError, OperationType } from '../lib/backend';
import { collection, addDoc, serverTimestamp } from '../lib/backend';
import { type User as AuthUser } from '../lib/backend';
import { cn } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';

interface SsiDisabilityGuideProps {
  user: AuthUser | null;
  profile: any;
  onHelpSubmitted?: () => void;
}

export default function SsiDisabilityGuide({ user, profile, onHelpSubmitted }: SsiDisabilityGuideProps) {
  // Navigation internal steps
  const [activeStep, setActiveStep] = useState<number>(1);
  const [requestSubmitted, setRequestSubmitted] = useState<boolean>(false);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Form states for advocate connection
  const [contactName, setContactName] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [diagnosis, setDiagnosis] = useState('');
  const [unemployedMonths, setUnemployedMonths] = useState('12+ months');
  const [treatmentStatus, setTreatmentStatus] = useState<'yes' | 'no' | 'past'>('no');
  const [contactMethod, setContactMethod] = useState<'phone' | 'text' | 'shelter'>('phone');
  const [preferredShelter, setPreferredShelter] = useState('Homeless Alliance Day Center (1220 W 4th St)');

  // Step checklist memory (self-guided progress)
  const [stepsCompleted, setStepsCompleted] = useState<Record<number, boolean>>({
    1: false,
    2: false,
    3: false,
    4: false,
    5: false
  });

  const toggleStepComplete = (stepId: number) => {
    setStepsCompleted(prev => ({ ...prev, [stepId]: !prev[stepId] }));
  };

  const stepsDetails = [
    {
      id: 1,
      title: "Meet the Basic Criteria (Is SSI right for you?)",
      badge: "Step 1: Check Guidelines",
      short: "Confirm you qualify under standard or specialized SOAR guidelines.",
      content: (
        <div className="space-y-4">
          <p className="text-xs text-neutral-600 leading-relaxed font-medium">
            Social Security Administration (SSA) pays monthly benefits via <strong>SSI (Supplemental Security Income)</strong> and <strong>SSDI (Disability Insurance)</strong> to adults who are unable to work due to medical conditions. For psychiatric conditions, the criteria are specific:
          </p>
          
          <div className="bg-neutral-50 p-4 rounded-2xl border border-neutral-100 space-y-3">
            <h5 className="text-[11px] font-black text-neutral-700 uppercase tracking-wider flex items-center gap-1.5">
              <Info className="w-3.5 h-3.5 text-brand-green" /> Key Prerequisites:
            </h5>
            <ul className="space-y-2 text-xs text-neutral-600 font-medium">
              <li className="flex items-start gap-2">
                <span className="text-brand-green font-bold shrink-0">✔</span>
                <span><strong>Severe Mental Illness:</strong> Have a formal clinical diagnosis (e.g. Schizophrenia, Bipolar Disorder, Major Depressive Disorder, severe PTSD, or Schizoaffective Disorder) with marked symptoms.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-brand-green font-bold shrink-0">✔</span>
                <span><strong>Inability to Work:</strong> The mental illness must prevent you from performing "Substantial Gainful Activity" (earning more than approx. $1,550/month in 2026).</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-brand-green font-bold shrink-0">✔</span>
                <span><strong>Duration Metric:</strong> The impairment must have lasted, or be expected to last, for at least <strong>12 consecutive months</strong>, or result in death.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-brand-green font-bold shrink-0">✔</span>
                <span><strong>Un-housed Priority:</strong> If you are unhoused or at severe risk, you qualify for **SOAR**—a fast-track national protocol with a 70%+ approval rating compared to 28% for normal unguided claims.</span>
              </li>
            </ul>
          </div>

          <div className="bg-amber-50/50 p-4 rounded-2xl border border-amber-200/40 text-xs text-amber-900 font-medium leading-relaxed">
            <strong>Mental Health Fact:</strong> Getting a disability claim approved purely for mental illness is notoriously difficult alone because SSA requires specific psychiatric documentation showing how symptoms disrupt basic hygiene, social focus, and task follow-through. Working with a <strong>SOAR certified caseworker</strong> is highly recommended.
          </div>
        </div>
      )
    },
    {
      id: 2,
      title: "Connect with a Local SOAR Case Manager",
      badge: "Step 2: Get Advocate Support",
      short: "OKC has dedicated advocates who will handle 100% of the filing paperwork for you.",
      content: (
        <div className="space-y-4">
          <p className="text-xs text-neutral-600 leading-relaxed font-semibold">
            Do not try to file alone if you are unhoused! Oklahoma City is home to certified **SOAR (SSI/SSDI Outreach, Access, and Recovery)** case managers who assist for free. Here are the leading local networks carrying state-certified SOAR navigators:
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Homeless Alliance */}
            <div className="p-4 rounded-2xl bg-white border border-neutral-100 shadow-sm space-y-2">
              <div className="flex items-start justify-between">
                <span className="bg-emerald-100 text-emerald-800 text-[8px] font-black uppercase px-2 py-0.5 rounded">Primary OKC Hub</span>
              </div>
              <h5 className="text-xs font-black uppercase text-neutral-900">Homeless Alliance SOAR</h5>
              <p className="text-[10px] text-neutral-500 font-medium leading-normal">On-site case managers dedicated solely to guiding unhoused adults through SSI psychiatric filings.</p>
              <div className="pt-1.5 border-t border-neutral-100 flex flex-col gap-1 text-[10px] text-neutral-600 font-medium">
                <span className="flex items-center gap-1.5"><MapPin className="w-3 h-3 text-brand-green" /> 1220 W 4th St, OKC</span>
                <span className="flex items-center gap-1.5"><PhoneCall className="w-3 h-3 text-brand-green" /> (405) 415-8410</span>
              </div>
            </div>

            {/* NorthCare */}
            <div className="p-4 rounded-2xl bg-white border border-neutral-100 shadow-sm space-y-2">
              <div className="flex items-start justify-between">
                <span className="bg-blue-100 text-blue-800 text-[8px] font-black uppercase px-2 py-0.5 rounded">Mental Health Center</span>
              </div>
              <h5 className="text-xs font-black uppercase text-neutral-900">NorthCare Outpatient</h5>
              <p className="text-[10px] text-neutral-500 font-medium leading-normal">Comprehensive mental health clinic with a dedicated SSI team. They assist with both psychiatric treatment and financial support.</p>
              <div className="pt-1.5 border-t border-neutral-100 flex flex-col gap-1 text-[10px] text-neutral-600 font-medium">
                <span className="flex items-center gap-1.5"><MapPin className="w-3 h-3 text-brand-green" /> 2617 General Pershing, OKC</span>
                <span className="flex items-center gap-1.5"><PhoneCall className="w-3 h-3 text-brand-green" /> (405) 858-2700</span>
              </div>
            </div>

            {/* Red Rock */}
            <div className="p-4 rounded-2xl bg-white border border-neutral-100 shadow-sm space-y-2">
              <div className="flex items-start justify-between">
                <span className="bg-purple-100 text-purple-800 text-[8px] font-black uppercase px-2 py-0.5 rounded">Outpatient Care</span>
              </div>
              <h5 className="text-xs font-black uppercase text-neutral-900">Red Rock Behavioral</h5>
              <p className="text-[10px] text-neutral-500 font-medium leading-normal">Provides peer advocates, psychiatric assessment, medication management, and SOAR certified fast-tracking.</p>
              <div className="pt-1.5 border-t border-neutral-100 flex flex-col gap-1 text-[10px] text-neutral-600 font-medium">
                <span className="flex items-center gap-1.5"><MapPin className="w-3 h-3 text-brand-green" /> 4400 Lincoln Blvd, OKC</span>
                <span className="flex items-center gap-1.5"><PhoneCall className="w-3 h-3 text-brand-green" /> (405) 424-7711</span>
              </div>
            </div>

            {/* Pivot */}
            <div className="p-4 rounded-2xl bg-white border border-neutral-100 shadow-sm space-y-2">
              <div className="flex items-start justify-between">
                <span className="bg-amber-100 text-amber-800 text-[8px] font-black uppercase px-2 py-0.5 rounded">For Youth 16-24</span>
              </div>
              <h5 className="text-xs font-black uppercase text-neutral-900">Pivot OKC</h5>
              <p className="text-[10px] text-neutral-500 font-medium leading-normal">Supports homeless/unstable youth in transition. Special SSI guidance for young people experiencing mental illness.</p>
              <div className="pt-1.5 border-t border-neutral-100 flex flex-col gap-1 text-[10px] text-neutral-600 font-medium">
                <span className="flex items-center gap-1.5"><MapPin className="w-3 h-3 text-brand-green" /> 201 NE 50th St, OKC</span>
                <span className="flex items-center gap-1.5"><PhoneCall className="w-3 h-3 text-brand-green" /> (405) 235-7537</span>
              </div>
            </div>
          </div>

          <div className="p-4 bg-brand-green/5 border border-brand-green/10 rounded-2xl text-xs text-neutral-700 font-medium leading-relaxed">
            🌿 <strong>How SOAR helps you:</strong> They gather all your psychiatric records, pay for diagnostic psychiatric evaluations if you do not have current records, fill out every SSA form, write a compelling Medical Summary Report on your behalf, and stand with you at consultations.
          </div>
        </div>
      )
    },
    {
      id: 3,
      title: "Establish Treatment Records & Evaluation",
      badge: "Step 3: Clinical Dossier",
      short: "See community doctors and psychiatrists to compile active diagnosis evidence.",
      content: (
        <div className="space-y-4">
          <p className="text-xs text-neutral-600 leading-relaxed font-medium">
            Social Security cannot approve disability without medical evidence from a **licensed medical source** (such as an MD, DO, or licensed PhD psychologist). Here is exactly what is needed and how to secure it:
          </p>

          <div className="space-y-2">
            {[
              {
                num: "A",
                title: "Register for Outpatient Mental Health",
                desc: "Schedule regular appointments at NorthCare or Red Rock in OKC. Consistency is key! SSA looks for a pattern showing that despite taking prescribed medications and attending therapy, your symptoms still make regular work impossible."
              },
              {
                num: "B",
                title: "Consent to Information Release",
                desc: "Sign a HIPAA Release Form (Form SSA-827) with your SOAR caseworker so they can directly order and compile your outpatient treatment logs, emergency room entries, and hospital admission charts."
              },
              {
                num: "C",
                title: "Attend local Consultative Examinations (CE)",
                desc: "If SSA doesn't have enough treatment history, they will schedule a free medical/psychiatric exam. **You MUST attend this appointment**. Missing an SSA consultative exam results in an immediate automatic denial."
              }
            ].map(item => (
              <div key={item.num} className="p-3 bg-neutral-50 rounded-xl border border-neutral-100 flex gap-3">
                <span className="w-6 h-6 shrink-0 bg-brand-green text-brand-yellow font-black text-xs rounded-full flex items-center justify-center">{item.num}</span>
                <div>
                  <h6 className="text-[11px] font-black uppercase text-neutral-800 leading-none mb-1">{item.title}</h6>
                  <p className="text-[10px] text-neutral-500 font-medium leading-normal">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="p-3 bg-amber-50 rounded-xl border border-amber-200/50 text-xs text-amber-900 font-medium">
            💡 <strong>No health insurance?</strong> Check out our **Adults SoonerCare** section (tab above) first! By qualifying for Oklahoma Medicaid, all your clinical appointments, prescriptions, and psychiatric consults are 100% free, building a powerful medical evidence paper-trail for your Social Security claim.
          </div>
        </div>
      )
    },
    {
      id: 4,
      title: "Getting to Your Appointments (Transit & Ride Directory)",
      badge: "Step 4: Free Commuting Services",
      short: "Secure rides, bus tickets, and clinical transit systems to ensure you never miss a review.",
      content: (
        <div className="space-y-4">
          <p className="text-xs text-neutral-600 leading-relaxed font-medium">
            Getting to your psychiatric evaluations, doctor consultations, and SSA interviews is critical. Missing an appointment can ruin a year-long filing process. Use these **completely free** Oklahoma City transit and ride systems:
          </p>

          <div className="space-y-3">
            {/* SoonerRide */}
            <div className="bg-neutral-50 p-4 rounded-xl border border-neutral-150 relative overflow-hidden">
              <div className="absolute top-2 right-2 flex items-center gap-1.5">
                <span className="bg-emerald-100 text-emerald-800 text-[8px] font-black px-1.5 py-0.5 rounded">Medicaid Benefit</span>
              </div>
              <h5 className="text-xs font-black uppercase text-neutral-900 flex items-center gap-1.5 mb-1">
                <Car className="w-4 h-4 text-emerald-600" /> SoonerRide (NEMT Transportation)
              </h5>
              <p className="text-[10px] text-neutral-500 font-medium leading-relaxed">
                If you have SoonerCare (Oklahoma Medicaid), you qualify for **100% free round-trip rides** to your doctor, therapist, or consultative exams. They can arrange sedans, vans, or wheelchair transport.
              </p>
              <div className="mt-2 text-[10px] font-bold text-neutral-600 bg-white p-2 rounded-lg border border-neutral-100 inline-flex flex-col sm:flex-row gap-2 sm:gap-4">
                <span>Call to reserve (3 days ahead): <strong>1-877-405-RIDE (7433)</strong></span>
                <span>Hours: Mon - Sat (7AM - 7PM)</span>
              </div>
            </div>

            {/* EMBARK Passes */}
            <div className="bg-neutral-50 p-4 rounded-xl border border-neutral-150 relative overflow-hidden">
              <h5 className="text-xs font-black uppercase text-neutral-900 flex items-center gap-1.5 mb-1">
                <Bus className="w-4 h-4 text-brand-green" /> EMBARK Bus Passes & Transit
              </h5>
              <p className="text-[10px] text-neutral-500 font-medium leading-relaxed">
                Homeless Alliance Day Center and partner case managers distribute **free daily bus passes** to clients who need transportation to legal, medical, or disability application appointments in Oklahoma City.
              </p>
              <div className="mt-2 text-[10px] font-bold text-neutral-600 bg-white p-2 rounded-lg border border-neutral-100">
                <span>Pick-up location: <strong>Homeless Alliance (1220 W 4th St, OKC)</strong> during morning check-in.</span>
              </div>
            </div>

            {/* Medical Transport Modal Bridge */}
            <div className="p-3 rounded-xl bg-brand-green/5 border border-brand-green/10 flex items-center justify-between gap-3 text-xs">
              <div className="space-y-0.5">
                <span className="font-black text-brand-green uppercase text-[10px] block">App's Built-in Medical Transport</span>
                <span className="text-neutral-500 font-medium">Use our home dashboard grid to request a medical transport van right to you!</span>
              </div>
              <span className="text-[10px] font-black bg-brand-yellow text-brand-green px-2 py-1 rounded-lg uppercase tracking-wider shrink-0">Available on Home</span>
            </div>
          </div>
        </div>
      )
    },
    {
      id: 5,
      title: "File the Application & Wait for Your First Check",
      badge: "Step 5: File & Complete",
      short: "Formally submit your claims through SSA and receive retroactive backpay once approved.",
      content: (
        <div className="space-y-4">
          <p className="text-xs text-neutral-600 leading-relaxed font-semibold">
            Once medical documents and clinical summary letters are complete, your SOAR counselor will submit the application to Social Security. Here is what happens next during processing:
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="bg-neutral-50 p-3.5 rounded-2xl border border-neutral-100 text-center space-y-1.5">
              <span className="w-6 h-6 bg-brand-green/10 text-brand-green font-black text-xs rounded-full flex items-center justify-center mx-auto">1</span>
              <h6 className="text-[10px] font-black uppercase text-neutral-900 leading-none">DDS Review</h6>
              <p className="text-[9px] text-neutral-500 font-medium leading-normal">
                Oklahoma Disability Determination Services reviews the mental medical records to confirm functional limitations.
              </p>
            </div>

            <div className="bg-neutral-50 p-3.5 rounded-2xl border border-neutral-100 text-center space-y-1.5">
              <span className="w-6 h-6 bg-brand-green/10 text-brand-green font-black text-xs rounded-full flex items-center justify-center mx-auto">2</span>
              <h6 className="text-[10px] font-black uppercase text-neutral-900 leading-none">SOAR Fast-Track</h6>
              <p className="text-[9px] text-neutral-500 font-medium leading-normal">
                While typical adult claims take 6 to 12 months, SOAR-certified cases are frequently approved in <strong>under 60 - 90 days</strong>.
              </p>
            </div>

            <div className="bg-neutral-50 p-3.5 rounded-2xl border border-neutral-100 text-center space-y-1.5">
              <span className="w-6 h-6 bg-brand-green/10 text-brand-green font-black text-xs rounded-full flex items-center justify-center mx-auto">3</span>
              <h6 className="text-[10px] font-black uppercase text-neutral-900 leading-none">Disability Check & Backpay</h6>
              <p className="text-[9px] text-neutral-500 font-medium leading-normal">
                Upon approval, monthly checks are deposited, and you receive structural backpay covering months since your protective filing date.
              </p>
            </div>
          </div>

          <div className="bg-amber-50 rounded-2xl p-4 border border-amber-200/50 text-xs text-amber-900">
            📌 <strong>Important OKC SSA Locations for physical filings:</strong>
            <div className="mt-2 grid grid-cols-1 sm:grid-cols-2 gap-2 text-[10px] text-neutral-700">
              <div className="bg-white p-2.5 rounded-xl border border-amber-100">
                <strong className="block text-amber-950 uppercase mb-0.5">OKC South Office</strong>
                400 SW 89th St, Oklahoma City, OK 73139
                <span className="block font-black text-brand-green mt-1">📞 Toll-Free: (866) 331-5407</span>
              </div>
              <div className="bg-white p-2.5 rounded-xl border border-amber-100">
                <strong className="block text-amber-950 uppercase mb-0.5">OKC North Office</strong>
                2613 Urbandale Ln, Oklahoma City, OK 73120
                <span className="block font-black text-brand-green mt-1">📞 Toll-Free: (866) 331-5374</span>
              </div>
            </div>
          </div>
        </div>
      )
    }
  ];

  const handleSsiRequestSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!user) {
      setErrorMessage("Please sign in to submit an assistance request.");
      return;
    }

    if (!contactName.trim()) {
      setErrorMessage("Please enter your name.");
      return;
    }

    if (contactMethod !== 'shelter' && !contactPhone.trim()) {
      setErrorMessage("Please supply a contact phone number.");
      return;
    }

    setIsSubmitting(true);

    try {
      const summaryMsg = `[SSI/SSDI SOAR MENTAL ILLNESS REQUEST]
Name: ${contactName}
Contact Method: ${contactMethod.toUpperCase()} (${contactPhone || 'Shelter client'})
Self-Reported Psychiatric Diagnosis: ${diagnosis || 'Not specified'}
Duration of Unemployment: ${unemployedMonths}
Currently receiving clinic treatment? ${treatmentStatus.toUpperCase()}
${contactMethod === 'shelter' ? `Target Shelter Location: ${preferredShelter}` : ''}
Sent from verified digital advocate portal.`;

      // 1. Submit to general queue (requests compilation)
      await addDoc(collection(db, 'requests'), {
        userId: user.uid,
        type: 'Other',
        title: `Disability Nav: ${contactName}`,
        location: contactMethod === 'shelter' ? (preferredShelter.split(' (')[0]) : `OKC - ${contactPhone}`,
        description: summaryMsg,
        timestamp: serverTimestamp(),
        urgent: true,
        status: 'open'
      });

      // 2. Submit to dedicated ssi_requests collection (custom database tracking for SOAR caseworkers)
      await addDoc(collection(db, 'ssi_requests'), {
        userId: user.uid,
        userName: contactName,
        phone: contactPhone || 'Shelter Walk-in',
        conditionType: diagnosis || 'Mental illness client',
        status: 'pending',
        timestamp: serverTimestamp()
      });

      setRequestSubmitted(true);
      setContactName('');
      setContactPhone('');
      setDiagnosis('');
      
      if (onHelpSubmitted) {
        onHelpSubmitted();
      }
    } catch (err: any) {
      console.error("Error submitting SSI help ticket:", err);
      try {
        handleFirestoreError(err, OperationType.WRITE, 'ssi_requests');
      } catch (adapted: any) {
        setErrorMessage(`Failed to send. Details: ${adapted.message}`);
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="bg-white rounded-[2.5rem] border-2 border-brand-green/10 shadow-sm overflow-hidden flex flex-col">
      {/* Visual Header Banner */}
      <div className="bg-brand-green text-white p-6 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-brand-yellow/10 rounded-full blur-2xl -mr-10 -mt-10"></div>
        <div className="flex items-center gap-3 relative z-10">
          <div className="p-3 bg-brand-yellow/10 border border-brand-yellow/30 rounded-2xl text-brand-yellow">
            <Compass className="w-8 h-8" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="bg-brand-yellow text-brand-green text-[9px] font-black tracking-widest uppercase px-2 py-0.5 rounded-md">OKC SOAR PROGRAM</span>
              <span className="text-[9px] text-emerald-300 font-black tracking-[0.15em] uppercase">Mental Health Benefit</span>
            </div>
            <h3 className="text-xl font-black font-mission tracking-tight text-white uppercase leading-none mt-1">Social Security Disability Guide</h3>
            <p className="text-[11px] text-emerald-200/90 font-medium tracking-tight mt-0.5">Navigating SSI/SSDI psychiatric applications with dedicated Oklahoma advocates</p>
          </div>
        </div>
      </div>

      <div className="p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Side: Step checklist selection */}
        <div className="lg:col-span-5 space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-neutral-100">
            <span className="text-[10px] font-black text-neutral-400 uppercase tracking-wider">Interactive Tutorial Steps</span>
            <span className="text-[9px] font-black text-brand-green bg-emerald-50 px-2 py-0.5 rounded-md">SELF-GUIDED</span>
          </div>

          <div className="space-y-2">
            {stepsDetails.map(step => {
              const isActive = activeStep === step.id;
              const isDone = stepsCompleted[step.id];
              return (
                <div 
                  key={step.id}
                  className={cn(
                    "p-3 rounded-2xl border transition-all cursor-pointer flex items-start gap-3",
                    isActive 
                      ? "bg-brand-green/5 border-brand-green text-brand-green shadow-sm"
                      : "bg-white hover:bg-neutral-50/50 border-neutral-150"
                  )}
                  onClick={() => setActiveStep(step.id)}
                >
                  {/* Step Completion Checkcircle */}
                  <div 
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleStepComplete(step.id);
                    }}
                    className={cn(
                      "w-4 h-4 rounded-md border flex items-center justify-center transition-colors shrink-0 mt-0.5 cursor-pointer",
                      isDone 
                        ? "bg-brand-green border-brand-green text-brand-yellow" 
                        : "border-neutral-300 bg-white"
                    )}
                  >
                    {isDone && <CheckSquare className="w-3.5 h-3.5" />}
                  </div>
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-1.5 leading-none">
                      <span className="text-[9px] font-bold text-neutral-400 uppercase">{step.badge}</span>
                    </div>
                    <h5 className={cn("text-xs font-black uppercase tracking-tight leading-snug", isActive ? "text-brand-green" : "text-neutral-800")}>{step.title}</h5>
                    <p className="text-[10px] text-neutral-400 font-medium leading-normal line-clamp-1">{step.short}</p>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Quick link to application form panel */}
          <div className="bg-neutral-50 p-4 rounded-[1.75rem] border border-neutral-150 space-y-2 text-center">
            <span className="text-[9px] font-black text-neutral-400 uppercase tracking-widest block">Need a dedicated helper?</span>
            <p className="text-[10px] text-neutral-500 font-medium leading-relaxed">
              Facing difficulties filing or acquiring clinical treatment? Connect with an OKC therapist and SOAR agent directly.
            </p>
            <button
              onClick={() => setActiveStep(99)} // Use step 99 to refer to help forms!
              className={cn(
                "w-full py-2 px-3 rounded-xl font-black text-[10px] uppercase tracking-wider transition-all flex items-center justify-center gap-1.5",
                activeStep === 99 
                  ? "bg-brand-green text-brand-yellow" 
                  : "bg-brand-yellow text-brand-green hover:bg-yellow-400"
              )}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Connect with SSA Navigator</span>
            </button>
          </div>
        </div>

        {/* Right Side: Step active content container */}
        <div className="lg:col-span-12 xl:col-span-7 bg-neutral-50 p-6 rounded-[2rem] border border-neutral-200/50">
          <AnimatePresence mode="wait">
            {activeStep !== 99 ? (
              <motion.div
                key={activeStep}
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                transition={{ duration: 0.2 }}
                className="space-y-4"
              >
                {/* Header elements */}
                <div className="pb-3 border-b border-neutral-250 flex items-center justify-between">
                  <div>
                    <span className="bg-brand-green text-brand-yellow text-[9px] font-black uppercase px-2 py-0.5 rounded-md tracking-wider">
                      {stepsDetails[activeStep - 1].badge}
                    </span>
                    <h4 className="font-black text-neutral-900 text-sm uppercase mt-1 leading-snug">
                      {stepsDetails[activeStep - 1].title}
                    </h4>
                  </div>
                  <button
                    onClick={() => toggleStepComplete(activeStep)}
                    className={cn(
                      "px-3 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-wider transition-all",
                      stepsCompleted[activeStep] 
                        ? "bg-emerald-100 text-brand-green" 
                        : "bg-white text-neutral-500 hover:text-neutral-800 hover:bg-neutral-100 border border-neutral-200"
                    )}
                  >
                    {stepsCompleted[activeStep] ? "Marked Complete" : "Mark Complete"}
                  </button>
                </div>

                {/* Content body rendering */}
                <div>
                  {stepsDetails[activeStep - 1].content}
                </div>

                {/* Navigation actions */}
                <div className="pt-4 border-t border-neutral-250 flex justify-between items-center">
                  <span className="text-[10px] font-bold text-neutral-400">Step {activeStep} of 5</span>
                  <div className="flex gap-2">
                    {activeStep > 1 && (
                      <button
                        onClick={() => setActiveStep(activeStep - 1)}
                        className="px-4 py-2 border rounded-xl font-bold text-xs uppercase text-neutral-600 hover:bg-neutral-100 transition-colors"
                      >
                        Prev
                      </button>
                    )}
                    {activeStep < 5 ? (
                      <button
                        onClick={() => setActiveStep(activeStep + 1)}
                        className="px-4 py-2 bg-brand-green hover:bg-emerald-950 text-brand-yellow transition-colors rounded-xl font-black text-xs uppercase tracking-wider flex items-center gap-1"
                      >
                        <span>Next Step</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    ) : (
                      <button
                        onClick={() => setActiveStep(99)}
                        className="px-4 py-2 bg-brand-yellow hover:bg-yellow-400 text-brand-green transition-colors rounded-xl font-black text-xs uppercase tracking-wider flex items-center gap-1 shadow"
                      >
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>Link to Nav Assistance</span>
                      </button>
                    )}
                  </div>
                </div>
              </motion.div>
            ) : (
              /* Step 99: Live Advocate Nav Request Form */
              <motion.div
                key="navigator-form"
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                className="space-y-4"
              >
                <div className="pb-3 border-b border-neutral-250">
                  <span className="bg-brand-yellow text-brand-green text-[9px] font-black uppercase px-2 py-0.5 rounded-md tracking-wider">
                    Official Assistance Ticket
                  </span>
                  <h4 className="font-black text-neutral-900 text-sm uppercase mt-1 leading-snug">
                    Request an OKC SOAR Advocate
                  </h4>
                  <p className="text-[11px] text-neutral-500 font-medium">Struggling with psychological paperwork, medical charts, or ID cards? Let our verified outreach teams sit down and file for you.</p>
                </div>

                {!user ? (
                  <div className="p-5 bg-amber-50 rounded-2xl border border-amber-200 text-center space-y-3">
                    <Lock className="w-8 h-8 text-amber-600 mx-auto" />
                    <p className="text-xs font-bold text-amber-900 leading-relaxed uppercase">
                      You must sign in to submit a live advocate help request.
                    </p>
                    <p className="text-[10px] text-neutral-500 font-medium leading-normal max-w-xs mx-auto">
                      This protects candidate files and allows caseworkers to safely coordinate with you. Click "Sign In with Google" at the top of the app!
                    </p>
                  </div>
                ) : requestSubmitted ? (
                  <motion.div 
                    initial={{ scale: 0.95, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    className="p-6 bg-emerald-50 rounded-3xl border-2 border-emerald-200 text-center space-y-4"
                  >
                    <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center mx-auto text-brand-green shadow-sm">
                      <CheckCircle2 className="w-7 h-7" />
                    </div>
                    <div>
                      <h5 className="font-black text-emerald-950 uppercase text-sm">SSI Navigator Request Filed!</h5>
                      <p className="text-xs text-neutral-600 font-medium leading-relaxed mt-1">
                        We have logged your candidate details. A licensed case specialist representing **Homeless Alliance SOAR outreach** or outpatient clinics will make contact on their next shelter visit.
                      </p>
                    </div>
                    <button 
                      onClick={() => setRequestSubmitted(false)}
                      className="px-4 py-2 bg-white hover:bg-neutral-50 text-neutral-800 border rounded-xl font-bold text-xs uppercase"
                    >
                      File Another Ticket
                    </button>
                  </motion.div>
                ) : (
                  <form onSubmit={handleSsiRequestSubmit} className="space-y-3">
                    {errorMessage && (
                      <div className="p-3 bg-red-50 text-red-700 text-xs font-bold rounded-xl border border-red-200 flex items-center gap-2">
                        <AlertCircle className="w-4 h-4 shrink-0" />
                        <span>{errorMessage}</span>
                      </div>
                    )}

                    {/* Candidate Name */}
                    <div className="space-y-1">
                      <label className="text-[10px] font-black text-neutral-500 uppercase tracking-wider block">Candidate Full Name</label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Marcus Carter"
                        value={contactName}
                        onChange={(e) => setContactName(e.target.value)}
                        className="w-full px-3 py-2 bg-white border border-neutral-200 rounded-xl text-xs font-bold focus:outline-none focus:ring-1 focus:ring-brand-green leading-none"
                      />
                    </div>

                    {/* Self-reported mental illness diagnosis */}
                    <div className="space-y-1">
                      <label className="text-[10px] font-black text-neutral-500 uppercase tracking-wider block">Primary Psychiatric Condition / Symptoms</label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Bipolar, Schizophrenia, Severe PTSD, clinical anxiety"
                        value={diagnosis}
                        onChange={(e) => setDiagnosis(e.target.value)}
                        className="w-full px-3 py-2 bg-white border border-neutral-200 rounded-xl text-xs font-bold focus:outline-none focus:ring-1 focus:ring-brand-green leading-none"
                      />
                    </div>

                    {/* Contact details */}
                    <div className="space-y-1">
                      <label className="text-[10px] font-black text-neutral-500 uppercase tracking-wider block">How to safely contact you</label>
                      <div className="grid grid-cols-3 gap-1.5">
                        {[
                          { id: 'phone', label: 'By Call' },
                          { id: 'text', label: 'By Text' },
                          { id: 'shelter', label: 'Visit in Shelter' }
                        ].map(m => (
                          <button
                            key={m.id}
                            type="button"
                            onClick={() => setContactMethod(m.id as any)}
                            className={cn(
                              "py-2 rounded-xl border text-[9px] font-black uppercase transition-all text-center",
                              contactMethod === m.id 
                                ? "bg-brand-green text-brand-yellow border-brand-green" 
                                : "bg-white text-neutral-500 border-neutral-200 hover:bg-neutral-50"
                            )}
                          >
                            {m.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Dynamic contact field based on selection */}
                    {contactMethod !== 'shelter' ? (
                      <div className="space-y-1">
                        <label className="text-[10px] font-black text-neutral-500 uppercase tracking-wider block">Phone Number or Message Box Location</label>
                        <input
                          type="tel"
                          required
                          placeholder="e.g. (405) 555-0199 or specify where to reach you"
                          value={contactPhone}
                          onChange={(e) => setContactPhone(e.target.value)}
                          className="w-full px-3 py-2 bg-white border border-neutral-200 rounded-xl text-xs font-bold focus:outline-none focus:ring-1 focus:ring-brand-green leading-none"
                        />
                      </div>
                    ) : (
                      <div className="space-y-1">
                        <label className="text-[10px] font-black text-neutral-500 uppercase tracking-wider block">Target OKC Intake Shelter / Day Center</label>
                        <select
                          value={preferredShelter}
                          onChange={(e) => setPreferredShelter(e.target.value)}
                          className="w-full px-3 py-2 bg-white border border-neutral-200 rounded-xl text-xs font-bold focus:outline-none focus:ring-1 focus:ring-brand-green"
                        >
                          <option value="Homeless Alliance Day Center (1220 W 4th St)">Homeless Alliance Day Center (1220 W 4th St, OKC)</option>
                          <option value="City Rescue Mission (800 W California Ave)">City Rescue Mission (800 W California Ave, OKC)</option>
                          <option value="City Care Night Shelter (532 N Villa Ave)">City Care Night Shelter (532 N Villa Ave, OKC)</option>
                          <option value="Sisu Youth Services (3000 N Classen Blvd)">Sisu Youth Services (3000 N Classen Blvd, OKC - Youth Only)</option>
                        </select>
                      </div>
                    )}

                    {/* Treatment / Work details */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <label className="text-[10px] font-black text-neutral-500 uppercase tracking-wider block">Duration of Unemployment</label>
                        <select
                          value={unemployedMonths}
                          onChange={(e) => setUnemployedMonths(e.target.value)}
                          className="w-full px-3 py-2 bg-white border border-neutral-200 rounded-xl text-xs font-bold leading-none"
                        >
                          <option value="Less than 6 months">Under 6 months</option>
                          <option value="6 - 12 months">6 to 12 months</option>
                          <option value="12+ months">Over 12 months (Prerequisite standard)</option>
                          <option value="Never been employed">Never been employed</option>
                        </select>
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] font-black text-neutral-500 uppercase tracking-wider block">Currently receiving doctor care?</label>
                        <div className="flex gap-1.5 h-8">
                          {[
                            { id: 'yes', label: 'Yes' },
                            { id: 'no', label: 'No' },
                            { id: 'past', label: 'In past' }
                          ].map(t => (
                            <button
                              key={t.id}
                              type="button"
                              onClick={() => setTreatmentStatus(t.id as any)}
                              className={cn(
                                "flex-1 rounded-xl border text-[10px] font-black uppercase transition-all text-center",
                                treatmentStatus === t.id 
                                  ? "bg-brand-green text-brand-yellow border-brand-green" 
                                  : "bg-white text-neutral-500 border-neutral-200 hover:bg-neutral-50"
                              )}
                            >
                              {t.label}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>

                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full flex items-center justify-center gap-1.5 py-3 bg-brand-green hover:bg-emerald-950 transition-colors text-brand-yellow font-black text-xs uppercase tracking-wider rounded-2xl shadow-md disabled:opacity-50"
                    >
                      {isSubmitting ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin" />
                          <span>Filing with OKC SOAR Advocates...</span>
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-4 h-4 text-brand-yellow" />
                          <span>Submit Ticket & Request Connection</span>
                        </>
                      )}
                    </button>
                  </form>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}

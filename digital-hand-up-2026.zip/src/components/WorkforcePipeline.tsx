import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Wrench, CheckCircle2, PlayCircle, Lock, BookOpen, Briefcase, MapPin, Bus, UserCheck } from 'lucide-react';

const TRADE_JOB_LISTINGS = [
  {
    job_id: "job_okc_trade_042",
    position_title: "Apprentice Maintenance Technician Helper",
    trade_sector: "HVAC / Electrical / Plumbing",
    hourly_pay: 17.50,
    hiring_criteria: {
      requires_background_check: false,
      requires_high_school_diploma: false,
      provides_on_the_job_training: true,
      provides_tools: true
    },
    transportation: {
      accessible_by_embark_bus: true,
      nearest_bus_stop: "Route 011 - NW 23rd & Villa"
    },
    grant_tracking_tags: ["DOL_Workforce_2026", "Low_Barrier_Trades"]
  },
  {
    job_id: "job_okc_trade_043",
    position_title: "Ready Mix Concrete Handler - Entry Level",
    trade_sector: "Construction / Concrete",
    hourly_pay: 18.00,
    hiring_criteria: {
      requires_background_check: false,
      requires_high_school_diploma: false,
      provides_on_the_job_training: true,
      provides_tools: true
    },
    transportation: {
      accessible_by_embark_bus: true,
      nearest_bus_stop: "Route 013 - S Western Ave"
    },
    grant_tracking_tags: ["Path_To_Pro", "Low_Barrier_Trades"]
  }
];

export default function WorkforcePipeline() {
  const [activeStep, setActiveStep] = useState(1);

  return (
    <div className="space-y-6">
      {/* Header and Tracking */}
      <div className="bg-neutral-900 text-white rounded-3xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-8 opacity-10 pointer-events-none">
          <Wrench className="w-32 h-32" />
        </div>
        <div className="flex items-center gap-3 mb-6 relative z-10">
          <Wrench className="w-6 h-6 text-brand-yellow" />
          <h2 className="text-xl font-black font-mission tracking-wide">MY TRADES PIPELINE JOURNEY</h2>
        </div>
        
        <div className="bg-neutral-800 rounded-2xl p-4 border border-neutral-700 relative z-10">
          <p className="text-xs font-bold text-neutral-400 uppercase tracking-widest mb-1">Current Track</p>
          <p className="font-bold text-brand-yellow text-lg leading-tight">HVAC & Electrical Maintenance Pre-Apprentice</p>
        </div>

        {/* Steps */}
        <div className="mt-8 space-y-6 relative z-10">
          {/* Step 1 - Completed */}
          <div className="flex gap-4">
            <div className="flex flex-col items-center">
              <div className="w-8 h-8 rounded-full bg-emerald-500 flex items-center justify-center shrink-0">
                <CheckCircle2 className="w-5 h-5 text-white" />
              </div>
              <div className="w-0.5 h-full bg-neutral-700 my-1"></div>
            </div>
            <div className="pb-4">
              <h3 className="font-bold text-white text-lg leading-none mb-1">Basic Safety & Tool ID</h3>
              <p className="text-emerald-400 text-sm font-bold">Completed: May 12</p>
            </div>
          </div>

          {/* Step 2 - Active */}
          <div className="flex gap-4">
            <div className="flex flex-col items-center">
              <div className="w-8 h-8 rounded-full bg-brand-yellow flex items-center justify-center shrink-0">
                <PlayCircle className="w-5 h-5 text-neutral-900" />
              </div>
              <div className="w-0.5 h-full bg-neutral-700 my-1 pb-10"></div>
            </div>
            <div className="pb-4 w-full">
              <h3 className="font-bold text-white text-lg leading-none mb-1">EPA 608 Certification Prep</h3>
              <p className="text-brand-yellow text-sm font-bold mb-3">In Progress (Next Class: Tuesday at 10 AM)</p>
              
              <button className="w-full bg-neutral-800 hover:bg-neutral-700 text-brand-yellow border border-neutral-700 py-3 px-4 rounded-xl flex items-center justify-center gap-2 font-bold text-sm transition-all active:scale-95">
                <BookOpen className="w-4 h-4" />
                Open Free Study Guide & Practice Tests
              </button>
            </div>
          </div>

          {/* Step 3 - Locked */}
          <div className="flex gap-4">
            <div className="flex flex-col items-center">
              <div className="w-8 h-8 rounded-full bg-neutral-800 border-2 border-neutral-700 flex items-center justify-center shrink-0">
                <Lock className="w-4 h-4 text-neutral-500" />
              </div>
            </div>
            <div>
              <h3 className="font-bold text-neutral-500 text-lg leading-none mb-1">Ride-Match to Contractor Job Fair</h3>
              <p className="text-neutral-600 text-sm font-bold">Status: Locked until EPA Prep is 100% complete</p>
            </div>
          </div>
        </div>
      </div>

      {/* Active Contractor Job Board */}
      <div className="bg-white rounded-3xl p-6 shadow-lg border border-neutral-100">
        <div className="flex items-center gap-3 mb-6">
          <Briefcase className="w-6 h-6 text-brand-green" />
          <div>
            <h2 className="text-lg font-black font-mission tracking-wide text-neutral-900">ACTIVE CONTRACTOR JOB BOARD</h2>
            <p className="text-[10px] uppercase font-bold text-neutral-400 tracking-widest">Low-Barrier Entry Matches</p>
          </div>
        </div>

        <div className="space-y-4">
          {TRADE_JOB_LISTINGS.map((job) => (
            <motion.div 
              key={job.job_id}
              whileHover={{ scale: 1.02 }}
              className="border-2 border-neutral-100 rounded-2xl p-4 hover:border-brand-green/30 transition-all cursor-pointer group"
            >
              <div className="flex justify-between items-start mb-2">
                <h3 className="font-bold text-neutral-900 group-hover:text-brand-green transition-colors leading-tight">
                  {job.position_title}
                </h3>
                <span className="bg-emerald-50 text-emerald-700 text-xs font-black px-2 py-1 rounded border border-emerald-200 shrink-0">
                  ${job.hourly_pay.toFixed(2)}/hr
                </span>
              </div>
              
              <p className="text-sm text-neutral-500 mb-3">{job.trade_sector}</p>
              
              <div className="flex flex-wrap gap-2 mb-4">
                {job.hiring_criteria.provides_on_the_job_training && (
                  <span className="text-[10px] font-bold bg-brand-yellow/20 text-yellow-800 px-2 py-1 rounded">Paid Training Provided</span>
                )}
                {!job.hiring_criteria.requires_high_school_diploma && (
                  <span className="text-[10px] font-bold bg-brand-yellow/20 text-yellow-800 px-2 py-1 rounded">No HS Diploma Req.</span>
                )}
                {job.hiring_criteria.provides_tools && (
                  <span className="text-[10px] font-bold bg-brand-yellow/20 text-yellow-800 px-2 py-1 rounded">Tools Provided</span>
                )}
              </div>

              <div className="bg-neutral-50 p-3 rounded-xl border border-neutral-200">
                <div className="flex items-center gap-2 text-xs font-medium text-neutral-600 mb-1">
                  <Bus className="w-3.5 h-3.5 text-brand-green" />
                  {job.transportation.accessible_by_embark_bus ? 'Embark Bus Route:' : 'Transportation:'}
                </div>
                <p className="text-sm font-bold text-neutral-800">{job.transportation.nearest_bus_stop}</p>
              </div>
              
              <div className="mt-4 flex flex-wrap gap-1">
                {job.grant_tracking_tags.map(tag => (
                  <span key={tag} className="text-[9px] font-mono text-neutral-400 bg-neutral-100 px-1.5 py-0.5 rounded">
                    #{tag}
                  </span>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}

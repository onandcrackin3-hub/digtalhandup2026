import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Activity, Car, CheckCircle2, ChevronLeft, Clock, MapPin, Phone, FileText, AlertCircle, Info } from 'lucide-react';
import { cn } from '../lib/utils';
import MedicalTransportModal from './MedicalTransportModal';

interface MethadoneTreatmentProps {
  onBack: () => void;
}

export default function MethadoneTreatment({ onBack }: MethadoneTreatmentProps) {
  const [selectedClinic, setSelectedClinic] = useState<{ name: string; location: string } | null>(null);

  const clinics = [
    {
      name: "Rightway Medical",
      location: "3400 NW 39th St, Oklahoma City, OK 73112",
      phone: "(405) 949-9969",
      hours: "Mon-Fri: 5:00 AM - 1:00 PM, Sat: 6:00 AM - 9:00 AM",
      details: "Medication-Assisted Treatment (MAT) for opioid use disorder. Accepts SoonerCare."
    },
    {
      name: "Oklahoma City Treatment Center",
      location: "1236 NW 50th St, Oklahoma City, OK 73118",
      phone: "(405) 842-2615",
      hours: "Mon-Fri: 5:30 AM - 1:30 PM, Sat: 6:00 AM - 8:30 AM",
      details: "Provides Methadone and Buprenorphine treatment. Accepts SoonerCare."
    },
    {
      name: "Southern Hills Treatment Center",
      location: "5350 S Western Ave #500, Oklahoma City, OK 73109",
      phone: "(405) 631-4131",
      hours: "Mon-Fri: 5:30 AM - 11:30 AM, Sat: 6:00 AM - 8:30 AM",
      details: "Opioid addiction treatment services. Accepts SoonerCare."
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <button 
          onClick={onBack}
          className="bg-white hover:bg-neutral-50 p-2 rounded-full border border-neutral-200 transition-colors shadow-sm"
        >
          <ChevronLeft className="w-5 h-5 text-neutral-600" />
        </button>
        <div>
          <h2 className="text-2xl font-black text-brand-green italic uppercase tracking-tighter">Substance Use Treatment</h2>
          <p className="text-[10px] font-black text-brand-yellow uppercase tracking-widest bg-brand-green px-2 py-0.5 rounded-full inline-block">Methadone & SoonerRide</p>
        </div>
      </div>

      <div className="bg-white border-t-8 border-orange-500 rounded-[2rem] p-6 sm:p-8 shadow-sm space-y-8">
        
        {/* Intro */}
        <div className="space-y-4">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 bg-orange-100 rounded-2xl flex items-center justify-center shrink-0">
              <Activity className="w-6 h-6 text-orange-600" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-neutral-900 leading-tight">Medication-Assisted Treatment (MAT)</h3>
              <p className="text-neutral-600 text-sm mt-1 leading-relaxed">
                Treatment centers in OKC can help you overcome opioid dependence using FDA-approved medications like Methadone and Suboxone. If you have SoonerCare, you can also schedule free rides to and from your daily appointments via SoonerRide.
              </p>
            </div>
          </div>
        </div>

        {/* Action Steps */}
        <div className="space-y-4">
          <h4 className="font-black text-neutral-900 uppercase tracking-tight text-sm">How to get started:</h4>
          
          <div className="space-y-3">
            <div className="bg-neutral-50 border border-neutral-100 p-4 rounded-2xl flex gap-4">
              <div className="w-8 h-8 rounded-full bg-white font-black text-brand-green shadow-sm flex items-center justify-center shrink-0 border border-neutral-200">1</div>
              <div>
                <h5 className="font-bold text-neutral-900">Choose a Clinic & Call</h5>
                <p className="text-sm text-neutral-600 mt-1">Select a state-certified clinic from the list below and call them to schedule your initial intake appointment.</p>
              </div>
            </div>
            
            <div className="bg-neutral-50 border border-neutral-100 p-4 rounded-2xl flex gap-4">
              <div className="w-8 h-8 rounded-full bg-white font-black text-brand-green shadow-sm flex items-center justify-center shrink-0 border border-neutral-200">2</div>
              <div>
                <h5 className="font-bold text-neutral-900">Complete the Intake</h5>
                <p className="text-sm text-neutral-600 mt-1">The first appointment usually takes 2-3 hours. You will meet with a doctor and a counselor to set up your treatment plan.</p>
              </div>
            </div>
            
            <div className="bg-neutral-50 border border-neutral-100 p-4 rounded-2xl flex gap-4">
              <div className="w-8 h-8 rounded-full bg-white font-black text-brand-green shadow-sm flex items-center justify-center shrink-0 border border-neutral-200">3</div>
              <div>
                <h5 className="font-bold text-neutral-900">Schedule SoonerRide</h5>
                <p className="text-sm text-neutral-600 mt-1">Once you know your daily dosing schedule, you can book a recurring ride with SoonerRide.</p>
              </div>
            </div>
          </div>
        </div>

        {/* Clinics List */}
        <div className="space-y-4 pt-4 border-t border-neutral-100">
          <h4 className="font-black text-neutral-900 uppercase tracking-tight text-sm flex items-center gap-2">
            <MapPin className="w-4 h-4 text-orange-500" />
            OKC Methadone Clinics
          </h4>
          
          <div className="grid grid-cols-1 gap-4">
            {clinics.map((clinic, index) => (
              <div key={index} className="border border-neutral-200 rounded-2xl p-5 hover:border-orange-300 transition-colors shadow-sm bg-white">
                <h5 className="font-black text-lg text-neutral-900">{clinic.name}</h5>
                <div className="mt-3 space-y-2">
                  <div className="flex items-start gap-2 text-sm text-neutral-600">
                    <MapPin className="w-4 h-4 mt-0.5 shrink-0 text-neutral-400" />
                    <span>{clinic.location}</span>
                  </div>
                  <div className="flex items-start gap-2 text-sm text-neutral-600">
                    <Phone className="w-4 h-4 mt-0.5 shrink-0 text-neutral-400" />
                    <a href={`tel:${clinic.phone.replace(/\D/g, '')}`} className="text-brand-green font-bold hover:underline">{clinic.phone}</a>
                  </div>
                  <div className="flex items-start gap-2 text-sm text-neutral-600">
                    <Clock className="w-4 h-4 mt-0.5 shrink-0 text-neutral-400" />
                    <span>{clinic.hours}</span>
                  </div>
                </div>
                
                <div className="mt-4 p-3 bg-neutral-50 rounded-xl text-xs text-neutral-600 border border-neutral-100">
                  {clinic.details}
                </div>
                
                <button 
                  onClick={() => setSelectedClinic({ name: clinic.name, location: clinic.location })}
                  className="mt-4 w-full bg-brand-yellow hover:bg-yellow-400 text-neutral-900 py-3 rounded-xl font-bold flex items-center justify-center gap-2 transition-colors border border-brand-yellow shadow-sm"
                >
                  <Car className="w-4 h-4" />
                  Book SoonerRide to this Clinic
                </button>
              </div>
            ))}
          </div>
        </div>
        
        {/* SoonerRide Requirements */}
        <div className="bg-brand-green/5 border border-brand-green/20 rounded-2xl p-5 space-y-4">
          <div className="flex items-center gap-2 text-brand-green font-black uppercase tracking-widest text-xs">
            <Info className="w-4 h-4" />
            SoonerRide Requirements
          </div>
          <ul className="space-y-3">
            <li className="flex items-start gap-2 text-sm text-neutral-700">
              <CheckCircle2 className="w-4 h-4 text-brand-green shrink-0 mt-0.5" />
              <span>You must have active SoonerCare (Medicaid) coverage.</span>
            </li>
            <li className="flex items-start gap-2 text-sm text-neutral-700">
              <CheckCircle2 className="w-4 h-4 text-brand-green shrink-0 mt-0.5" />
              <span><strong>3-Business-Day Notice:</strong> You must schedule your ride at least three business days before your appointment.</span>
            </li>
            <li className="flex items-start gap-2 text-sm text-neutral-700">
              <CheckCircle2 className="w-4 h-4 text-brand-green shrink-0 mt-0.5" />
              <span>Have your SoonerCare ID, the clinic's exact address, and your appointment time ready when calling.</span>
            </li>
          </ul>
        </div>

      </div>

      {/* NEMT Ride Booking Modal (Reusing existing component) */}
      {selectedClinic && (
        <MedicalTransportModal
          isOpen={true}
          onClose={() => setSelectedClinic(null)}
          clinicName={selectedClinic.name}
          clinicAddress={selectedClinic.location}
        />
      )}
    </div>
  );
}

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShieldCheck, ArrowRight, Home, Users, AlertTriangle, FileText, CheckCircle2, Factory } from 'lucide-react';
import { cn } from '../lib/utils';

interface DiversionProps {
  onRoute: (route: string) => void;
}

export default function DiversionScreening({ onRoute }: DiversionProps) {
  const [step, setStep] = useState(0);
  const [hasEviction, setHasEviction] = useState<boolean | null>(null);
  const [daysUntilHomeless, setDaysUntilHomeless] = useState<number | null>(null);
  const [hasFamilySupport, setHasFamilySupport] = useState<boolean | null>(null);
  const [result, setResult] = useState<any>(null);

  const evaluateRisk = () => {
    if (hasEviction && daysUntilHomeless !== null && daysUntilHomeless <= 7 && !hasFamilySupport) {
      setResult({
        tier: "CRITICAL RISK",
        action_button: "Connect to Immediate Emergency Rental Funds",
        provider_route: "Legal Aid Services of Oklahoma (Eviction Defense)",
        grant_metric_track: "eviction_prevented_triage",
        color: "red"
      });
    } else if (daysUntilHomeless !== null && daysUntilHomeless <= 30) {
      setResult({
        tier: "MODERATE RISK",
        action_button: "Access Utility Assistance & Mediation",
        provider_route: "Community Action Agency Diversion Program",
        grant_metric_track: "diversion_stabilization_triage",
        color: "amber"
      });
    } else {
      setResult({
        tier: "STABLE / STAGE 1",
        action_button: "Browse Standard Affordable Housing Directory",
        provider_route: "Standard Housing Resource Network",
        grant_metric_track: "standard_resource_view",
        color: "emerald"
      });
    }
    setStep(3);
  };

  return (
    <div className="bg-white rounded-3xl shadow-lg border border-neutral-100 overflow-hidden">
      <div className="bg-brand-green p-5 text-white flex items-center gap-3">
         <ShieldCheck className="w-8 h-8 text-brand-yellow" />
         <div>
           <h2 className="text-xl font-black font-mission tracking-wide">HUD Diversion Screening</h2>
           <p className="text-xs text-brand-yellow/80 font-bold tracking-widest uppercase">Early Intervention Triage</p>
         </div>
      </div>
      
      <div className="p-6">
        <AnimatePresence mode="wait">
          {step === 0 && (
            <motion.div
              key="step0"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-4"
            >
              <h3 className="text-lg font-bold text-neutral-900 leading-tight">
                Are you currently holding an official eviction notice from a court or landlord?
              </h3>
              <div className="flex gap-3">
                <button 
                  onClick={() => { setHasEviction(true); setStep(1); }}
                  className="flex-1 py-3 rounded-xl border-2 border-neutral-200 font-bold hover:bg-neutral-50 active:scale-95 transition-all text-neutral-800"
                >
                  Yes
                </button>
                <button 
                  onClick={() => { setHasEviction(false); setStep(1); }}
                  className="flex-1 py-3 rounded-xl border-2 border-neutral-200 font-bold hover:bg-neutral-50 active:scale-95 transition-all text-neutral-800"
                >
                  No
                </button>
              </div>
            </motion.div>
          )}

          {step === 1 && (
            <motion.div
              key="step1"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-4"
            >
              <h3 className="text-lg font-bold text-neutral-900 leading-tight">
                How many days until you potentially lose your current housing?
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {[7, 30, 90].map((days) => (
                  <button 
                    key={days}
                    onClick={() => { setDaysUntilHomeless(days); setStep(2); }}
                    className="py-3 rounded-xl border-2 border-neutral-200 font-bold hover:bg-neutral-50 active:scale-95 transition-all text-neutral-800"
                  >
                    {days === 90 ? '30+ Days' : `Under ${days} Days`}
                  </button>
                ))}
              </div>
            </motion.div>
          )}

          {step === 2 && (
            <motion.div
              key="step2"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-4"
            >
              <h3 className="text-lg font-bold text-neutral-900 leading-tight">
                Do you have family or close friends who could safely host you temporarily?
              </h3>
              <div className="flex gap-3">
                <button 
                  onClick={() => { setHasFamilySupport(true); evaluateRisk(); }}
                  className="flex-1 py-3 rounded-xl border-2 border-neutral-200 font-bold hover:bg-neutral-50 active:scale-95 transition-all text-neutral-800"
                >
                  Yes
                </button>
                <button 
                  onClick={() => { setHasFamilySupport(false); evaluateRisk(); }}
                  className="flex-1 py-3 rounded-xl border-2 border-neutral-200 font-bold hover:bg-neutral-50 active:scale-95 transition-all text-neutral-800"
                >
                  No
                </button>
              </div>
            </motion.div>
          )}

          {step === 3 && result && (
            <motion.div
              key="step3"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="space-y-6"
            >
              <div className={cn(
                "p-4 rounded-2xl border-l-4",
                result.color === 'red' ? 'bg-red-50 border-red-500' :
                result.color === 'amber' ? 'bg-amber-50 border-amber-500' :
                'bg-emerald-50 border-emerald-500'
              )}>
                <div className="flex items-center gap-2 mb-2">
                  <AlertTriangle className={cn("w-5 h-5", `text-${result.color}-600`)} />
                  <span className={cn("font-black tracking-widest uppercase text-sm", `text-${result.color}-800`)}>
                    {result.tier}
                  </span>
                </div>
                <p className="text-sm font-medium text-neutral-700">
                  Based on your responses, we are flagging this intake as <span className="font-bold">{result.tier}</span>. 
                  (Tracking Metric: <code className="bg-white px-1 text-xs rounded text-neutral-500">{result.grant_metric_track}</code>)
                </p>
              </div>

              <div className="bg-neutral-50 rounded-2xl p-4 border border-neutral-200">
                <p className="text-xs font-bold text-neutral-400 uppercase tracking-widest mb-1">Recommended Provider Route</p>
                <p className="font-bold text-neutral-800 text-lg flex items-center gap-2">
                   <Home className="w-5 h-5 text-neutral-500" />
                   {result.provider_route}
                </p>
              </div>

              <button 
                onClick={() => onRoute(result.provider_route)}
                className={cn(
                  "w-full py-4 rounded-xl font-black text-white flex items-center justify-center gap-2 transition-all active:scale-95 shadow-lg",
                  result.color === 'red' ? 'bg-red-600 hover:bg-red-700 shadow-red-600/30' :
                  result.color === 'amber' ? 'bg-amber-600 hover:bg-amber-700 shadow-amber-600/30' :
                  'bg-emerald-600 hover:bg-emerald-700 shadow-emerald-600/30'
                )}
              >
                {result.action_button}
                <ArrowRight className="w-5 h-5" />
              </button>
              
              <div className="text-center">
                <button 
                  onClick={() => { setStep(0); setHasEviction(null); setDaysUntilHomeless(null); setHasFamilySupport(null); }}
                  className="text-xs font-bold text-neutral-400 hover:text-neutral-600 uppercase tracking-widest"
                >
                  Start Over
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

import React, { useState } from 'react';
import { 
  Activity, 
  FileText, 
  CheckSquare, 
  Users, 
  PhoneCall, 
  ArrowRight, 
  AlertCircle, 
  ExternalLink, 
  Heart, 
  Sparkles, 
  CheckCircle2, 
  Calculator, 
  Bookmark,
  Calendar,
  Lock,
  Loader2,
  ListTodo
} from 'lucide-react';
import { db, handleFirestoreError, OperationType } from '../lib/backend';
import { collection, addDoc, serverTimestamp } from '../lib/backend';
import { type User as AuthUser } from '../lib/backend';
import { cn } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';

interface SoonercareAssistantProps {
  user: AuthUser | null;
  profile: any;
  onHelpSubmitted?: () => void;
}

export default function SoonercareAssistant({ user, profile, onHelpSubmitted }: SoonercareAssistantProps) {
  // Navigation internal tabs
  const [panelTab, setPanelTab] = useState<'eligibility' | 'checklist' | 'apply' | 'request'>('eligibility');

  // Eligibility Estimator State
  const [householdSize, setHouseholdSize] = useState<number>(1);
  const [monthlyIncome, setMonthlyIncome] = useState<string>('');
  const [residesInOK, setResidesInOK] = useState<boolean | null>(true);
  const [ageRange, setAgeRange] = useState<boolean | null>(true); // 19-64
  const [isUSCitizen, setIsUSCitizen] = useState<boolean | null>(true);
  
  // Assistance Request Form State
  const [contactName, setContactName] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [contactMethod, setContactMethod] = useState<'phone' | 'text' | 'shelter' | 'other'>('phone');
  const [shelterDetails, setShelterDetails] = useState('');
  const [roadblocks, setRoadblocks] = useState<string[]>([]);
  const [additionalDetails, setAdditionalDetails] = useState('');
  const [isSubmittingHelp, setIsSubmittingHelp] = useState(false);
  const [helpSuccess, setHelpSuccess] = useState(false);
  const [validationError, setValidationError] = useState<string | null>(null);

  // Pre-compiled Oklahoma Federal Poverty Level Guidelines for 2025/2026 (138% FPL)
  const getIncomeLimit = (size: number) => {
    // 138% of FPL
    const bases = [0, 1732, 2351, 2970, 3588, 4207, 4826, 5445, 6064];
    if (size <= 8) return bases[size];
    return bases[8] + (size - 8) * 619;
  };

  const selectedLimit = getIncomeLimit(householdSize);
  const numericIncome = parseFloat(monthlyIncome) || 0;
  const isIncomeWithinLimit = numericIncome <= selectedLimit;

  // Checklist of documents
  const [checkedDocs, setCheckedDocs] = useState<Record<string, boolean>>({
    ssn: false,
    id: false,
    residency: false,
    income: false,
    status: false
  });

  const toggleDoc = (key: string) => {
    setCheckedDocs(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const handleToggleRoadblock = (block: string) => {
    if (roadblocks.includes(block)) {
      setRoadblocks(prev => prev.filter(r => r !== block));
    } else {
      setRoadblocks(prev => [...prev, block]);
    }
  };

  const handleHelpSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setValidationError(null);

    if (!user) {
      setValidationError("Please sign in to submit a request for local SoonerCare assistance.");
      return;
    }

    if (!contactName.trim()) {
      setValidationError("Please enter your name.");
      return;
    }

    if (contactMethod !== 'shelter' && !contactPhone.trim()) {
      setValidationError("Please provide a phone number so our local advocates can reach out.");
      return;
    }

    setIsSubmittingHelp(true);

    try {
      const eligibilitySummary = `SoonerCare Eligibility Est: Household Size ${householdSize}, Est Income: $${monthlyIncome || '0'}/mo. Meets OK expansion limit? ${isIncomeWithinLimit ? 'Yes' : 'No'}. Age 19-64? ${ageRange ? 'Yes' : 'No'}. OK Resident? ${residesInOK ? 'Yes' : 'No'}.`;
      const docStatus = `Document Readiness: ${Object.entries(checkedDocs).map(([k, v]) => `${k}: ${v ? 'Ready' : 'Missing'}`).join(', ')}`;
      
      const compositeDescription = `[SOONERCARE APPLICATION HELP]
Name: ${contactName}
Preferred Contact: ${contactMethod.toUpperCase()} (${contactPhone || 'N/A'})
${contactMethod === 'shelter' ? `Preferred Shelter Meeting Location: ${shelterDetails || 'Homeless Alliance Westtown Center'}` : ''}
Specific Roadblocks: ${roadblocks.length > 0 ? roadblocks.join(', ') : 'None selected'}
Additional notes: ${additionalDetails || 'None provided'}

--- Auto Screening Stats ---
${eligibilitySummary}
${docStatus}`;

      // We fit this directly into the existing verified SupportRequest schema
      // This maps cleanly to allow create: if isVerified() && isValidId(requestId) && isValidRequest(incoming());
      // Wait, is the user verified? isVerified() is isSignedIn() && request.auth.token.email_verified == true
      // To ensure all users can apply, let's submit it. If the user doesn't have an email_verified == true (e.g., anonymous or unverified google accounts), we should verify if we can submit it.
      // Wait, let's double check if we can write a clean request or fallback to local guide if write fails.
      await addDoc(collection(db, 'requests'), {
        userId: user.uid,
        type: 'Other', // Matches enum: ["Food", "Supplies", "Transport", "Other"]
        title: `SoonerCare Nav: ${contactName}`,
        location: contactMethod === 'shelter' ? (shelterDetails || "Homeless Alliance OKC") : `OKC - ${contactPhone}`,
        description: compositeDescription,
        timestamp: serverTimestamp(),
        urgent: true,
        status: 'open' // Enums: ["open", "pending", "fulfilled", "cancelled"]
      });

      // Also store reference in dedicated soonercare_requests collection
      await addDoc(collection(db, 'soonercare_requests'), {
        userId: user.uid,
        userName: contactName,
        phone: contactPhone || 'Shelter client',
        subgroup: roadblocks.length > 0 ? roadblocks.join(', ') : 'No roadblocks selected',
        status: 'pending',
        timestamp: serverTimestamp()
      });

      setHelpSuccess(true);
      setContactName('');
      setContactPhone('');
      setAdditionalDetails('');
      setRoadblocks([]);
      
      if (onHelpSubmitted) {
        onHelpSubmitted();
      }
    } catch (err: any) {
      console.error("Error submitting SoonerCare help request:", err);
      try {
        handleFirestoreError(err, OperationType.WRITE, 'requests');
      } catch (adaptedError: any) {
        setValidationError(`Submission incomplete. (Advocate services require a verified user account). Details: ${adaptedError.message}`);
      }
    } finally {
      setIsSubmittingHelp(false);
    }
  };

  return (
    <div className="bg-white rounded-[2.5rem] border-2 border-brand-green/10 shadow-sm overflow-hidden flex flex-col">
      {/* Brand Header Banner */}
      <div className="bg-brand-green text-white p-6 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-brand-yellow/10 rounded-full blur-2xl -mr-10 -mt-10"></div>
        <div className="flex items-center gap-3 relative z-10">
          <div className="p-3 bg-brand-yellow/10 border border-brand-yellow/30 rounded-2xl text-brand-yellow">
            <Activity className="w-8 h-8" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="bg-brand-yellow text-brand-green text-[9px] font-black tracking-widest uppercase px-2 py-0.5 rounded-md">OKLAHOMA</span>
              <span className="text-[9px] text-emerald-300 font-black tracking-[0.15em] uppercase">Medicaid Expansion</span>
            </div>
            <h3 className="text-xl font-black font-mission tracking-tight text-white uppercase leading-none mt-1">Adults SoonerCare</h3>
            <p className="text-[11px] text-emerald-200/90 font-medium tracking-tight mt-0.5">Guided application assistant & OKC local enrollment bridge</p>
          </div>
        </div>
      </div>

      {/* Navigation Subtabs */}
      <div className="flex border-b border-neutral-100 bg-neutral-50 px-3 py-2 gap-1.5 overflow-x-auto scrollbar-none">
        {[
          { id: 'eligibility', label: '1. Am I Eligible?', icon: Calculator },
          { id: 'checklist', label: '2. Prepare Docs', icon: ListTodo },
          { id: 'apply', label: '3. How to Apply', icon: ArrowRight },
          { id: 'request', label: '4. Navigator Help', icon: Sparkles }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setPanelTab(tab.id as any)}
            className={cn(
              "flex items-center gap-1.5 px-3 py-2 rounded-xl text-[11px] font-black uppercase tracking-wider transition-all whitespace-nowrap",
              panelTab === tab.id 
                ? "bg-white text-brand-green shadow-sm border border-brand-green/10" 
                : "text-neutral-500 hover:text-neutral-800 hover:bg-neutral-100"
            )}
          >
            <tab.icon className={cn("w-3.5 h-3.5", panelTab === tab.id ? "text-brand-green" : "text-neutral-400")} />
            {tab.label}
          </button>
        ))}
      </div>

      {/* Main Panel Content */}
      <div className="p-6">
        <AnimatePresence mode="wait">
          {panelTab === 'eligibility' && (
            <motion.div
              key="eligibility"
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 10 }}
              className="space-y-5"
            >
              <div className="space-y-1">
                <h4 className="font-black text-neutral-900 text-sm uppercase tracking-tight">SoonerCare Eligibility Estimator (Ages 19-64)</h4>
                <p className="text-xs text-neutral-500 font-medium">Under Oklahoma Medicaid Expansion, low-income adults now qualify for full healthcare. Check if you likely meet the metrics:</p>
              </div>

              {/* Household size */}
              <div className="space-y-2 bg-neutral-50 p-4 rounded-2xl border border-neutral-100">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-neutral-700 uppercase tracking-wider">Household Size</span>
                  <span className="text-xs font-black text-brand-green bg-emerald-50 px-2.5 py-1 rounded-lg border border-brand-green/15">{householdSize} {householdSize === 1 ? 'Person' : 'People'}</span>
                </div>
                <input 
                  type="range" 
                  min="1" 
                  max="8" 
                  value={householdSize} 
                  onChange={(e) => setHouseholdSize(parseInt(e.target.value))}
                  className="w-full accent-brand-green h-2 bg-neutral-200 rounded-lg cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-neutral-400 font-black">
                  <span>1</span>
                  <span>2</span>
                  <span>3</span>
                  <span>4</span>
                  <span>5</span>
                  <span>6</span>
                  <span>7</span>
                  <span>8+</span>
                </div>
              </div>

              {/* Estimator Income Input */}
              <div className="space-y-2 bg-neutral-50 p-4 rounded-2xl border border-neutral-100">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-neutral-700 uppercase tracking-wider">Estimated Monthly Income</span>
                  <span className="text-xs font-black text-neutral-500">Gross (Before Taxes)</span>
                </div>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-neutral-400 font-black text-sm">$</span>
                  <input
                    type="number"
                    placeholder="Enter monthly income (e.g., 1200 or 0)"
                    value={monthlyIncome}
                    onChange={(e) => setMonthlyIncome(e.target.value)}
                    className="w-full pl-8 pr-4 py-2.5 bg-white border border-neutral-200 rounded-xl leading-tight text-sm font-black text-neutral-800 placeholder:text-neutral-400 focus:outline-none focus:ring-1 focus:ring-brand-green focus:border-brand-green"
                  />
                </div>
                {monthlyIncome && (
                  <div className="text-[11px] font-bold text-neutral-400 text-right">
                    Approx. ${((parseFloat(monthlyIncome) || 0) * 12).toLocaleString()} / year
                  </div>
                )}
              </div>

              {/* Basic requirements toggles */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setResidesInOK(p => !p)}
                  className={cn(
                    "p-3 rounded-2xl border flex flex-col items-center justify-center text-center gap-1 transition-all",
                    residesInOK ? "bg-emerald-50/50 border-brand-green/30 text-brand-green" : "border-neutral-200/80 text-neutral-400"
                  )}
                >
                  <span className="text-[10px] font-black uppercase tracking-widest leading-none">Oklahoma Resident</span>
                  <span className="text-xs font-black uppercase">{residesInOK ? 'Yes' : 'No'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setAgeRange(p => !p)}
                  className={cn(
                    "p-3 rounded-2xl border flex flex-col items-center justify-center text-center gap-1 transition-all",
                    ageRange ? "bg-emerald-50/50 border-brand-green/30 text-brand-green" : "border-neutral-200/80 text-neutral-400"
                  )}
                >
                  <span className="text-[10px] font-black uppercase tracking-widest leading-none">Age Range 19-64</span>
                  <span className="text-xs font-black uppercase">{ageRange ? 'Yes (19-64)' : 'No (Other)'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setIsUSCitizen(p => !p)}
                  className={cn(
                    "p-3 rounded-2xl border flex flex-col items-center justify-center text-center gap-1 transition-all",
                    isUSCitizen ? "bg-emerald-50/50 border-brand-green/30 text-brand-green" : "border-neutral-200/80 text-neutral-400"
                  )}
                >
                  <span className="text-[10px] font-black uppercase tracking-widest leading-none">Citizen / Eligible</span>
                  <span className="text-xs font-black uppercase">{isUSCitizen ? 'Yes' : 'No'}</span>
                </button>
              </div>

              {/* Result Callout Dashboard */}
              <div className="p-5 rounded-3xl border border-neutral-200 shadow-sm bg-neutral-50 space-y-3">
                <div className="flex items-center justify-between border-b border-neutral-200 pb-3">
                  <span className="text-xs font-black text-neutral-500 uppercase tracking-widest">Oklahoma Medicaid Income Standard</span>
                  <span className="text-xs font-black text-neutral-900">${selectedLimit.toLocaleString()} / month</span>
                </div>

                {/* Eligibility Output Verdict */}
                {residesInOK && ageRange && isUSCitizen && isIncomeWithinLimit ? (
                  <div className="space-y-2">
                    <div className="flex items-center gap-2.5 text-brand-green">
                      <CheckCircle2 className="w-5 h-5 shrink-0" />
                      <span className="text-sm font-black uppercase tracking-tight">Highly Likely Eligible!</span>
                    </div>
                    <p className="text-xs text-neutral-600 font-medium leading-relaxed">
                      Your household size ({householdSize}) and gross income (${numericIncome || '0'}/mo) fall <strong>below</strong> the expansion cap of <strong>${selectedLimit.toLocaleString()}/mo</strong> (138% of the Federal Poverty Level).
                    </p>
                    <div className="text-xs font-bold text-neutral-500 italic bg-white p-2.5 rounded-xl border border-neutral-100">
                      Even if you have $0 monthly income, you qualify! Oklahoma SoonerCare provides 100% free comprehensive healthcare with no monthly premiums.
                    </div>
                  </div>
                ) : (!residesInOK || !ageRange) ? (
                  <div className="space-y-1.5 text-amber-800">
                    <div className="flex items-center gap-2 text-amber-700">
                      <AlertCircle className="w-5 h-5 shrink-0" />
                      <span className="text-sm font-black uppercase tracking-tight">Requires Alternative Check</span>
                    </div>
                    <p className="text-xs font-medium leading-relaxed">
                      {!residesInOK && "• You must reside in the State of Oklahoma to fit Oklahoma SoonerCare rules. "}
                      {!ageRange && "• Under/over traditional adult expansion ages. Different eligibility metrics apply to children under 19, parents, or seniors over 65."}
                    </p>
                  </div>
                ) : !isIncomeWithinLimit ? (
                  <div className="space-y-1.5">
                    <div className="flex items-center gap-2 text-amber-700">
                      <AlertCircle className="w-5 h-5 shrink-0" />
                      <span className="text-sm font-black uppercase tracking-tight">Exceeds Standard Expansion limit</span>
                    </div>
                    <p className="text-xs text-neutral-600 font-medium leading-relaxed">
                      Your income (${numericIncome.toLocaleString()}/mo) is above the standard $${selectedLimit.toLocaleString()}/mo limit for this household size.
                    </p>
                    <p className="text-[11px] text-neutral-500 font-semibold italic bg-amber-50/50 p-2.5 rounded-xl border border-amber-200/40">
                      Tip: Medical deduction and work exceptions can modify eligibility. If you have children, the income limit is higher! Go to section 4 to request an advocate to review your case.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-1 text-amber-700">
                    <div className="flex items-center gap-2">
                      <AlertCircle className="w-5 h-5 shrink-0" />
                      <span className="text-sm font-black uppercase tracking-tight">Incomplete Check</span>
                    </div>
                    <p className="text-xs text-neutral-600">Please answer all Residency and citizenship details to get an estimate.</p>
                  </div>
                )}
              </div>

              {/* Call-to-action */}
              <button
                onClick={() => setPanelTab('checklist')}
                className="w-full flex items-center justify-center gap-2 py-3 bg-brand-green hover:bg-emerald-900 transition-colors text-brand-yellow rounded-2xl font-black text-xs uppercase tracking-wider shadow-md"
              >
                <span>Continue to Document Prep</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </motion.div>
          )}

          {panelTab === 'checklist' && (
            <motion.div
              key="checklist"
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 10 }}
              className="space-y-5"
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <Bookmark className="w-4 h-4 text-brand-green" />
                  <h4 className="font-black text-neutral-900 text-sm uppercase tracking-tight">Required Application Artifacts</h4>
                </div>
                <p className="text-xs text-neutral-500 font-medium">To avoid delay, get these items ready before clicking submit. Check them off as you prepare:</p>
              </div>

              <div className="space-y-3">
                {[
                  {
                    id: 'ssn',
                    title: "Social Security Number & Birth Date",
                    desc: "Required for identity and citizen verification database check."
                  },
                  {
                    id: 'id',
                    title: "Government-issued Photo ID",
                    desc: "An Oklahoma ID, tribal membership card, or U.S. passport."
                  },
                  {
                    id: 'residency',
                    title: "Oklahoma Physical Address Proof",
                    desc: "A shelter residence letter, landlord statement, utility bill, or self-certification paper if unhoused."
                  },
                  {
                    id: 'income',
                    title: "Last 30 Days of Income / Paystubs",
                    desc: "Paychecks, tax records, or a simple Statement of No Income if you are currently earning $0."
                  },
                  {
                    id: 'status',
                    title: "U.S. Citizenship or qualified legal status",
                    desc: "Standard verification. Native tribal members can include CDIB card for additional Medicaid exemptions."
                  }
                ].map(item => (
                  <div 
                    key={item.id}
                    onClick={() => toggleDoc(item.id)}
                    className={cn(
                      "flex items-start p-3 rounded-2xl border transition-all cursor-pointer select-none",
                      checkedDocs[item.id]
                        ? "bg-emerald-50/50 border-brand-green/30 text-brand-green"
                        : "bg-white hover:bg-neutral-50 border-neutral-100 text-neutral-700"
                    )}
                  >
                    <div className="h-5 flex items-center mr-3 mt-0.5">
                      <div className={cn(
                        "w-4 h-4 rounded-md border flex items-center justify-center transition-colors shrink-0",
                        checkedDocs[item.id]
                          ? "bg-brand-green border-brand-green text-brand-yellow"
                          : "border-neutral-300 bg-white"
                      )}>
                        {checkedDocs[item.id] && <CheckSquare className="w-3.5 h-3.5" />}
                      </div>
                    </div>
                    <div>
                      <h5 className="font-black text-xs uppercase leading-tight">{item.title}</h5>
                      <p className="text-[10px] text-neutral-500 font-medium mt-0.5 leading-snug">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>

              {/* Special tip for unhoused applicants */}
              <div className="p-4 rounded-2xl bg-amber-50/50 border border-amber-200/40 text-xs">
                <span className="font-black text-amber-950 uppercase block mb-1">🏥 No Permanent Mailing Address?</span>
                <p className="text-neutral-600 font-medium leading-relaxed">
                  In OKC, you can list a local shelter, such as the <strong>Homeless Alliance (1220 W. 4th St, OKC)</strong>, as your physical/mailing address. Volunteers will hold your medical cards and renewal letters, protecting you from losing coverage!
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => setPanelTab('eligibility')}
                  className="py-2.5 border border-neutral-200 rounded-xl font-bold text-xs uppercase text-neutral-600 hover:bg-neutral-50 transition-colors"
                >
                  Back
                </button>
                <button
                  onClick={() => setPanelTab('apply')}
                  className="py-2.5 bg-brand-green text-brand-yellow hover:bg-emerald-950 transition-colors rounded-xl font-black text-xs uppercase tracking-wider text-center"
                >
                  How to Submit
                </button>
              </div>
            </motion.div>
          )}

          {panelTab === 'apply' && (
            <motion.div
              key="apply"
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 10 }}
              className="space-y-5"
            >
              <div className="space-y-1">
                <h4 className="font-black text-neutral-900 text-sm uppercase tracking-tight">Simple Ways to File in Oklahoma</h4>
                <p className="text-xs text-neutral-500 font-medium">You can complete your application through three primary routes. Select the choice that works best:</p>
              </div>

              <div className="space-y-3">
                {/* Option 1: Online */}
                <div className="bg-white p-4 rounded-2xl border border-neutral-100 flex flex-col justify-between items-start gap-2.5 shadow-sm">
                  <div className="space-y-1">
                    <span className="bg-emerald-100 text-emerald-800 text-[9px] font-black uppercase px-2 py-0.5 rounded-md">Option A (Fastest)</span>
                    <h5 className="font-black text-xs uppercase text-neutral-900 leading-none">Online via MySoonerCare Portal</h5>
                    <p className="text-[10px] text-neutral-500 font-medium leading-relaxed">Create a secure login and complete your forms instantly on the Oklahoma Health Care Authority website.</p>
                  </div>
                  <a
                    href="https://www.mysoonercare.org/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 px-4 py-2 bg-brand-green hover:bg-emerald-950 text-white font-black text-[10px] uppercase tracking-wider rounded-xl transition-colors shadow-sm self-stretch text-center"
                  >
                    <span>Visit MySoonerCare.org</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>

                {/* Option 2: Telephone */}
                <div className="bg-white p-4 rounded-2xl border border-neutral-100 flex flex-col justify-between items-start gap-2.5 shadow-sm">
                  <div className="space-y-1">
                    <span className="bg-amber-100 text-amber-800 text-[9px] font-black uppercase px-2 py-0.5 rounded-md">Option B</span>
                    <h5 className="font-black text-xs uppercase text-neutral-900 leading-none">By Phone (Toll Free Helpline)</h5>
                    <p className="text-[10px] text-neutral-500 font-medium leading-relaxed">Call the official Oklahoma Healthcare Authority helpline. A counselor will fill out the online forms with you over the phone.</p>
                  </div>
                  <a
                    href="tel:18009877767"
                    className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 px-4 py-2 bg-neutral-900 hover:bg-neutral-800 text-brand-yellow font-black text-[10px] uppercase tracking-wider rounded-xl transition-colors shadow-sm self-stretch text-center"
                  >
                    <PhoneCall className="w-3.5 h-3.5" />
                    <span>Call 1-800-987-7767</span>
                  </a>
                </div>

                {/* Option 3: In-Person assistance */}
                <div className="bg-white p-4 rounded-2xl border border-neutral-100 flex flex-col justify-between items-start gap-2.5 shadow-sm">
                  <div className="space-y-1">
                    <span className="bg-sky-100 text-sky-800 text-[9px] font-black uppercase px-2 py-0.5 rounded-md">Option C</span>
                    <h5 className="font-black text-xs uppercase text-neutral-900 leading-none">In-person assist at Westtown OKC</h5>
                    <p className="text-[10px] text-neutral-500 font-medium leading-relaxed">Visit the Homeless Alliance Westtown campus. On-site case coordinators will sit down with you and complete the system on their laptops.</p>
                  </div>
                  <div className="text-[9px] font-black text-neutral-400 uppercase tracking-widest bg-neutral-50 p-2.5 rounded-xl border border-neutral-100/50 w-full">
                    Address: 1220 W 4th St, Oklahoma City • Mon - Fri (8AM - 4PM)
                  </div>
                </div>
              </div>

              {/* Transition to direct help */}
              <div className="space-y-3 bg-brand-green/5 p-4 rounded-3xl border border-brand-green/10 text-center">
                <span className="text-[9px] font-black text-brand-green uppercase tracking-widest block">Having difficulty? No internet access?</span>
                <p className="text-[11px] text-neutral-600 font-medium px-2 leading-relaxed">
                  Submit a ticket to matches in Oklahoma. We can configure a certified local advocate or caseworker to visit you, supply access, and handle documents!
                </p>
                <button
                  onClick={() => setPanelTab('request')}
                  className="inline-flex items-center gap-1.5 py-2 px-4 bg-brand-yellow text-brand-green font-black text-[10px] uppercase tracking-wider rounded-xl hover:bg-yellow-400 transition-colors shadow-sm"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Request Local Navigator Assistance</span>
                </button>
              </div>
            </motion.div>
          )}

          {panelTab === 'request' && (
            <motion.div
              key="request"
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 10 }}
              className="space-y-4"
            >
              <div className="space-y-1">
                <h4 className="font-black text-neutral-900 text-sm uppercase tracking-tight">Request an OKC SoonerCare Navigator</h4>
                <p className="text-xs text-neutral-500 font-medium">Stuck? Unsure? Submit your info below. A certified peer advocate or Homeless Alliance caseworker in Oklahoma will assist you with enrollment.</p>
              </div>

              {/* If not logged in, showcase notice */}
              {!user ? (
                <div className="p-5 bg-amber-50 rounded-2xl border border-amber-200 text-center space-y-3">
                  <Lock className="w-8 h-8 text-amber-600 mx-auto" />
                  <p className="text-xs font-bold text-amber-900 leading-relaxed uppercase">
                    You must sign in to submit a live advocate help request.
                  </p>
                  <p className="text-[10px] text-neutral-500 font-medium leading-normal max-w-xs mx-auto">
                    This keeps requests secure and allows volunteers to safely track your case history. Click "Sign In with Google" at the top of the app!
                  </p>
                </div>
              ) : helpSuccess ? (
                <motion.div 
                  initial={{ scale: 0.95, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="p-6 bg-emerald-50 rounded-3xl border-2 border-emerald-200 text-center space-y-4"
                >
                  <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center mx-auto text-brand-green shadow-sm">
                    <CheckCircle2 className="w-7 h-7" />
                  </div>
                  <div>
                    <h5 className="font-black text-emerald-950 uppercase text-sm">Request Submitted successfully!</h5>
                    <p className="text-xs text-neutral-600 font-medium leading-relaxed mt-1">
                      We have posted your SoonerCare help ticket to our verified community network. A qualified Oklahoma health navigator or outreach partner will contact you shortly.
                    </p>
                  </div>
                  <button 
                    onClick={() => setHelpSuccess(false)}
                    className="px-4 py-2 bg-white hover:bg-neutral-50 text-neutral-800 border rounded-xl font-bold text-xs uppercase"
                  >
                    Submit Another Request
                  </button>
                </motion.div>
              ) : (
                <form onSubmit={handleHelpSubmit} className="space-y-3">
                  {validationError && (
                    <div className="p-3 bg-red-50 text-red-700 text-xs font-bold rounded-xl border border-red-200 flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 shrink-0" />
                      <span>{validationError}</span>
                    </div>
                  )}

                  {/* Contact Name */}
                  <div className="space-y-1">
                    <label className="text-[10px] font-black text-neutral-500 uppercase tracking-wider block">Your Full Name</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Marcus Carter"
                      value={contactName}
                      onChange={(e) => setContactName(e.target.value)}
                      className="w-full px-3 py-2 bg-neutral-50 border border-neutral-200 rounded-xl text-xs font-bold focus:bg-white focus:outline-none focus:ring-1 focus:ring-brand-green leading-none"
                    />
                  </div>

                  {/* Contact Method Toggles */}
                  <div className="space-y-1">
                    <label className="text-[10px] font-black text-neutral-500 uppercase tracking-wider block">Best Way to Contact You</label>
                    <div className="grid grid-cols-4 gap-1.5">
                      {[
                        { id: 'phone', label: 'Call' },
                        { id: 'text', label: 'Text' },
                        { id: 'shelter', label: 'In-shelter' },
                        { id: 'other', label: 'Other/No-phone' }
                      ].map(method => (
                        <button
                          key={method.id}
                          type="button"
                          onClick={() => setContactMethod(method.id as any)}
                          className={cn(
                            "py-2 rounded-xl border text-[10px] font-black uppercase transition-all text-center",
                            contactMethod === method.id 
                              ? "bg-brand-green text-brand-yellow border-brand-green" 
                              : "bg-neutral-50 text-neutral-500 border-neutral-200 hover:bg-neutral-100"
                          )}
                        >
                          {method.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* If phone/text selected vs shelter */}
                  {contactMethod !== 'shelter' ? (
                    <div className="space-y-1">
                      <label className="text-[10px] font-black text-neutral-500 uppercase tracking-wider block">Phone Number or Address Details</label>
                      <input
                        type="tel"
                        required={contactMethod !== 'other'}
                        placeholder="e.g. (405) 555-0199 or specify where to reach you"
                        value={contactPhone}
                        onChange={(e) => setContactPhone(e.target.value)}
                        className="w-full px-3 py-2 bg-neutral-50 border border-neutral-200 rounded-xl text-xs font-bold focus:bg-white focus:outline-none focus:ring-1 focus:ring-brand-green leading-none"
                      />
                    </div>
                  ) : (
                    <div className="space-y-1">
                      <label className="text-[10px] font-black text-neutral-500 uppercase tracking-wider block">Preferred Shelter & Intake Center in OKC</label>
                      <select
                        value={shelterDetails}
                        onChange={(e) => setShelterDetails(e.target.value)}
                        className="w-full px-3 py-2 bg-neutral-50 border border-neutral-200 rounded-xl text-xs font-bold focus:bg-white focus:outline-none focus:ring-1 focus:ring-brand-green"
                      >
                        <option value="Homeless Alliance Day Center (1220 W 4th St)">Homeless Alliance Day Center (1220 W 4th St, OKC)</option>
                        <option value="City Rescue Mission (800 W California Ave)">City Rescue Mission (800 W California Ave, OKC)</option>
                        <option value="City Care Night Shelter (532 N Villa Ave)">City Care Night Shelter (532 N Villa Ave, OKC)</option>
                        <option value="Sisu Youth Services (3000 N Classen Blvd)">Sisu Youth Services (3000 N Classen Blvd, OKC - Youth Only)</option>
                        <option value="Other Shelter Intake Location">Other OKC location (describe below)</option>
                      </select>
                    </div>
                  )}

                  {/* Roadblocks Checked */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black text-neutral-500 uppercase tracking-wider block">Specific Roadblocks or Needs (Select all that apply)</label>
                    <div className="flex flex-wrap gap-1.5">
                      {[
                        "No ID card",
                        "No proof of income",
                        "No permanent address",
                        "Cannot access computer",
                        "Stuck on paperwork",
                        "Need Spanish support"
                      ].map(block => {
                        const isSel = roadblocks.includes(block);
                        return (
                          <button
                            key={block}
                            type="button"
                            onClick={() => handleToggleRoadblock(block)}
                            className={cn(
                              "px-2.5 py-1 text-[9px] font-black uppercase rounded-lg border transition-all",
                              isSel 
                                ? "bg-amber-100 text-amber-900 border-amber-300"
                                : "bg-neutral-50 text-neutral-500 border-neutral-200 hover:bg-neutral-100"
                            )}
                          >
                            {block}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Additional notes */}
                  <div className="space-y-1">
                    <label className="text-[10px] font-black text-neutral-500 uppercase tracking-wider block">Additional details or context (Optional)</label>
                    <textarea
                      placeholder="e.g. I am at the shelter until Thursday, or I need an interpreter."
                      rows={2}
                      value={additionalDetails}
                      onChange={(e) => setAdditionalDetails(e.target.value)}
                      className="w-full px-3 py-2 bg-neutral-50 border border-neutral-200 rounded-xl text-xs font-medium focus:bg-white focus:outline-none focus:ring-1 focus:ring-brand-green"
                    />
                  </div>

                  {/* Submit Button */}
                  <button
                    type="submit"
                    disabled={isSubmittingHelp}
                    className="w-full flex items-center justify-center gap-1.5 py-3 bg-brand-green hover:bg-emerald-950 transition-colors text-brand-yellow font-black text-xs uppercase tracking-wider rounded-2xl shadow-md disabled:opacity-50"
                  >
                    {isSubmittingHelp ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>Sending Request to OK Network...</span>
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-4 h-4 text-brand-yellow" />
                        <span>Submit Nav Request</span>
                      </>
                    )}
                  </button>
                </form>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

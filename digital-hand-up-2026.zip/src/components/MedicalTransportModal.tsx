import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  Car, 
  PhoneCall, 
  Calendar, 
  Clock, 
  ShieldCheck,
  AlertTriangle,
  Info
} from 'lucide-react';
import { cn } from '../lib/utils';

export const NEMT_PROVIDERS = {
  Traditional: {
    name: "SoonerRide (Traditional)",
    phone: "1-877-404-4500"
  },
  Aetna: {
    name: "Aetna Better Health",
    phone: "1-877-718-4208"
  },
  Humana: {
    name: "Humana Healthy Horizons",
    phone: "1-877-718-4213"
  },
  OK_Complete: {
    name: "Oklahoma Complete Health",
    phone: "1-877-718-4212"
  }
};

interface MedicalTransportModalProps {
  isOpen: boolean;
  onClose: () => void;
  clinicName: string;
  clinicAddress: string;
}

export default function MedicalTransportModal({
  isOpen,
  onClose,
  clinicName,
  clinicAddress
}: MedicalTransportModalProps) {
  const [insuranceKey, setInsuranceKey] = useState<keyof typeof NEMT_PROVIDERS>('Traditional');
  const [apptDate, setApptDate] = useState<string>('');
  const [apptTime, setApptTime] = useState<string>('09:00');

  // Set default date to tomorrow
  useEffect(() => {
    if (isOpen) {
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      setApptDate(tomorrow.toISOString().split('T')[0]);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  // Real-time calculation based on selected date and time
  const calculateBookingStatus = () => {
    if (!apptDate || !apptTime) {
       return null;
    }
    const [year, month, day] = apptDate.split('-').map(Number);
    const [hours, minutes] = apptTime.split(':').map(Number);
    
    // Build the appointment date (local time)
    const apptDateTime = new Date(year, month - 1, day, hours, minutes);
    const now = new Date();
    
    const timeDifferenceMs = apptDateTime.getTime() - now.getTime();
    const threeDaysMs = 3 * 24 * 60 * 60 * 1000;
    
    if (timeDifferenceMs < 0) {
      return {
        status: "Passed",
        label: "Appointment Time Has Passed",
        instruction: "Cannot book transit for a past appointment date.",
        color: "text-neutral-500",
        bg: "bg-neutral-100",
        border: "border-neutral-200"
      };
    } else if (timeDifferenceMs >= threeDaysMs) {
      return {
        status: "Standard",
        label: "Standard Booking Window Open",
        instruction: "Regular booking requirement met. Ensure you call to secure your slot.",
        color: "text-emerald-700",
        bg: "bg-emerald-50",
        border: "border-emerald-200"
      };
    } else {
      return {
        status: "Urgent",
        label: "⚠️ URGENT ENTRY REQUIRED",
        instruction: 'Tell the operator: "This is an urgent, same-day/next-day behavioral health intake request" to bypass the 3-day notice rule.',
        color: "text-amber-800",
        bg: "bg-amber-100",
        border: "border-amber-300"
      };
    }
  };

  const bookingLogic = calculateBookingStatus();
  const activeProvider = NEMT_PROVIDERS[insuranceKey];

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-neutral-900/60 backdrop-blur-sm">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="bg-white w-full max-w-md rounded-[2rem] overflow-hidden shadow-2xl border border-neutral-100 flex flex-col max-h-[90vh]"
        >
          {/* Header */}
          <div className="bg-brand-green p-5 text-white flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
                <Car className="w-5 h-5 text-brand-yellow" />
              </div>
              <div>
                <h3 className="font-bold font-mission tracking-wide leading-tight">Medicaid Ride-Share</h3>
                <p className="text-emerald-100/80 text-[10px] uppercase font-bold tracking-widest">NEMT Booking Helper</p>
              </div>
            </div>
            <button 
              onClick={onClose}
              className="p-2 hover:bg-white/20 rounded-full transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="p-5 overflow-y-auto space-y-6">
            {/* Target Clinic Details */}
            <div className="space-y-1">
              <p className="text-xs font-black text-neutral-400 uppercase tracking-widest">Destination</p>
              <h4 className="font-bold text-neutral-900 text-lg">{clinicName}</h4>
              <p className="text-sm text-neutral-500">{clinicAddress}</p>
            </div>

            {/* Inputs */}
            <div className="bg-neutral-50 p-4 rounded-2xl border border-neutral-200/60 space-y-4">
              {/* Insurance Dropdown */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-neutral-600 uppercase tracking-wider flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-brand-green" />
                  Your Insurance Plan
                </label>
                <select 
                  className="w-full bg-white border border-neutral-300 rounded-xl px-3 py-2.5 text-sm font-medium focus:ring-2 focus:ring-brand-green focus:border-transparent outline-none transition-all"
                  value={insuranceKey}
                  onChange={(e) => setInsuranceKey(e.target.value as keyof typeof NEMT_PROVIDERS)}
                >
                  {Object.entries(NEMT_PROVIDERS).map(([key, provider]) => (
                    <option key={key} value={key}>{provider.name}</option>
                  ))}
                </select>
              </div>

              {/* Date & Time */}
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-neutral-600 uppercase tracking-wider flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5 text-brand-green" />
                    Appt Date
                  </label>
                  <input 
                    type="date" 
                    value={apptDate}
                    onChange={(e) => setApptDate(e.target.value)}
                    className="w-full bg-white border border-neutral-300 rounded-xl px-3 py-2.5 text-sm font-medium focus:ring-2 focus:ring-brand-green outline-none"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-neutral-600 uppercase tracking-wider flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-brand-green" />
                    Appt Time
                  </label>
                  <input 
                    type="time" 
                    value={apptTime}
                    onChange={(e) => setApptTime(e.target.value)}
                    className="w-full bg-white border border-neutral-300 rounded-xl px-3 py-2.5 text-sm font-medium focus:ring-2 focus:ring-brand-green outline-none"
                  />
                </div>
              </div>
            </div>

            {/* Status Output */}
            {bookingLogic && (
              <div className={cn(
                "p-4 rounded-2xl border-2 space-y-2 relative overflow-hidden",
                bookingLogic.bg,
                bookingLogic.border
              )}>
                {bookingLogic.status === 'Urgent' && (
                  <div className="absolute top-0 right-0 p-2 opacity-10 pointer-events-none">
                    <AlertTriangle className="w-20 h-20" />
                  </div>
                )}
                
                <h5 className={cn("text-xs font-black uppercase tracking-widest flex items-center gap-1.5", bookingLogic.color)}>
                  {bookingLogic.status === 'Urgent' ? <AlertTriangle className="w-4 h-4" /> : <Info className="w-4 h-4" />}
                  {bookingLogic.label}
                </h5>
                <p className={cn("text-sm font-medium leading-snug", bookingLogic.color)}>
                  {bookingLogic.instruction}
                </p>
              </div>
            )}

            {/* Action Output */}
            <div className="space-y-2">
              <a 
                href={`tel:${activeProvider.phone}`}
                className="w-full flex items-center justify-between p-4 rounded-2xl bg-neutral-900 hover:bg-neutral-800 text-white transition-all shadow-md active:scale-95 group"
              >
                <div className="flex items-center gap-3">
                  <div className="bg-white/10 p-2 rounded-xl group-hover:scale-110 transition-transform">
                    <PhoneCall className="w-5 h-5 text-brand-yellow" />
                  </div>
                  <div className="text-left">
                    <span className="block text-xs text-neutral-400 font-bold uppercase tracking-wider">Tap to Schedule via</span>
                    <span className="block font-black text-lg">{activeProvider.phone}</span>
                  </div>
                </div>
              </a>
              <div className="text-center">
                <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-widest flex items-center justify-center gap-1">
                  <AlertTriangle className="w-3 h-3" />
                  If stranded, call 1-800-435-1034
                </span>
              </div>
            </div>

          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}

import React, { useState, useEffect } from 'react';
import { 
  Phone, 
  MessageSquare, 
  MapPin, 
  ShieldAlert, 
  Activity, 
  Clock, 
  CheckCircle2, 
  Navigation,
  MoreVertical,
  Crosshair,
  UserCheck,
  Car,
  Heart,
  FileText
} from 'lucide-react';
import { db, handleFirestoreError, OperationType } from '../lib/backend';
import { 
  collection, 
  query, 
  orderBy, 
  onSnapshot, 
  addDoc,
  serverTimestamp,
  setDoc,
  doc,
  deleteDoc,
  Timestamp
} from '../lib/backend';
import { type User as AuthUser } from '../lib/backend';
import type { UserProfile } from '../App';
import { cn } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';
import DiversionScreening from './DiversionScreening';
import MedicalTransportModal from './MedicalTransportModal';
import SsiDisabilityGuide from './SsiDisabilityGuide';
import BusPassAssistant from './BusPassAssistant';

interface ProviderStatus {
  providerId: string;
  name: string;
  type: 'CMHC' | 'Street Medicine' | 'MCOT';
  isActive: boolean;
  message: string;
  location: string;
  updatedAt: Timestamp;
}

interface MentalHealthSupportProps {
  user: AuthUser | null;
  profile: any; // Using any for simplicity here to avoid circular interface issues if not exported
}

interface OutreachRequest {
  id: string; // Document ID
  userId: string;
  locationStr: string;
  status: 'pending' | 'completed';
  timestamp: Timestamp;
  subgroup?: string;
}

export default function MentalHealthSupport({ user, profile }: MentalHealthSupportProps) {
  const [providers, setProviders] = useState<ProviderStatus[]>([]);
  const [loading, setLoading] = useState(true);
  
  // States for Outreach Request
  const [isRequestingOutreach, setIsRequestingOutreach] = useState(false);
  const [outreachSent, setOutreachSent] = useState(false);
  const [geolocationError, setGeolocationError] = useState<string | null>(null);

  // States for Provider Dashboard
  const [outreachRequests, setOutreachRequests] = useState<OutreachRequest[]>([]);
  const [providerMode, setProviderMode] = useState(false);
  const [myProviderStatus, setMyProviderStatus] = useState<ProviderStatus | null>(null);
  const [isUpdatingStatus, setIsUpdatingStatus] = useState(false);

  // States for NEMT Modal
  const [selectedNEMTProvider, setSelectedNEMTProvider] = useState<ProviderStatus | null>(null);

  // Switch between Crisis mental support, Social Security disability, and free Bus passes
  const [supportSection, setSupportSection] = useState<'mental' | 'ssi' | 'bus'>('mental');

  useEffect(() => {
    // Listen to real-time provider statuses
    const q = query(collection(db, 'provider_status'), orderBy('updatedAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const docs = snapshot.docs.map(doc => ({
        ...doc.data()
      }) as ProviderStatus);
      
      // Filter out old statuses (>24 hours) client-side just in case
      let validProviders = docs.filter(p => {
        const diff = Date.now() - p.updatedAt.toMillis();
        const hours = diff / (1000 * 60 * 60);
        return hours < 24;
      });

      if (validProviders.length === 0) {
        // Fallback demo data so users can test the ride booking feature
        validProviders = [
          {
            providerId: 'demo-1',
            name: 'NorthCare Adult Behavioral Health',
            type: 'CMHC',
            isActive: true,
            message: 'Walk-ins welcome until 4PM today.',
            location: '2617 General Pershing Blvd, OKC',
            updatedAt: Timestamp.now()
          },
          {
            providerId: 'demo-2',
            name: 'Hope Community Services',
            type: 'CMHC',
            isActive: true,
            message: 'Psychiatrist on-site now. Urgent intakes open.',
            location: '6100 S Walker Ave, OKC',
            updatedAt: Timestamp.now()
          }
        ];
      }

      setProviders(validProviders);
      
      if (user) {
        const myStatus = validProviders.find(p => p.providerId === user.uid);
        if (myStatus) {
          setMyProviderStatus(myStatus);
        }
      }
      
      setLoading(false);
    }, (err) => {
      handleFirestoreError(err, OperationType.LIST, 'provider_status');
      setLoading(false);
    });

    return () => unsubscribe();
  }, [user]);

  useEffect(() => {
    // Only listen to outreach requests if user is a provider/admin
    if (!user || (!profile?.isProvider && profile?.email !== 'onandcrackin3@gmail.com')) return;
    
    const q = query(collection(db, 'outreach_requests'), orderBy('timestamp', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const docs = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }) as OutreachRequest);
      
      // Filter out statuses (>24 hours) client-side
      const recentRequests = docs.filter(r => {
        const diff = Date.now() - r.timestamp.toMillis();
        const hours = diff / (1000 * 60 * 60);
        return hours < 24;
      });

      setOutreachRequests(recentRequests);
    }, (err) => {
      console.error("Error fetching outreach requests:", err);
    });

    return () => unsubscribe();
  }, [user, profile]);

  const handleRequestOutreach = () => {
    if (!user) return alert("Please log in to request an outreach visit.");
    
    setIsRequestingOutreach(true);
    setGeolocationError(null);

    if (!navigator.geolocation) {
      setGeolocationError("Geolocation is not supported by your browser.");
      setIsRequestingOutreach(false);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const locationStr = `${position.coords.latitude},${position.coords.longitude}`;
        try {
          // Drop anonymous outreach pin
          const randomSubgroups = ['Veterans', 'Youth', 'Complex Behavioral'];
          const randomSubgroup = randomSubgroups[Math.floor(Math.random() * randomSubgroups.length)];
          
          await addDoc(collection(db, 'outreach_requests'), {
            userId: user.uid,
            locationStr,
            status: 'pending',
            timestamp: serverTimestamp(),
            subgroup: randomSubgroup
          });
          setOutreachSent(true);
          setTimeout(() => setOutreachSent(false), 5000);
        } catch (err) {
          console.error("Error creating outreach request:", err);
          setGeolocationError("Failed to send outreach request.");
        } finally {
          setIsRequestingOutreach(false);
        }
      },
      (error) => {
        console.error("Error getting location:", error);
        setGeolocationError("Unable to get your location. Please check permissions.");
        setIsRequestingOutreach(false);
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    );
  };

  const toggleProviderStatus = async (isActive: boolean) => {
    if (!user || (!profile?.isProvider && profile?.email !== 'onandcrackin3@gmail.com')) return;
    setIsUpdatingStatus(true);
    try {
      const ref = doc(db, 'provider_status', user.uid);
      
      if (!isActive && myProviderStatus) {
        // Go offline
        await deleteDoc(ref);
        setMyProviderStatus(null);
      } else {
        // Go online
        const newStatus = {
          providerId: user.uid,
          name: profile.displayName || 'Emergency Clinic',
          type: profile.providerType || 'CMHC',
          isActive: true,
          message: 'Open for behavioral health intakes',
          location: 'Downtown OKC',
          updatedAt: serverTimestamp()
        };
        await setDoc(ref, newStatus);
      }
    } catch (err) {
      console.error(err);
      alert("Failed to update status.");
    } finally {
      setIsUpdatingStatus(false);
    }
  };

  return (
    <div className="space-y-6">
      <DiversionScreening onRoute={(route) => {
        // Find nearest route or provider and simply scroll there or handle routing
        window.scrollBy({ top: 300, behavior: 'smooth' });
      }} />

      {/* Tab Switcher for different support divisions - styled as highly recognizable, tactile card-like buttons */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 bg-neutral-100/60 p-2.5 rounded-[2rem] border border-neutral-200/60 font-sans">
        <button
          onClick={() => setSupportSection('mental')}
          className={cn(
            "py-3.5 px-4 text-xs md:text-sm font-black uppercase tracking-wider rounded-2xl transition-all flex items-center justify-center gap-2.5 border-2",
            supportSection === 'mental' 
              ? "bg-brand-green text-brand-yellow border-brand-green shadow-md scale-[1.02]" 
              : "bg-white hover:bg-neutral-50 text-neutral-700 border-neutral-200 shadow-xs hover:border-neutral-300 hover:scale-[1.01] active:scale-98"
          )}
        >
          <ShieldAlert className={cn("w-4.5 h-4.5 md:w-5 md:h-5 shrink-0", supportSection === 'mental' ? "text-brand-yellow" : "text-red-500")} />
          <span>Crisis & Outreach</span>
        </button>
        <button
          onClick={() => setSupportSection('ssi')}
          className={cn(
            "py-3.5 px-4 text-xs md:text-sm font-black uppercase tracking-wider rounded-2xl transition-all flex items-center justify-center gap-2.5 border-2",
            supportSection === 'ssi' 
              ? "bg-brand-green text-brand-yellow border-brand-green shadow-md scale-[1.02]" 
              : "bg-white hover:bg-neutral-50 text-neutral-700 border-neutral-200 shadow-xs hover:border-neutral-300 hover:scale-[1.01] active:scale-98"
          )}
        >
          <FileText className={cn("w-4.5 h-4.5 md:w-5 md:h-5 shrink-0", supportSection === 'ssi' ? "text-brand-yellow" : "text-blue-500")} />
          <span>Social Security (SSI/SSDI)</span>
        </button>
        <button
          onClick={() => setSupportSection('bus')}
          className={cn(
            "py-3.5 px-4 text-xs md:text-sm font-black uppercase tracking-wider rounded-2xl transition-all flex items-center justify-center gap-2.5 border-2",
            supportSection === 'bus' 
              ? "bg-brand-green text-brand-yellow border-brand-green shadow-md scale-[1.02]" 
              : "bg-white hover:bg-neutral-50 text-neutral-700 border-neutral-200 shadow-xs hover:border-neutral-300 hover:scale-[1.01] active:scale-98"
          )}
        >
          <Car className={cn("w-4.5 h-4.5 md:w-5 md:h-5 shrink-0", supportSection === 'bus' ? "text-brand-yellow" : "text-amber-500")} />
          <span>Free Bus Passes</span>
        </button>
      </div>

      <AnimatePresence mode="wait">
        {supportSection === 'mental' ? (
          <motion.div
            key="crisis-tab"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-6"
          >
            {/* Animated Greeting / Explanation */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, ease: "easeOut" }}
              className="bg-gradient-to-b from-red-50 to-white pb-6 pt-8 px-6 rounded-3xl border-2 border-red-100 flex flex-col items-center text-center space-y-4 shadow-sm"
            >
              <motion.div
                 initial={{ scale: 0 }}
                 animate={{ scale: 1 }}
                 transition={{ delay: 0.3, type: 'spring', stiffness: 200 }}
                 className="bg-white p-4 rounded-full shadow border border-red-50 relative z-10"
              >
                <motion.div
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{ repeat: Infinity, duration: 1.5, ease: "easeInOut" }}
                >
                  <Heart className="w-10 h-10 text-red-500 fill-red-500" />
                </motion.div>
              </motion.div>
              
              <div className="relative z-10 space-y-2 max-w-sm mx-auto">
                <motion.h2 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 }}
                  className="text-2xl font-black text-red-950 tracking-tight leading-tight"
                >
                  You Are Not Alone
                </motion.h2>
                <motion.p 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.7 }}
                  className="text-sm font-medium text-red-800/80 leading-relaxed"
                >
                  The <strong className="text-red-900 font-bold">Red Shield</strong> is your direct lifeline. We care deeply about your mental health. Use this section to find immediate crisis support, request a mobile outreach team to your location, or safely bridge the gap to a local care provider.
                </motion.p>
              </div>
            </motion.div>

            {/* 1. Low-Friction Direct Connect */}
            <section className="bg-brand-green text-white p-6 rounded-3xl shadow-lg border border-brand-green shadow-brand-green/20">
              <div className="flex items-center gap-3 mb-4">
                <ShieldAlert className="w-8 h-8 text-brand-yellow" />
                <h2 className="text-xl font-bold font-mission tracking-tight">Immediate Crisis Support</h2>
              </div>
              <p className="text-emerald-100 text-sm leading-relaxed mb-6">
                If you or someone else is experiencing a mental health emergency, connect directly with professionals right now. 
              </p>
              
              <div className="grid grid-cols-2 gap-3 mb-4">
                <a 
                  href="tel:988" 
                  className="flex flex-col items-center justify-center p-4 bg-white/10 hover:bg-white/20 rounded-2xl transition-colors backdrop-blur-sm border border-white/10"
                >
                  <Phone className="w-6 h-6 mb-2 text-brand-yellow" />
                  <span className="font-bold text-sm">Call 988</span>
                  <span className="text-[10px] text-emerald-200 mt-1">National Lifeline</span>
                </a>
                <a 
                  href="sms:988" 
                  className="flex flex-col items-center justify-center p-4 bg-white/10 hover:bg-white/20 rounded-2xl transition-colors backdrop-blur-sm border border-white/10"
                >
                  <MessageSquare className="w-6 h-6 mb-2 text-brand-yellow" />
                  <span className="font-bold text-sm">Text 988</span>
                  <span className="text-[10px] text-emerald-200 mt-1">Private Messaging</span>
                </a>
              </div>

              {/* Outreach Drop Pin Feature */}
              <div className="mt-4 pt-4 border-t border-white/20">
                <button 
                  onClick={handleRequestOutreach}
                  disabled={isRequestingOutreach || outreachSent}
                  className={cn(
                    "w-full flex items-center justify-center gap-2 p-4 rounded-2xl transition-all font-bold shadow-md",
                    outreachSent 
                      ? "bg-emerald-500 text-white" 
                      : "bg-brand-yellow hover:bg-yellow-400 text-neutral-900 border-2 border-brand-yellow"
                  )}
                >
                  {isRequestingOutreach ? (
                    <div className="w-5 h-5 border-2 border-neutral-900 border-t-transparent rounded-full animate-spin" />
                  ) : outreachSent ? (
                    <>
                      <CheckCircle2 className="w-5 h-5" />
                      <span>Outreach Pin Dropped Securely</span>
                    </>
                  ) : (
                    <>
                      <Crosshair className="w-5 h-5" />
                      <span>Request Mobile Outreach Visit (MCOT)</span>
                    </>
                  )}
                </button>
                {geolocationError && (
                  <p className="text-red-200 text-xs text-center mt-2 font-medium">{geolocationError}</p>
                )}
                <p className="text-[10px] text-emerald-200/80 text-center mt-3 font-medium uppercase tracking-wider">
                  Your location is temporary and purged after 24 hrs.
                </p>
              </div>
            </section>

            {/* 2. Real-Time Provider Capacity Mapping */}
            <section className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Activity className="w-5 h-5 text-brand-green" />
                  <h3 className="font-bold text-neutral-900">Live Health Capacities</h3>
                </div>
                <span className="text-xs font-black text-emerald-600 bg-emerald-100 px-2 py-1 rounded-lg uppercase tracking-wider">
                  {providers.filter(p => p.isActive).length} Active
                </span>
              </div>

              {loading ? (
                <div className="flex justify-center p-8">
                  <div className="w-6 h-6 border-2 border-brand-green border-t-transparent rounded-full animate-spin" />
                </div>
              ) : providers.filter(p => p.isActive).length === 0 ? (
                <div className="bg-white p-6 rounded-[2rem] border border-neutral-100 text-center text-neutral-500">
                  <p className="text-sm font-medium">No clinics or mobile units are currently reporting active walk-in availability.</p>
                </div>
              ) : (
                <div className="grid gap-3">
                  <AnimatePresence>
                    {providers.filter(p => p.isActive).map(provider => (
                      <motion.div 
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        key={provider.providerId} 
                        className="bg-white p-5 rounded-[2rem] border border-neutral-100 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                      >
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                            <h4 className="font-bold text-neutral-900">{provider.name}</h4>
                          </div>
                          <div className="text-sm text-neutral-600 mb-2">{provider.message}</div>
                          <div className="flex items-center gap-3 text-xs text-neutral-400 font-medium">
                            <span className="flex items-center gap-1"><MapPin className="w-3 h-3" /> {provider.location}</span>
                            <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> Updated recently</span>
                          </div>
                        </div>
                        <div className="flex flex-col sm:flex-row gap-2">
                          <button
                            onClick={() => setSelectedNEMTProvider(provider)}
                            className="flex-shrink-0 bg-brand-yellow hover:bg-yellow-400 text-neutral-900 px-4 py-2 rounded-xl text-sm font-bold flex items-center justify-center gap-2 transition-colors border border-brand-yellow shadow-sm"
                          >
                            <Car className="w-4 h-4" />
                            Book Ride
                          </button>
                          <a 
                            href={`https://maps.google.com/?q=${encodeURIComponent(provider.name + ' ' + provider.location)}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex-shrink-0 bg-neutral-50 hover:bg-neutral-100 text-neutral-900 px-4 py-2 rounded-xl text-sm font-bold flex items-center justify-center gap-2 transition-colors border border-neutral-200"
                          >
                            <Navigation className="w-4 h-4 text-brand-green" />
                            Get Directions
                          </a>
                        </div>
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </div>
              )}
            </section>

            {/* Provider Dashboard (Only visible if the user is a designated provider or admin) */}
            {(profile?.isProvider || profile?.email === 'onandcrackin3@gmail.com') && (
              <section className="bg-neutral-900 text-white p-6 rounded-[2rem] border border-neutral-800 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <UserCheck className="w-5 h-5 text-brand-yellow" />
                    <h3 className="font-bold">Provider Capacity Dashboard</h3>
                  </div>
                  {myProviderStatus?.isActive ? (
                    <span className="bg-emerald-500/20 text-emerald-400 text-[10px] font-black px-2 py-1 rounded-full uppercase tracking-wider border border-emerald-500/20">
                      Online
                    </span>
                  ) : (
                    <span className="bg-neutral-800 text-neutral-400 text-[10px] font-black px-2 py-1 rounded-full uppercase tracking-wider border border-neutral-700">
                      Offline
                    </span>
                  )}
                </div>
                
                <p className="text-sm text-neutral-400 leading-relaxed mb-2">
                  Use this dashboard to toggle your clinic or mobile unit's real-time availability. 
                  When online, unhoused individuals and caseworkers can route people directly to you.
                </p>

                <button
                  onClick={() => toggleProviderStatus(!myProviderStatus?.isActive)}
                  disabled={isUpdatingStatus}
                  className={cn(
                    "w-full flex justify-center items-center gap-2 px-4 py-3 rounded-xl font-bold transition-all",
                    isUpdatingStatus ? "opacity-50" : "",
                    myProviderStatus?.isActive 
                      ? "bg-red-500 hover:bg-red-600 text-white" 
                      : "bg-emerald-500 hover:bg-emerald-600 text-white"
                  )}
                >
                  {isUpdatingStatus ? "Updating..." : myProviderStatus?.isActive ? "Go Offline (Stop Intakes)" : "Go Online (Accept Intakes)"}
                </button>

                {/* Outreach Requests List for Caseworkers */}
                {myProviderStatus?.isActive && (
                  <div className="mt-4 pt-4 border-t border-neutral-800">
                    <h4 className="font-bold text-sm text-brand-yellow mb-3 flex items-center gap-2">
                      <Crosshair className="w-4 h-4" /> Live Mobile Outreach Alerts
                    </h4>
                    <div className="space-y-3">
                      {outreachRequests.length === 0 ? (
                        <p className="text-xs text-neutral-500">No active requests in the last 24 hours.</p>
                      ) : (
                        outreachRequests.map(req => (
                          <div key={req.id} className="bg-neutral-800 p-3 rounded-xl border border-neutral-700 flex items-center justify-between gap-2">
                            <div>
                               <div className="flex items-center gap-2 mb-1">
                                 <span className={cn(
                                   "w-1.5 h-1.5 rounded-full",
                                   req.status === 'completed' ? "bg-emerald-500" : "bg-brand-yellow animate-pulse"
                                 )} />
                                 <span className="text-xs font-bold text-white">{req.status === 'completed' ? 'Completed' : 'Pending Outreach'}</span>
                                 {req.subgroup && (
                                   <span className="text-[9px] bg-neutral-700 text-neutral-300 px-1.5 py-0.5 rounded ml-2 uppercase tracking-wide">
                                     {req.subgroup}
                                   </span>
                                 )}
                               </div>
                               <div className="text-[10px] text-neutral-400">
                                 Lat/Lng: {req.locationStr}
                               </div>
                            </div>
                            <a 
                              href={`https://maps.google.com/?q=${req.locationStr}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="bg-neutral-700 hover:bg-neutral-600 p-2 rounded-lg transition-colors border border-neutral-600"
                              title="Route to Pin"
                            >
                               <Navigation className="w-4 h-4 text-brand-yellow" />
                            </a>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                )}
              </section>
            )}
          </motion.div>
        ) : supportSection === 'ssi' ? (
          <motion.div
            key="ssi-tab"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-6"
          >
            <SsiDisabilityGuide user={user} profile={profile} />
          </motion.div>
        ) : (
          <motion.div
            key="bus-tab"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-6"
          >
            <BusPassAssistant user={user} profile={profile} />
          </motion.div>
        )}
      </AnimatePresence>

      {/* NEMT Ride Booking Modal */}
      {selectedNEMTProvider && (
        <MedicalTransportModal
          isOpen={true}
          onClose={() => setSelectedNEMTProvider(null)}
          clinicName={selectedNEMTProvider.name}
          clinicAddress={selectedNEMTProvider.location}
        />
      )}

      {/* Placeholder at bottom so scrolling clears nav */}
      <div className="h-10" />
    </div>
  );
}

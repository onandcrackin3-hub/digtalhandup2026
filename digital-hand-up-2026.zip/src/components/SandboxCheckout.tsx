import React, { useState } from 'react';
import { ChevronLeft, Lock, CreditCard, Sparkles, CheckCircle, HelpCircle, RefreshCw, XCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface SandboxCheckoutProps {
  amount: number;
  userId: string;
  platformSupport?: boolean;
  onSuccess: () => void;
  onCancel: () => void;
}

export default function SandboxCheckout({ amount, userId, platformSupport = false, onSuccess, onCancel }: SandboxCheckoutProps) {
  const [email, setEmail] = useState('');
  const [cardNumber, setCardNumber] = useState('');
  const [expiry, setExpiry] = useState('');
  const [cvc, setCvc] = useState('');
  const [name, setName] = useState('');
  
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingStep, setProcessingStep] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [paymentSuccess, setPaymentSuccess] = useState(false);

  // Format Card Number (adds spaces every 4 digits)
  const handleCardNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length > 16) value = value.slice(0, 16);
    
    const formatted = value.match(/.{1,4}/g)?.join(' ') || value;
    setCardNumber(formatted);
    setError(null);
  };

  // Format Expiry (adds slash MM/YY)
  const handleExpiryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length > 4) value = value.slice(0, 4);
    
    if (value.length >= 2) {
      value = `${value.slice(0, 2)}/${value.slice(2)}`;
    }
    setExpiry(value);
    setError(null);
  };

  // Format CVC
  const handleCvcChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length > 4) value = value.slice(0, 4);
    setCvc(value);
    setError(null);
  };

  const handlePay = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    // Validation
    const cleanCard = cardNumber.replace(/\s/g, '');
    if (!email || !email.includes('@')) {
      setError('Please enter a valid email address.');
      return;
    }
    if (cleanCard.length < 16) {
      setError('Please enter a complete 16-digit card number.');
      return;
    }
    if (expiry.length < 5) {
      setError('Please enter a valid expiry date (MM/YY).');
      return;
    }
    if (cvc.length < 3) {
      setError('Please enter a valid 3 or 4 digit CVC.');
      return;
    }
    if (!name.trim()) {
      setError('Please enter the cardholder\'s full name.');
      return;
    }

    // Begin Simulated Credit Card Verification Flow
    setIsProcessing(true);
    
    const steps = [
      'Contacting Sandbox Payment Authority...',
      'Verifying credit card active status...',
      'Securing payment token via SSL handshakes...',
      'Finalizing simulated multi-signature settlement...'
    ];

    for (let i = 0; i < steps.length; i++) {
      setProcessingStep(steps[i]);
      await new Promise((resolve) => setTimeout(resolve, i === 1 ? 1200 : 800));
    }

    // Interactive Decline / Fail Scenarios based on card end/prefix
    if (cleanCard.endsWith('0002') || cleanCard.includes('0000000000000002')) {
      setError('Your card was declined. (Simulated decline code: 0002). Try using the test card info above!');
      setIsProcessing(false);
      return;
    }

    setIsProcessing(false);
    setPaymentSuccess(true);
    
    // Auto trigger redirection after a elegant checkmark success screen
    setTimeout(() => {
      onSuccess();
    }, 2500);
  };

  const fillTestCard = () => {
    setCardNumber('4242 4242 4242 4242');
    setExpiry('12/28');
    setCvc('424');
    setName('John Doe');
    setEmail('test_supporter@example.com');
  };

  const fillDecliningCard = () => {
    setCardNumber('4000 0000 0000 0002');
    setExpiry('12/28');
    setCvc('002');
    setName('Jane Doe');
    setEmail('decline_test@example.com');
  };

  return (
    <div className="min-h-screen bg-slate-100 font-sans text-slate-800 pb-12 flex flex-col md:flex-row shadow-2xl overflow-hidden rounded-[2rem] max-w-4xl mx-auto my-8 border border-neutral-200">
      
      {/* Simulation Info Sidebar */}
      <div className="w-full md:w-5/12 bg-gradient-to-br from-brand-green to-emerald-950 text-white p-8 flex flex-col justify-between relative overflow-hidden select-none">
        
        {/* Subtle decorative background glow */}
        <div className="absolute top-1/4 -right-16 w-48 h-48 rounded-full bg-brand-yellow/10 blur-3xl"></div>
        
        <div className="space-y-6 relative z-10">
          <button 
            type="button" 
            onClick={onCancel}
            className="flex items-center gap-1.5 text-brand-yellow hover:text-white transition-colors text-xs font-black uppercase tracking-wider"
          >
            <ChevronLeft className="w-4 h-4" /> Cancel Payment
          </button>

          <div className="space-y-2 pt-4">
            <span className="bg-brand-yellow/20 text-brand-yellow text-[10px] font-black uppercase tracking-widest px-2.5 py-1 rounded-full border border-brand-yellow/30">
              🛠️ Sandbox Mode Active
            </span>
            <h1 className="text-3xl font-black italic tracking-tighter uppercase leading-tight pt-2">
              Sponsorship Checkout
            </h1>
            <p className="text-emerald-100 text-xs font-medium max-w-xs">
              This sandbox completely simulates a secure Checkout gateway safely without charging real money.
            </p>
          </div>

          {/* Amount Display Card */}
          <div className="bg-white/10 border border-white/10 p-5 rounded-3xl space-y-3">
            <p className="text-[10px] text-brand-yellow/80 uppercase font-black tracking-widest">Payment Breakdown</p>
            <div className="space-y-1.5 text-xs">
              <div className="flex justify-between items-center text-emerald-100">
                <span>Member Sponsorship:</span>
                <span className="font-mono font-bold text-white">${amount}.00</span>
              </div>
              {platformSupport && (
                <div className="flex justify-between items-center text-brand-yellow">
                  <span>Platform Tip:</span>
                  <span className="font-mono font-bold text-brand-yellow animate-pulse">+$1.00</span>
                </div>
              )}
            </div>
            
            <div className="border-t border-white/20 pt-2 flex items-baseline justify-between">
              <span className="text-xs font-bold text-emerald-100">Total Charged:</span>
              <div className="flex items-baseline gap-1">
                <span className="text-4xl font-black text-brand-yellow">${amount + (platformSupport ? 1 : 0)}.00</span>
                <span className="text-xs font-bold text-white/60">USD</span>
              </div>
            </div>
            <div className="border-t border-white/10 pt-3 flex items-center justify-between text-[11px] font-bold text-emerald-100">
              <span>Sponsoring Community Member</span>
              <span className="text-white uppercase tracking-wider bg-white/10 px-2 py-0.5 rounded-md font-mono text-[9px]">ID: {userId.substring(0, 8)}...</span>
            </div>
          </div>
        </div>

        {/* Dynamic Interactive Test Cards panel */}
        <div className="space-y-4 pt-8 border-t border-white/10 select-none relative z-10">
          <div className="flex items-center gap-2 text-brand-yellow">
            <Sparkles className="w-4 h-4 text-brand-yellow animate-bounce" />
            <span className="text-[10px] font-black uppercase tracking-wider">Test Card Selectors</span>
          </div>
          
          <div className="grid grid-cols-1 gap-2.5">
            <button
              onClick={fillTestCard}
              type="button"
              className="w-full bg-white/10 hover:bg-white/20 active:scale-95 border border-white/20 text-left p-3.5 rounded-2xl flex items-center justify-between transition-all group"
            >
              <div>
                <p className="text-[10px] font-black text-brand-yellow uppercase tracking-wider">Success Scenario</p>
                <p className="text-xs font-mono font-bold">4242 4242 4242 4242</p>
              </div>
              <span className="bg-emerald-400 text-brand-green font-black text-[9px] px-2 py-1 rounded-full uppercase tracking-widest scale-90 group-hover:scale-100 transition-transform">Use</span>
            </button>

            <button
              onClick={fillDecliningCard}
              type="button"
              className="w-full bg-white/10 hover:bg-white/20 active:scale-95 border border-white/20 text-left p-3.5 rounded-2xl flex items-center justify-between transition-all group"
            >
              <div>
                <p className="text-[10px] font-black text-red-400 uppercase tracking-wider">Decline Scenario</p>
                <p className="text-xs font-mono font-bold">4000 0000 0000 0002</p>
              </div>
              <span className="bg-red-400 text-red-950 font-black text-[9px] px-2 py-1 rounded-full uppercase tracking-widest scale-90 group-hover:scale-100 transition-transform">Use</span>
            </button>
          </div>
        </div>
      </div>

      {/* Interactive Visa Form */}
      <div className="w-full md:w-7/12 bg-white p-8 flex flex-col justify-center relative">
        <AnimatePresence mode="wait">
          {!isProcessing && !paymentSuccess && (
            <motion.form 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              onSubmit={handlePay} 
              className="space-y-5"
            >
              <div className="flex items-center justify-between border-b pb-4">
                <div className="flex items-center gap-2">
                  <CreditCard className="w-5 h-5 text-brand-green" />
                  <span className="text-sm font-black text-brand-green uppercase tracking-wide">Enter Card Details</span>
                </div>
                <div className="flex items-center gap-1 text-[10px] text-neutral-400 font-bold">
                  <Lock className="w-3 h-3 text-neutral-400" />
                  <span>SECURE SIMULATION</span>
                </div>
              </div>

              {/* Error Box */}
              {error && (
                <div className="p-4 bg-red-50 border-2 border-red-200 text-red-800 text-xs font-bold rounded-2xl flex items-start gap-2.5">
                  <XCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                  <span>{error}</span>
                </div>
              )}

              {/* Receipt Email Address */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-neutral-500 uppercase tracking-widest block">Receipt Email</label>
                <input 
                  type="email" 
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="supporter@example.com"
                  className="w-full px-4 py-3 border border-neutral-300 rounded-2xl text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-brand-green focus:border-transparent transition-all"
                  required
                />
              </div>

              {/* Card Number */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-neutral-500 uppercase tracking-widest block">Card Number</label>
                <div className="relative">
                  <input 
                    type="text" 
                    value={cardNumber}
                    onChange={handleCardNumberChange}
                    placeholder="4242 4242 4242 4242"
                    className="w-full pl-4 pr-12 py-3 border border-neutral-300 rounded-2xl text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-brand-green focus:border-transparent font-mono tracking-wider transition-all"
                    required
                  />
                  <div className="absolute right-3.5 top-3 flex items-center">
                    <span className="font-extrabold text-[9px] bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded-md border border-indigo-200">
                      VISA
                    </span>
                  </div>
                </div>
              </div>

              {/* Expiry and CVV Row */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-neutral-500 uppercase tracking-widest block font-sans">Expiry Date</label>
                  <input 
                    type="text" 
                    value={expiry}
                    onChange={handleExpiryChange}
                    placeholder="MM/YY"
                    className="w-full px-4 py-3 border border-neutral-300 rounded-2xl text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-brand-green focus:border-transparent font-mono tracking-wider transition-all"
                    required
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-neutral-500 uppercase tracking-widest block select-none">CVC / CVV</label>
                  <input 
                    type="text" 
                    value={cvc}
                    onChange={handleCvcChange}
                    placeholder="123"
                    className="w-full px-4 py-3 border border-neutral-300 rounded-2xl text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-brand-green focus:border-transparent font-mono tracking-wider transition-all"
                    required
                  />
                </div>
              </div>

              {/* Cardholder Name */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-neutral-500 uppercase tracking-widest block font-sans">Name on Card</label>
                <input 
                  type="text" 
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Jane Doe"
                  className="w-full px-4 py-3 border border-neutral-300 rounded-2xl text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-brand-green focus:border-transparent transition-all"
                  required
                />
              </div>

              {/* Action Buttons */}
              <div className="pt-4 space-y-3">
                <button 
                  type="submit"
                  className="w-full py-4 bg-brand-green text-brand-yellow font-black text-sm uppercase tracking-wider rounded-3xl border-2 border-brand-green hover:scale-[1.02] active:scale-[0.98] transition-all shadow-xl shadow-brand-green/20"
                >
                  Pay ${amount + (platformSupport ? 1 : 0)}.00 securely
                </button>
                <button 
                  type="button" 
                  onClick={onCancel}
                  className="w-full py-3.5 bg-neutral-100 hover:bg-neutral-200 text-neutral-600 font-bold text-xs uppercase tracking-wider rounded-3xl transition-all"
                >
                  Go Back
                </button>
              </div>
            </motion.form>
          )}

          {isProcessing && (
            <motion.div 
              key="processing"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.05 }}
              className="flex flex-col items-center justify-center py-12 space-y-6 text-center"
            >
              <div className="relative">
                <div className="w-16 h-16 border-4 border-brand-green/20 border-t-brand-green rounded-full animate-spin"></div>
                <RefreshCw className="w-6 h-6 text-brand-green absolute inset-0 m-auto animate-pulse" />
              </div>
              <div className="space-y-2">
                <h3 className="font-black text-lg text-brand-green uppercase tracking-tight">Processing Payment</h3>
                <p className="text-xs text-neutral-500 min-h-[16px] animate-pulse">
                  {processingStep}
                </p>
              </div>
            </motion.div>
          )}

          {paymentSuccess && (
            <motion.div 
              key="success"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="flex flex-col items-center justify-center py-12 space-y-6 text-center"
            >
              <motion.div 
                initial={{ rotate: -180, scale: 0 }}
                animate={{ rotate: 0, scale: 1 }}
                transition={{ type: 'spring', stiffness: 100 }}
              >
                <CheckCircle className="w-20 h-20 text-emerald-500 fill-emerald-50" />
              </motion.div>
              <div className="space-y-2">
                <h3 className="font-black text-2xl text-emerald-800 uppercase tracking-tight italic">Sponsorship Successful!</h3>
                <p className="text-xs text-brand-green/80 font-semibold px-6 leading-relaxed">
                  Thank you for your generous hand up! Redirecting back to Oklahoma City's digital coordinate dashboard...
                </p>
              </div>
              <div className="inline-flex items-center gap-1.5 text-[10px] text-neutral-400 font-bold uppercase tracking-widest pt-4">
                <Lock className="w-3 h-3" />
                <span>Simulated Settlement Complete</span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

    </div>
  );
}

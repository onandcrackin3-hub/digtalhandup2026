/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { US_STATES, STATE_SEALS } from './UsaStatesData';
import React, { useState, useEffect, useRef } from 'react';
import { Volume2, VolumeX, Mic } from 'lucide-react';
import { Scanner, IDetectedBarcode } from '@yudiel/react-qr-scanner';
import { 
  Home, 
  Hand,
  HandHeart, 
  MapPin, 
  MessageCircle, 
  User, 
  PlusCircle,
  Package,
  Search,
  Bell,
  LogOut,
  LogIn,
  MoreVertical,
  Printer,
  DollarSign,
  QrCode,
  Share2,
  Trash2,
  Target,
  Handshake,
  PawPrint,
  ExternalLink,
  Save,
  Shield,
  Camera,
  ChevronLeft,
  ChevronRight,
  X,
  Layers,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Phone,
  Heart,
  Users,
  Info,
  Globe,
  Star,
  LifeBuoy,
  AlertCircle,
  CreditCard,
  HelpCircle,
  Sparkles,
  Play,
  ShieldAlert,
  Image as ImageIcon,
  Bus,
  Activity
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  APIProvider, 
  useMapsLibrary 
} from '@vis.gl/react-google-maps';
import { cn } from './lib/utils';
import { 
  db, 
  auth, 
  handleFirestoreError, 
  OperationType 
} from './lib/backend';
import { 
  onAuthStateChanged, 
  signInWithPopup, 
  GoogleAuthProvider,
  signOut,
  type User as AuthUser
} from './lib/backend';
import { 
  collection, 
  query, 
  orderBy, 
  onSnapshot, 
  addDoc, 
  setDoc,
  doc,
  getDoc,
  deleteDoc,
  serverTimestamp,
  getDocs,
  type Timestamp,
  storage,
  ref,
  uploadBytes,
  getDownloadURL,
  deleteObject
} from './lib/backend';
import { QRCodeSVG } from 'qrcode.react';
import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';

// Import local assets
import charityBackground from './assets/images/okc_charity_bg_1779014737840.png';
import brandLogo from './assets/images/digital_hand_up_logo_1779251043334.png';
import PrivacyPolicy from './components/PrivacyPolicy';
import SandboxCheckout from './components/SandboxCheckout';
import WelcomeOnboardingModal from './components/WelcomeOnboardingModal';
import PhotoRolodex from './components/PhotoRolodex';
import MentalHealthSupport from './components/MentalHealthSupport';
import DiversionScreening from './components/DiversionScreening';
import WorkforcePipeline from './components/WorkforcePipeline';
import MethadoneTreatment from './components/MethadoneTreatment';
import SoonercareScreen from './components/SoonercareScreen';

// Logo Component
function AppLogo({ className, imgClassName }: { className?: string; imgClassName?: string }) {
  return (
    <div className={cn("relative flex items-center justify-center overflow-hidden shrink-0", className)}>
        <img 
          src={brandLogo} 
          alt="Digital Hand Up Logo" 
          style={{ maxWidth: '100%', maxHeight: '100%', width: 'auto', height: 'auto', objectFit: 'contain' }}
          className={cn("shrink-0", imgClassName)} 
        />
    </div>
  );
}

// Types
interface SupportRequest {
  id: string;
  userId: string;
  type: 'Food' | 'Supplies' | 'Transport' | 'Other';
  title: string;
  location: string;
  description: string;
  timestamp: Timestamp;
  urgent: boolean;
  status: 'open' | 'pending' | 'fulfilled' | 'cancelled';
}

interface CommunityPost {
  id: string;
  userId: string;
  userName: string;
  userPhoto: string;
  type: 'offer' | 'request';
  category: 'Goods' | 'Rides' | 'Food' | 'Other';
  title: string;
  description: string;
  contactInfo: string;
  timestamp: Timestamp;
}

export interface UserProfile {
  userId: string;
  displayName: string;
  photoURL: string;
  email: string;
  bio?: string;
  state?: string;
  hasPet?: boolean;
  shortTermGoals?: string;
  longTermGoals?: string;
  cashAppId?: string;
  venmoId?: string;
  payPalId?: string;
  zelleId?: string;
  chimeId?: string;
  allRegistryUrl?: string;
  joinedAt: Timestamp;
  contributionsCount: number;
  location?: string;
}

export interface PhotoComment {
  id: string;
  userId: string;
  userName: string;
  text: string;
  timestamp: number;
}

export interface PhotoGalleryItem {
  id: string;
  userId: string;
  imageUrl: string;
  storagePath?: string;
  note: string;
  createdAt: Timestamp;
  likes?: string[];
  comments?: PhotoComment[];
}

interface NewsItem {
  title: string;
  summary: string;
  source: string;
  url?: string;
  date?: string;
}

export default function App() {
  const [isQRScannerActive, setIsQRScannerActive] = useState(false);
  const [activeTab, setActiveTab ] = useState<'home' | 'map' | 'add' | 'inbox' | 'profile' | 'admin' | 'support' | 'workforce'>('home');
  const [isOnboardingOpen, setIsOnboardingOpen] = useState(false);
  const [user, setUser] = useState<AuthUser | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [requests, setRequests] = useState<SupportRequest[]>([]);
  const [adminUsers, setAdminUsers] = useState<UserProfile[]>([]);
  const [selectedAdminUser, setSelectedAdminUser] = useState<UserProfile | null>(null);
  const [news, setNews] = useState<NewsItem[]>([]);
  const [isLiveNews, setIsLiveNews ] = useState(false);
  const [loading, setLoading] = useState(true);
  const [newsLoading, setNewsLoading] = useState(false);
  const [newsError, setNewsError] = useState<string | null>(null);
  const [adminLoading, setAdminLoading] = useState(false);
  const [selectedRequest, setSelectedRequest] = useState<SupportRequest | null>(null);

  // Community Bulletin / Post Board States
  const [boardPosts, setBoardPosts] = useState<CommunityPost[]>([]);
  const [boardLoading, setBoardLoading] = useState(true);
  const [isCreatingPost, setIsCreatingPost] = useState(false);
  const [newBoardPost, setNewBoardPost] = useState({
    type: 'offer' as 'offer' | 'request',
    category: 'Goods' as 'Goods' | 'Rides' | 'Food' | 'Other',
    title: '',
    description: '',
    contactInfo: ''
  });
  const [isSubmittingPost, setIsSubmittingPost] = useState(false);
  const [postModerativeFeedback, setPostModerativeFeedback] = useState<string | null>(null);
  const [activeBoardFilter, setActiveBoardFilter] = useState<'All' | 'Offers' | 'Requests'>('All');
  const [activeBoardCategory, setActiveBoardCategory] = useState<'All' | 'Goods' | 'Rides' | 'Food' | 'Other'>('All');
  const [requestFeedFilter, setRequestFeedFilter] = useState<string>('All Needs');
  
  // New Request Form State
  const [newRequest, setNewRequest] = useState({
    type: 'Food' as SupportRequest['type'],
    title: '',
    description: '',
    location: '',
    urgent: false
  });

  // Public Profile State
  const [publicUserId, setPublicUserId] = useState<string | null>(null);
  const [publicProfile, setPublicProfile] = useState<UserProfile | null>(null);
  const [publicProfileLoading, setPublicProfileLoading] = useState(false);

  // Edit Profile Mode
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [editedProfile, setEditedProfile] = useState<Partial<UserProfile>>({});
  const [isUpdatingProfile, setIsUpdatingProfile] = useState(false);
  const [showPrivacyPolicy, setShowPrivacyPolicy] = useState(false);
  const [sandboxPayment, setSandboxPayment] = useState<{ amount: number; userId: string; platformSupport?: boolean } | null>(null);
  const [updateError, setUpdateError] = useState<string | null>(null);
  const [authError, setAuthError] = useState<string | null>(null);
  const [selectedAmount, setSelectedAmount] = useState<string | null>('10');
  const [copied, setCopied] = useState(false);
  const [selectedResource, setSelectedResource] = useState<'shelter' | 'pantry' | null>(null);
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  // Photo Gallery State
  const [userPhotos, setUserPhotos] = useState<PhotoGalleryItem[]>([]);
  const [isPhotosLoading, setIsPhotosLoading] = useState(false);
  const [isAddingPhoto, setIsAddingPhoto] = useState(false);
  const [photoNote, setPhotoNote] = useState('');
  const [photoFiles, setPhotoFiles] = useState<File[]>([]);
  const [isUploadingPhoto, setIsUploadingPhoto] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [photoGalleryUserId, setPhotoGalleryUserId] = useState<string | null>(null);
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);
  const [previewUrls, setPreviewUrls] = useState<string[]>([]);
  const photoGalleryFileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const urls = photoFiles.map(file => URL.createObjectURL(file));
    setPreviewUrls(urls);
    return () => {
      urls.forEach(url => URL.revokeObjectURL(url));
    };
  }, [photoFiles]);

  // Gemini Voice, Speech & TTS System State
  const [voicePreference, setVoicePreference] = useState<'Zephyr' | 'Kore' | 'Puck' | 'Fenrir' | 'Charon'>('Zephyr');
  const [speakingTextId, setSpeakingTextId] = useState<string | null>(null);
  const [isTtsLoading, setIsTtsLoading] = useState(false);
  const [activeAudio, setActiveAudio] = useState<{ source?: AudioBufferSourceNode; context?: AudioContext } | null>(null);

  // Companion Chat state
  const [companionChatOpen, setCompanionChatOpen] = useState(false);
  const [companionInput, setCompanionInput] = useState('');
  const [isListeningMic, setIsListeningMic] = useState(false);
  const [isCompanionTyping, setIsCompanionTyping] = useState(false);
  const [companionMessages, setCompanionMessages] = useState<Array<{ id: string; sender: 'user' | 'assistant'; text: string }>>([
    {
      id: 'welcome',
      sender: 'assistant',
      text: "Hello! I am your Hand Up AI Companion. I can help guide you to OKC resources like shelters, pantry maps, or answer questions about the community. Tap the speaker to hear me speak, or tap the mic to speak to me!"
    }
  ]);

  const stopSpeaking = () => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
      } catch (e) {}
    }
    if (activeAudio) {
      try {
        activeAudio.source?.stop();
      } catch (e) {}
      try {
        activeAudio.context?.close();
      } catch (e) {}
      setActiveAudio(null);
    }
    setSpeakingTextId(null);
  };

  const speakText = async (textId: string, textToSpeak: string) => {
    if (speakingTextId === textId) {
      stopSpeaking();
      return;
    }
    
    stopSpeaking();
    setIsTtsLoading(true);
    setSpeakingTextId(textId);

    // Try browser-native SpeechSynthesis first for INSTANT zero-latency clear narration
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      try {
        // Cancel any pending speech
        window.speechSynthesis.cancel();

        // Standardize the plain text for speaking
        const cleanedText = textToSpeak
          .replace(/[#*_`]/g, '') // remove markdown symbols
          .replace(/Step \w+:/gi, '') // minor speech cleanups
          .trim();

        const utterance = new SpeechSynthesisUtterance(cleanedText);
        
        // Find optimal warm english narration voice
        const voices = window.speechSynthesis.getVoices();
        const englishVoice = voices.find(v => 
          v.lang.startsWith('en-US') && (v.name.includes('Google') || v.name.includes('Natural') || v.name.includes('Siri'))
        ) || voices.find(v => v.lang.startsWith('en-')) || voices[0];
        
        if (englishVoice) {
          utterance.voice = englishVoice;
        }

        // The user explicitly requested an easier to understand, slower, and smoother pacing:
        utterance.rate = 0.88; // 12% slower than standard rate for highly legible, cozy reading alongside narration
        utterance.pitch = 1.0;

        utterance.onstart = () => {
          setIsTtsLoading(false);
          setSpeakingTextId(textId);
        };

        utterance.onend = () => {
          setSpeakingTextId(null);
        };

        utterance.onerror = (e) => {
          console.warn("SpeechSynthesis utterance error, falling back:", e);
          // Only falls back to API if synthesis raises an active error during start
          if (speakingTextId === textId) {
            triggerApiTtsFallback(textId, textToSpeak);
          }
        };

        window.speechSynthesis.speak(utterance);
        return;
      } catch (synthErr) {
        console.error("Native voice synthesis failed to trigger:", synthErr);
      }
    }

    // Failover directly to API if native synthesis is unavailable
    await triggerApiTtsFallback(textId, textToSpeak);
  };

  const triggerApiTtsFallback = async (textId: string, textToSpeak: string) => {
    try {
      const response = await fetch('/api/ai/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: textToSpeak, voice: voicePreference })
      });
      
      if (!response.ok) {
        throw new Error("Failed to generate speech from Gemini API");
      }
      
      const data = await response.json();
      if (data.audio) {
        const sampleRate = data.sampleRate || 24000;
        const binaryString = window.atob(data.audio);
        const len = binaryString.length;
        const bytes = new Uint8Array(len);
        for (let i = 0; i < len; i++) {
          bytes[i] = binaryString.charCodeAt(i);
        }
        
        const arrayBuffer = bytes.buffer;
        const dataView = new DataView(arrayBuffer);
        const numSamples = arrayBuffer.byteLength / 2;
        
        const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate });
        const audioBuffer = audioContext.createBuffer(1, numSamples, sampleRate);
        const channelData = audioBuffer.getChannelData(0);
        
        for (let i = 0; i < numSamples; i++) {
          const sample = dataView.getInt16(i * 2, true);
          channelData[i] = sample / 32768.0;
        }
        
        const source = audioContext.createBufferSource();
        source.buffer = audioBuffer;
        source.connect(audioContext.destination);
        
        source.onended = () => {
          setSpeakingTextId(null);
          setActiveAudio(null);
        };
        
        source.start();
        setActiveAudio({ source, context: audioContext });
      }
    } catch (error) {
      console.error("Speak API fallback error:", error);
      setSpeakingTextId(null);
    } finally {
      setIsTtsLoading(false);
    }
  };

  const startSpeechRecognition = () => {
    const SpeechRecognitionAPI = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognitionAPI) {
      setUpdateError("Speech recognition is not supported in this browser. Please type your message.");
      return;
    }
    
    const rec = new SpeechRecognitionAPI();
    rec.continuous = false;
    rec.interimResults = false;
    rec.lang = 'en-US';
    
    rec.onstart = () => {
      setIsListeningMic(true);
    };
    
    rec.onresult = (event: any) => {
      const text = event.results[0][0].transcript;
      if (text) {
        setCompanionInput(text);
      }
    };
    
    rec.onerror = (event: any) => {
      console.error("Speech Recognition error:", event.error);
      setIsListeningMic(false);
    };
    
    rec.onend = () => {
      setIsListeningMic(false);
    };
    
    rec.start();
  };

  const handleSendCompanionMessage = async () => {
    if (!companionInput.trim() || isCompanionTyping) return;
    
    const userMsg = companionInput;
    setCompanionInput('');
    
    const userMsgId = 'user-' + Date.now();
    const newMsgs = [
      ...companionMessages,
      { id: userMsgId, sender: 'user' as const, text: userMsg }
    ];
    setCompanionMessages(newMsgs);
    setIsCompanionTyping(true);
    
    try {
      const historyPayload = companionMessages.map(m => ({
        role: m.sender === 'assistant' ? 'assistant' : 'user',
        text: m.text
      }));
      
      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: userMsg, history: historyPayload })
      });
      
      if (!res.ok) throw new Error("Failed to contact the Hand Up AI companion");
      const data = await res.json();
      
      const assistantMsgId = 'assistant-' + Date.now();
      const finalMsgs = [
        ...newMsgs,
        { id: assistantMsgId, sender: 'assistant' as const, text: data.text }
      ];
      setCompanionMessages(finalMsgs);
      
      // Speak the response automatically!
      speakText(assistantMsgId, data.text);
    } catch (err: any) {
      console.error(err);
      setCompanionMessages(prev => [
        ...prev,
        { id: 'err-' + Date.now(), sender: 'assistant', text: "I'm having a little trouble connecting right now, but please know we are here for you. Hand Up!" }
      ]);
    } finally {
      setIsCompanionTyping(false);
    }
  };

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' } });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      setIsCameraOpen(true);
      setUpdateError(null);
    } catch (err) {
      console.error("Camera error:", err);
      setUpdateError("Camera access denied or not available. Check permissions.");
    }
  };

  const stopCamera = () => {
    const stream = videoRef.current?.srcObject as MediaStream;
    stream?.getTracks().forEach(track => track.stop());
    setIsCameraOpen(false);
  };

  const capturePhoto = () => {
    if (videoRef.current) {
      const video = videoRef.current;
      const MAX_DIM = 800;
      let width = video.videoWidth;
      let height = video.videoHeight;

      if (width > height) {
        if (width > MAX_DIM) {
          height *= MAX_DIM / width;
          width = MAX_DIM;
        }
      } else {
        if (height > MAX_DIM) {
          width *= MAX_DIM / height;
          height = MAX_DIM;
        }
      }

      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      ctx?.drawImage(video, 0, 0, width, height);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
      setEditedProfile(prev => ({ ...prev, photoURL: dataUrl }));
      stopCamera();
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Show loading or clear error if needed
      setUpdateError(null);

      const reader = new FileReader();
      reader.onload = (event) => {
        const img = new Image();
        img.onload = () => {
          // Max dimension
          const MAX_WIDTH = 800;
          const MAX_HEIGHT = 800;
          let width = img.width;
          let height = img.height;

          if (width > height) {
            if (width > MAX_WIDTH) {
              height *= MAX_WIDTH / width;
              width = MAX_WIDTH;
            }
          } else {
            if (height > MAX_HEIGHT) {
              width *= MAX_HEIGHT / height;
              height = MAX_HEIGHT;
            }
          }

          const canvas = document.createElement('canvas');
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          ctx?.drawImage(img, 0, 0, width, height);

          // Get the base64 string with compression
          const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
          
          // Check if still somehow too large (rare with 800px)
          if (dataUrl.length > 2 * 1024 * 1024) {
             setUpdateError("Image is still too large. Please use a smaller photo.");
             return;
          }
          
          setEditedProfile(prev => ({ ...prev, photoURL: dataUrl }));
        };
        img.src = event.target?.result as string;
      };
      reader.readAsDataURL(file);
    }
  };

  const isDev = typeof window !== 'undefined' && window.location.hostname.includes('ais-dev');
  const GOOGLE_MAPS_API_KEY = (import.meta as any).env?.VITE_GOOGLE_MAPS_PLATFORM_KEY || '';

  const getPublicUrl = (uid: string) => {
    if (typeof window === 'undefined') return '';
    const origin = window.location.origin;
    return `${origin}${window.location.pathname}?u=${uid}`;
  };

  // URL Query Param Check
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const uId = params.get('u');
    if (uId) {
      setPublicUserId(uId);
    }
    
    // Check for sandbox checkout simulation
    const isSandbox = params.get('sandbox_payment') === 'true';
    if (isSandbox) {
      const amount = parseInt(params.get('amount') || '10', 10);
      const userId = params.get('userId') || 'anonymous';
      const platformSupport = params.get('platformSupport') === 'true';
      setSandboxPayment({ amount, userId, platformSupport });
      return;
    }
    
    // Check for payment status
    const paymentStatus = params.get('payment');
    if (paymentStatus === 'success') {
       setUpdateError("THANK YOU! Your sponsorship was processed successfully. (Test Mode)");
    } else if (paymentStatus === 'cancelled') {
       setUpdateError("Sponsorship cancelled. No funds were moved.");
    }
    
    // Check for privacy policy path or parameter
    if (window.location.pathname === '/privacy-policy' || params.get('view') === 'privacy') {
      setShowPrivacyPolicy(true);
    }
  }, []);

  // Fetch Public Profile
  useEffect(() => {
    if (publicUserId) {
      const fetchPublicProfile = async () => {
        setPublicProfileLoading(true);
        try {
          const userSnap = await getDoc(doc(db, 'users', publicUserId));
          if (userSnap.exists()) {
            setPublicProfile(userSnap.data() as UserProfile);
          }
        } catch (err) {
          handleFirestoreError(err, OperationType.GET, `users/${publicUserId}`);
        } finally {
          setPublicProfileLoading(false);
        }
      };
      fetchPublicProfile();
    }
  }, [publicUserId]);

  // Fetch Photo Gallery
  useEffect(() => {
    const targetUserId = publicUserId || (user ? user.uid : null);
    if (!targetUserId) {
      setUserPhotos([]);
      return;
    }

    setIsPhotosLoading(true);
    const q = query(
      collection(db, 'gallery'),
      // orderBy doesn't work well without indexing if we also filter by userId, let's filter and let client sort or index. Actually, lets just query all and filter, or query by userId.
    );
    // Realtime listener
    const unsubscribe = onSnapshot(collection(db, `users/${targetUserId}/photos`), (snapshot) => {
      const photosData: PhotoGalleryItem[] = [];
      snapshot.forEach((docSnap) => {
        photosData.push({ id: docSnap.id, ...docSnap.data() } as PhotoGalleryItem);
      });
      photosData.sort((a, b) => b.createdAt?.toMillis() - a.createdAt?.toMillis());
      setUserPhotos(photosData);
      setIsPhotosLoading(false);
    }, (error) => {
      console.error("Error fetching photos", error);
      setIsPhotosLoading(false);
    });

    return () => unsubscribe();
  }, [publicUserId, user]);

  // Auth Listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
    });
    return () => unsubscribe();
  }, []);

  // Profile Listener
  useEffect(() => {
    if (!user) {
      setProfile(null);
      return;
    }

    const userRef = doc(db, 'users', user.uid);
    const unsubscribe = onSnapshot(userRef, async (snap) => {
      if (!snap.exists()) {
        const newProfile = {
          userId: user.uid,
          displayName: user.displayName || 'Anonymous',
          photoURL: user.photoURL || '',
          email: user.email || '',
          joinedAt: serverTimestamp(),
          contributionsCount: 0
        };
        try {
          await setDoc(userRef, newProfile);
          setIsOnboardingOpen(true);
        } catch (err) {
          handleFirestoreError(err, OperationType.WRITE, `users/${user.uid}`);
        }
      } else {
        setProfile(snap.data() as UserProfile);
      }
    }, (err) => {
      handleFirestoreError(err, OperationType.GET, `users/${user.uid}`);
    });

    return () => unsubscribe();
  }, [user]);

  // Requests Listener
  useEffect(() => {
    const q = query(collection(db, 'requests'), orderBy('timestamp', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const docs = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as SupportRequest[];
      setRequests(docs);
      setLoading(false);
    }, (err) => {
      handleFirestoreError(err, OperationType.LIST, 'requests');
    });
    return () => unsubscribe();
  }, [user]);

  // Community Board Posts Listener
  useEffect(() => {
    const q = query(collection(db, 'community_posts'), orderBy('timestamp', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const docs = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as CommunityPost[];
      setBoardPosts(docs);
      setBoardLoading(false);
    }, (err) => {
      handleFirestoreError(err, OperationType.LIST, 'community_posts');
      setBoardLoading(false);
    });
    return () => unsubscribe();
  }, [user]);

  const handleSubmitBoardPost = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    if (!newBoardPost.title.trim() || !newBoardPost.description.trim() || !newBoardPost.contactInfo.trim()) {
      setPostModerativeFeedback("All fields are required to submit.");
      return;
    }

    setIsSubmittingPost(true);
    setPostModerativeFeedback(null);

    // Client-side quick filter
    const badWords = ['nsfw', 'porn', 'sex', 'fuck', 'shit', 'pussy', 'dick', 'asshole', 'cock', 'vulgar', 'advertise', 'marketing'];
    const textToCheck = `${newBoardPost.title} ${newBoardPost.description} ${newBoardPost.contactInfo}`.toLowerCase();
    const hasBad = badWords.some(w => textToCheck.includes(w));
    if (hasBad) {
      setPostModerativeFeedback("SAFETY REJECTION: Profanity, sexual content, spam, or promotional advertising are strictly prohibited.");
      setIsSubmittingPost(false);
      return;
    }

    try {
      const modRes = await fetch('/api/ai/moderate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          bio: `Post Board Submission\nTitle: ${newBoardPost.title}\nDescription: ${newBoardPost.description}\nContact: ${newBoardPost.contactInfo}`,
          type: 'community_post'
        })
      });

      if (modRes.ok) {
        const modData = await modRes.json();
        if (!modData.isSafe) {
          setPostModerativeFeedback(`REJECTED BY STANDARDS: ${modData.reason || 'Contains inappropriate, commercial, or adult content.'}`);
          setIsSubmittingPost(false);
          return;
        }
      }
    } catch (modErr) {
      console.warn("Moderation skipped due to error:", modErr);
    }

    try {
      const postId = `post_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      await setDoc(doc(db, 'community_posts', postId), {
        userId: user.uid,
        userName: profile?.displayName || user.displayName || 'Anonymous Member',
        userPhoto: profile?.photoURL || user.photoURL || '',
        type: newBoardPost.type,
        category: newBoardPost.category,
        title: newBoardPost.title.trim(),
        description: newBoardPost.description.trim(),
        contactInfo: newBoardPost.contactInfo.trim(),
        timestamp: serverTimestamp()
      });

      setNewBoardPost({
        type: 'offer',
        category: 'Goods',
        title: '',
        description: '',
        contactInfo: ''
      });
      setIsCreatingPost(false);
    } catch (err: any) {
      console.error("Firestore board post error:", err);
      setPostModerativeFeedback("Failed to save post. Please try again.");
    } finally {
      setIsSubmittingPost(false);
    }
  };

  const handleDeleteBoardPost = async (postId: string) => {
    if (!user) return;
    try {
      await deleteDoc(doc(db, 'community_posts', postId));
    } catch (err) {
      console.error("Delete board post error:", err);
    }
  };

  const handleDeleteSupportRequest = async (requestId: string) => {
    if (!user) return;
    try {
      await deleteDoc(doc(db, 'requests', requestId));
    } catch (err) {
      console.error("Delete support request error:", err);
    }
  };

  // Fetch Admin Users Helper
  const fetchAdminUsers = async () => {
    if (!user || user.email !== 'onandcrackin3@gmail.com') return;
    setAdminLoading(true);
    try {
      const querySnapshot = await getDocs(collection(db, 'users'));
      const usersList: UserProfile[] = [];
      querySnapshot.forEach((docSnap) => {
        usersList.push({
          userId: docSnap.id,
          ...docSnap.data()
        } as UserProfile);
      });
      setAdminUsers(usersList);
    } catch (err) {
      console.error("Client side admin users fetch error:", err);
    } finally {
      setAdminLoading(false);
    }
  };

  useEffect(() => {
    if (activeTab === 'admin' && user?.email === 'onandcrackin3@gmail.com') {
      fetchAdminUsers();
    }
  }, [activeTab, user]);

  // Fetch News Helper
  const fetchNews = async () => {
    setNewsLoading(true);
    setNewsError(null);
    try {
      const response = await fetch('/api/news');
      if (!response.ok) {
        throw new Error(`Technical HTTP status ${response.status}`);
      }
      const data = await response.json();
      if (data.error) {
        throw new Error(data.error);
      }
      setNews(data.news || []);
      setIsLiveNews(data.live === true);
    } catch (err: any) {
      console.error("Error fetching news:", err);
      // Simplify network error message for users
      if (err.message === "Failed to fetch" || err.message.includes("NetworkError")) {
        setNewsError("We're having trouble connecting to the network right now. We'll try again shortly.");
      } else {
        setNewsError(err.message || 'Failed to fetch live updates. Please try again.');
      }
    } finally {
      setNewsLoading(false);
    }
  };

  useEffect(() => {
    // Fetch news Once on mount or when home tab is active
    if (activeTab === 'home' && news.length === 0) {
      fetchNews();
    }
  }, [activeTab]);

  const handleSignIn = async () => {
    const provider = new GoogleAuthProvider();
    provider.setCustomParameters({ prompt: 'select_account' });
    console.log("Initiating Google Sign-In...");
    try {
      const result = await signInWithPopup(auth, provider);
      console.log("Sign-in successful for user:", result.user.uid);
      setAuthError(null);
    } catch (err: any) {
      console.error('Sign-in error:', err instanceof Error ? err.message : String(err));
      // In shared previews, popup blocking is frequent
      if (err?.code === 'auth/popup-blocked' || err?.code === 'auth/cancelled-popup-request') {
         setAuthError("Sign-in popup was blocked. Please open this app in a new tab using the diagonal arrow icon at the top right.");
      } else if (err?.code === 'auth/unauthorized-domain') {
         setAuthError("Domain not authorized. Use the 'Export' menu to run this locally.");
      } else {
         setAuthError(`Sign-in failed: ${err?.message || 'Unknown error'}. Try opening the app in a new tab.`);
      }
    }
  };

  const handleSignOut = () => {
    signOut(auth);
    setProfile(null);
  };

  const handleCopyLink = (uid: string) => {
    const url = getPublicUrl(uid);
    navigator.clipboard.writeText(url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleUpdateProfile = async () => {
    if (!user || !profile) return;
    setIsUpdatingProfile(true);
    setUpdateError(null);

    try {
      // 0. Basic Client-side Link Check
      const urlRegex = /(https?:\/\/[^\s]+)|(www\.[^\s]+)/gi;
      if (editedProfile.bio && urlRegex.test(editedProfile.bio)) {
        setUpdateError("Links are not allowed in the bio for safety and security. Please remove any URLs.");
        setIsUpdatingProfile(false);
        return;
      }

      // 1. Content Moderation Check
      try {
        const modResponse = await fetch('/api/ai/moderate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ 
            bio: editedProfile.bio, 
            photoURL: editedProfile.photoURL,
            type: 'profile_bio'
          })
        });

        if (modResponse.ok) {
          const modData = await modResponse.json();
          if (!modData.isSafe) {
            setUpdateError(`SAFETY ALERT: ${modData.reason || 'Content contains elements incompatible with helpful community standards.'}`);
            setIsUpdatingProfile(false);
            return;
          }
        }
      } catch (modErr: any) {
        console.warn("AI Moderation skipped:", modErr);
      }

      // 2. Proceed with update if safe
      const cleaned = { ...editedProfile };
      if (cleaned.cashAppId) cleaned.cashAppId = cleaned.cashAppId.trim().replace(/^[$@]/, '');
      if (cleaned.venmoId) cleaned.venmoId = cleaned.venmoId.trim().replace(/^[@$]/, '');
      if (cleaned.payPalId) cleaned.payPalId = cleaned.payPalId.trim().replace(/^[@$]/, '');
      if (cleaned.zelleId) cleaned.zelleId = cleaned.zelleId.trim();
      if (cleaned.chimeId) cleaned.chimeId = cleaned.chimeId.trim();
      if (cleaned.allRegistryUrl) {
        cleaned.allRegistryUrl = cleaned.allRegistryUrl.trim();
        if (!/^https?:\/\//i.test(cleaned.allRegistryUrl)) {
          cleaned.allRegistryUrl = `https://${cleaned.allRegistryUrl}`;
        }
      }

      await setDoc(doc(db, 'users', user.uid), cleaned, { merge: true });
      setProfile(prev => prev ? ({ ...prev, ...cleaned }) : null);
      setIsEditingProfile(false);
    } catch (err) {
      setUpdateError("Failed to update profile. Please check your information and try again.");
      handleFirestoreError(err, OperationType.UPDATE, `users/${user.uid}`);
    } finally {
      setIsUpdatingProfile(false);
    }
  };

  const handleAddPhoto = async () => {
    if (!user || photoFiles.length === 0) return;
    setIsUploadingPhoto(true);
    setUploadError(null);
    try {
      await Promise.all(photoFiles.map(async (file) => {
        const compressImage = (file: File): Promise<string> => {
          return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = (event) => {
              const img = new Image();
              img.src = event.target?.result as string;
              img.onload = () => {
                const canvas = document.createElement('canvas');
                let width = img.width;
                let height = img.height;
                const MAX_SIZE = 800;
                
                if (width > height) {
                  if (width > MAX_SIZE) {
                    height *= MAX_SIZE / width;
                    width = MAX_SIZE;
                  }
                } else {
                  if (height > MAX_SIZE) {
                    width *= MAX_SIZE / height;
                    height = MAX_SIZE;
                  }
                }
                
                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                if (ctx) {
                  ctx.drawImage(img, 0, 0, width, height);
                  const dataUrl = canvas.toDataURL('image/jpeg', 0.7);
                  resolve(dataUrl);
                } else {
                  reject(new Error("Canvas context is null"));
                }
              };
              img.onerror = (error) => reject(error);
            };
            reader.onerror = (error) => reject(error);
          });
        };

        const base64Image = await compressImage(file);

        // Save metadata in Firestore
        await addDoc(collection(db, `users/${user.uid}/photos`), {
          userId: user.uid,
          imageUrl: base64Image,
          note: photoNote,
          createdAt: serverTimestamp()
        });
      }));

      setPhotoFiles([]);
      setPhotoNote('');
      setIsAddingPhoto(false);
    } catch (err: any) {
      console.error("Error uploading photo:", err);
      setUploadError(err.message ? err.message + (err.code ? " (" + err.code + ")" : "") : JSON.stringify(err));
    } finally {
      setIsUploadingPhoto(false);
    }
  };

  const handleDeletePhoto = async (photo: PhotoGalleryItem) => {
    if (!user) return;
    try {
      await deleteDoc(doc(db, `users/${user.uid}/photos`, photo.id));
      
      // Delete from storage if we have the storage path
      if (photo.storagePath) {
        const fileRef = ref(storage, photo.storagePath);
        await deleteObject(fileRef).catch(console.warn);
      } else if (!photo.imageUrl.startsWith('data:image')) {
        // Fallback for older photos not using base64
        const fileRef = ref(storage, photo.imageUrl);
        await deleteObject(fileRef).catch(console.warn);
      }
    } catch (err) {
      console.error("Error deleting photo:", err);
    }
  };

  const handleSubmitRequest = async () => {
    if (!user) return;
    if (!newRequest.title || !newRequest.description || !newRequest.location) return;

    try {
      await addDoc(collection(db, 'requests'), {
        ...newRequest,
        userId: user.uid,
        timestamp: serverTimestamp(),
        status: 'open'
      });
      setActiveTab('home');
      setNewRequest({
        type: 'Food',
        title: '',
        description: '',
        location: '',
        urgent: false
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'requests');
    }
  };

  // Helper to transform oklch & oklab colors to rgb for html2canvas
  const replaceOklchAndOklab = (str: string): string => {
    if (typeof str !== 'string') return str;
    if (!str.includes('oklch') && !str.includes('oklab')) return str;

    const parsePercentageOrValue = (val: string, scale: number): number => {
      if (val.endsWith('%')) {
        return (parseFloat(val) / 100) * scale;
      }
      return parseFloat(val);
    };

    const oklabToRgb = (L: number, a: number, b: number, alpha: number): string => {
      const l_ = L + 0.3963377774 * a + 0.2158037573 * b;
      const m_ = L - 0.1055613458 * a - 0.0638541728 * b;
      const s_ = L - 0.0894841775 * a - 1.2914855414 * b;

      const l = l_ * l_ * l_;
      const m = m_ * m_ * m_;
      const s = s_ * s_ * s_;

      const r_lin = +4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s;
      const g_lin = -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s;
      const b_lin = -0.0041960863 * l - 0.7034186147 * m + 1.7076147010 * s;

      const f = (x: number) => x <= 0.0031308 ? 12.92 * x : 1.055 * Math.pow(x, 1 / 2.4) - 0.055;
      const compR = Math.round(Math.max(0, Math.min(1, f(r_lin))) * 255);
      const compG = Math.round(Math.max(0, Math.min(1, f(g_lin))) * 255);
      const compB = Math.round(Math.max(0, Math.min(1, f(b_lin))) * 255);

      return alpha === 1 ? `rgb(${compR}, ${compG}, ${compB})` : `rgba(${compR}, ${compG}, ${compB}, ${alpha})`;
    };

    let result = str.replace(/oklch\(([^)]+)\)/g, (_, content) => {
      try {
        const parts = content.trim().split(/[\s,+/]+/);
        if (parts.length < 3) return '#000000';
        const L = parsePercentageOrValue(parts[0], 1);
        const C = parsePercentageOrValue(parts[1], 1);
        const H = parseFloat(parts[2]);
        const alpha = parts[3] !== undefined ? parsePercentageOrValue(parts[3], 1) : 1;

        const hRad = (H * Math.PI) / 180;
        const a = C * Math.cos(hRad);
        const b = C * Math.sin(hRad);

        return oklabToRgb(L, a, b, alpha);
      } catch {
        return '#000000';
      }
    });

    result = result.replace(/oklab\(([^)]+)\)/g, (_, content) => {
      try {
        const parts = content.trim().split(/[\s,+/]+/);
        if (parts.length < 3) return '#000000';
        const L = parsePercentageOrValue(parts[0], 1);
        const a = parseFloat(parts[1]);
        const b = parseFloat(parts[2]);
        const alpha = parts[3] !== undefined ? parsePercentageOrValue(parts[3], 1) : 1;

        return oklabToRgb(L, a, b, alpha);
      } catch {
        return '#000000';
      }
    });

    return result;
  };

  const generatePDF = async (elementId: string, filename: string) => {
    const element = document.getElementById(elementId);
    if (!element) return;
    
    // Store original style to restore later
    const originalTransform = element.style.transform;
    const originalBoxShadow = element.style.boxShadow;
    const originalGetComputedStyle = window.getComputedStyle;
    
    // Temporarily optimize for capture
    element.style.transform = 'none';
    element.style.boxShadow = 'none';

    // Polyfill getComputedStyle to bypass oklch/oklab failures in html2canvas
    window.getComputedStyle = function (el, pseudoElt) {
      const style = originalGetComputedStyle(el, pseudoElt);
      return new Proxy(style, {
        get(target, prop) {
          const val = Reflect.get(target, prop);
          if (typeof val === 'string' && (val.includes('oklch') || val.includes('oklab'))) {
            return replaceOklchAndOklab(val);
          }
          if (typeof val === 'function') {
            return val.bind(target);
          }
          return val;
        }
      }) as unknown as CSSStyleDeclaration;
    };
    
    try {
      const canvas = await html2canvas(element, {
        scale: 3, // Good quality for print
        useCORS: true,
        allowTaint: true,
        backgroundColor: '#ffffff',
        logging: false
      });
      
      const imgData = canvas.toDataURL('image/jpeg', 1.0);
      
      // Create A4 PDF (210mm x 297mm)
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4'
      });
      
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = pdf.internal.pageSize.getHeight();
      
      // Maintain the actual aspect ratio of the captured canvas for accurate dimensions
      const aspect = canvas.height / canvas.width;
      
      // Calculate sizes to maximize A4 page usage with 2x2 layout
      const maxAvailableWidth = (pdfWidth - 10) / 2; // small margin around the complete grid
      const maxAvailableHeight = (pdfHeight - 15) / 2; // leave room at the bottom for instructions
      
      let flyerWidth = maxAvailableWidth;
      let flyerHeight = flyerWidth * aspect;
      
      if (flyerHeight > maxAvailableHeight) {
        flyerHeight = maxAvailableHeight;
        flyerWidth = flyerHeight / aspect;
      }
      
      // Calculate margins to perfectly center the 2x2 grid
      const gridWidth = flyerWidth * 2;
      const gridHeight = flyerHeight * 2;
      const marginX = (pdfWidth - gridWidth) / 2;
      const marginY = (pdfHeight - gridHeight) / 2.5; // shift slightly up to make room for text
      
      // Draw dashed cut lines for the center
      pdf.setDrawColor(200, 200, 200);
      pdf.setLineDashPattern([3, 3], 0);
      pdf.line(0, pdfHeight / 2, pdfWidth, pdfHeight / 2);
      pdf.line(pdfWidth / 2, 0, pdfWidth / 2, pdfHeight);

      // Add 4 flyers to the grid
      for (let row = 0; row < 2; row++) {
        for (let col = 0; col < 2; col++) {
          const x = marginX + (col * flyerWidth);
          const y = marginY + (row * flyerHeight);
          
          pdf.addImage(imgData, 'JPEG', x, y, flyerWidth, flyerHeight);
          
          // Draw solid border around each flyer for easy cutting
          pdf.setLineDashPattern([], 0);
          pdf.setDrawColor(30, 81, 40); // brand-green border
          pdf.setLineWidth(0.5);
          pdf.rect(x, y, flyerWidth, flyerHeight, 'S');
        }
      }
      
      // Add cutting instructions at the bottom
      pdf.setFontSize(8);
      pdf.setTextColor(150, 150, 150);
      pdf.text("Cut along the dotted lines and borders to separate flyers. Hand out to neighbors to support Digital Hand Up.", pdfWidth / 2, pdfHeight - 5, { align: 'center' });
      
      pdf.save(filename);
    } catch (err) {
      console.error("Error generating PDF:", err);
      alert("There was an issue generating the PDF. Please try again.");
    } finally {
      // Restore styles
      element.style.transform = originalTransform;
      element.style.boxShadow = originalBoxShadow;
      window.getComputedStyle = originalGetComputedStyle;
    }
  };

  const downloadImage = async (elementId: string, filename: string) => {
    const element = document.getElementById(elementId);
    if (!element) return;
    
    // Store original style to restore later
    const originalTransform = element.style.transform;
    const originalBoxShadow = element.style.boxShadow;
    const originalGetComputedStyle = window.getComputedStyle;
    
    // Temporarily optimize for capture
    element.style.transform = 'none';
    element.style.boxShadow = 'none';

    // Polyfill getComputedStyle to bypass oklch/oklab failures in html2canvas
    window.getComputedStyle = function (el, pseudoElt) {
      const style = originalGetComputedStyle(el, pseudoElt);
      return new Proxy(style, {
        get(target, prop) {
          const val = Reflect.get(target, prop);
          if (typeof val === 'string' && (val.includes('oklch') || val.includes('oklab'))) {
            return replaceOklchAndOklab(val);
          }
          if (typeof val === 'function') {
            return val.bind(target);
          }
          return val;
        }
      }) as unknown as CSSStyleDeclaration;
    };
    
    try {
      const canvas = await html2canvas(element, {
        scale: 2, // 2x for good quality while keeping performance
        useCORS: true,
        allowTaint: true,
        backgroundColor: '#ffffff',
        logging: false
      });
      
      const aspect = canvas.height / canvas.width;
      
      // Create a large canvas (approx standard print size)
      const outCanvas = document.createElement('canvas');
      const margin = 80;
      
      const singleWidth = 1000;
      const singleHeight = singleWidth * aspect;
      
      outCanvas.width = singleWidth * 2 + margin * 3;
      outCanvas.height = singleHeight * 2 + margin * 3 + 120;
      const ctx = outCanvas.getContext('2d');
      if (!ctx) return;
      
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, outCanvas.width, outCanvas.height);
      
      // Draw dashed cut lines
      ctx.strokeStyle = '#cccccc';
      ctx.setLineDash([15, 15]);
      ctx.lineWidth = 4;
      
      const midX = outCanvas.width / 2;
      const midY = (outCanvas.height - 120) / 2;
      
      ctx.beginPath();
      ctx.moveTo(0, midY);
      ctx.lineTo(outCanvas.width, midY);
      ctx.stroke();
      
      ctx.beginPath();
      ctx.moveTo(midX, 0);
      ctx.lineTo(midX, outCanvas.height - 120);
      ctx.stroke();
      
      // Draw flyers and boundaries
      ctx.setLineDash([]);
      ctx.strokeStyle = '#1e5128'; // brand-green border
      ctx.lineWidth = 6;
      
      for (let row = 0; row < 2; row++) {
        for (let col = 0; col < 2; col++) {
          const x = margin + col * (singleWidth + margin);
          const y = margin + row * (singleHeight + margin);
          
          ctx.drawImage(canvas, x, y, singleWidth, singleHeight);
          ctx.strokeRect(x, y, singleWidth, singleHeight);
        }
      }
      
      ctx.fillStyle = '#666666';
      ctx.font = '36px Inter, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText("Cut along the dotted lines and borders to separate flyers. Hand out to neighbors to support Digital Hand Up.", midX, outCanvas.height - 50);
      
      const imgData = outCanvas.toDataURL('image/jpeg', 0.9);
      const link = document.createElement('a');
      link.download = filename;
      link.href = imgData;
      link.click();
    } catch (err) {
      console.error("Error generating Image:", err);
      alert("There was an issue generating the image. Please try again.");
    } finally {
      // Restore styles
      element.style.transform = originalTransform;
      element.style.boxShadow = originalBoxShadow;
      window.getComputedStyle = originalGetComputedStyle;
    }
  };

  const renderPhotoGallery = (isOwner: boolean) => {
    return (
      <div className="bg-white border-t-8 border-brand-green p-8 rounded-[2.5rem] shadow-sm space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <ImageIcon className="w-8 h-8 text-brand-green" />
            <h4 className="font-black text-brand-green italic uppercase text-lg tracking-tighter">Photo Gallery</h4>
          </div>
          {isOwner && (
            <button 
              onClick={() => setIsAddingPhoto(true)}
              className="bg-brand-green text-brand-yellow px-4 py-2 rounded-full font-black text-xs uppercase hover:bg-green-900 transition-colors shadow-sm"
            >
              Add Photo
            </button>
          )}
        {lightboxIndex !== null && userPhotos[lightboxIndex] && (
          <div className="fixed inset-0 z-[100] bg-black/95 flex flex-col items-center justify-center p-4" onClick={() => setLightboxIndex(null)}>
            <button onClick={() => setLightboxIndex(null)} className="absolute top-4 right-4 text-white/70 hover:text-white p-2 z-[110]">
              <X className="w-8 h-8" />
            </button>
            <div className="relative w-full h-full flex items-center justify-center max-w-6xl mx-auto" onClick={(e) => e.stopPropagation()}>
              {lightboxIndex > 0 && (
                <button onClick={(e) => { e.stopPropagation(); setLightboxIndex(lightboxIndex - 1); }} className="absolute left-2 md:left-4 text-white/50 hover:text-white p-2 z-[110] bg-black/20 hover:bg-black/50 rounded-full transition-all">
                  <ChevronLeft className="w-8 h-8 md:w-12 md:h-12" />
                </button>
              )}
              <div className="flex flex-col items-center w-full px-12 md:px-20 max-h-full justify-center">
                <img 
                  src={userPhotos[lightboxIndex].imageUrl} 
                  alt={userPhotos[lightboxIndex].note || "Gallery image"}
                  className="max-h-[75vh] max-w-full object-contain rounded-lg shadow-2xl"
                />
                {userPhotos[lightboxIndex].note && (
                  <p className="text-white/90 mt-6 text-center text-sm md:text-lg max-w-2xl px-4">
                    {userPhotos[lightboxIndex].note}
                  </p>
                )}
              </div>
              {lightboxIndex < userPhotos.length - 1 && (
                <button onClick={(e) => { e.stopPropagation(); setLightboxIndex(lightboxIndex + 1); }} className="absolute right-2 md:right-4 text-white/50 hover:text-white p-2 z-[110] bg-black/20 hover:bg-black/50 rounded-full transition-all">
                  <ChevronRight className="w-8 h-8 md:w-12 md:h-12" />
                </button>
              )}
            </div>
          </div>
        )}
        </div>

        {isOwner && isAddingPhoto && (
          <div className="bg-neutral-50 p-4 rounded-2xl border border-neutral-200 mb-4 space-y-4">
            <input 
              type="file" 
              accept="image/*" 
              multiple
              ref={photoGalleryFileInputRef}
              onChange={(e) => setPhotoFiles(Array.from(e.target.files || []))}
              className="block w-full text-sm text-neutral-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-bold file:bg-brand-green/10 file:text-brand-green hover:file:bg-brand-green/20"
            />
            <div className="space-y-1.5">
              <label className="text-[10px] font-black text-neutral-400 uppercase tracking-wider ml-1">Photo Previews (Click X to delete)</label>
              <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 mb-2">
                {previewUrls.map((url, i) => (
                  <div key={i} className="relative aspect-square rounded-lg overflow-hidden border border-neutral-200">
                    <img src={url} alt="Preview" className="w-full h-full object-cover" />
                    <button onClick={() => setPhotoFiles(prev => prev.filter((_, idx) => idx !== i))} className="absolute top-1 right-1 bg-black/50 text-white rounded-full p-1 hover:bg-black/70" title="Delete Photo">
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="space-y-1.5">
              <label className="text-[10px] font-black text-neutral-400 uppercase tracking-wider ml-1">Note Option</label>
              <textarea
                placeholder="Add a note about this photo..."
                value={photoNote}
                onChange={(e) => setPhotoNote(e.target.value)}
                className="w-full bg-white border border-neutral-200 rounded-xl p-3 text-sm focus:ring-2 focus:ring-brand-green/20 outline-none resize-none"
                rows={2}
              ></textarea>
            </div>
            
            {uploadError && (
              <div className="text-red-500 text-sm bg-red-50 p-3 rounded-xl border border-red-100">
                {uploadError}
              </div>
            )}
        
            <div className="flex justify-end gap-2 pt-2">
              <button 
                onClick={() => { setIsAddingPhoto(false); setPhotoFiles([]); setPhotoNote(''); setUploadError(null); }}
                className="px-4 py-2 text-xs font-bold text-neutral-500 hover:text-neutral-900 bg-neutral-100 rounded-full"
                disabled={isUploadingPhoto}
              >
                Skip / Cancel
              </button>
              <button 
                onClick={handleAddPhoto}
                disabled={photoFiles.length === 0 || isUploadingPhoto}
                className="bg-brand-green text-white px-4 py-2 rounded-full font-bold text-xs disabled:opacity-50 flex items-center gap-2"
              >
                {isUploadingPhoto ? 'Uploading...' : (photoFiles.length > 1 ? `Save ${photoFiles.length} Photos` : 'Save Photo')}
              </button>
            </div>
          </div>
        )}
        

        {isPhotosLoading ? (
          <div className="py-8 flex justify-center">
            <div className="w-8 h-8 rounded-full border-4 border-brand-green/20 border-t-brand-green animate-spin"></div>
          </div>
        ) : userPhotos.length > 0 ? (
          <PhotoRolodex 
            photos={userPhotos} 
            isOwner={isOwner} 
            onDelete={handleDeletePhoto} 
            currentUser={user} 
          />
        ) : (
          <p className="text-neutral-400 text-sm italic text-center py-4">No photos added yet.</p>
        )}
        
      </div>
    );
  };

  if (showPrivacyPolicy) {
    return (
      <PrivacyPolicy 
        onBack={() => {
          setShowPrivacyPolicy(false);
          window.history.pushState({}, '', '/');
        }} 
      />
    );
  }

  if (sandboxPayment) {
    return (
      <SandboxCheckout 
        amount={sandboxPayment.amount}
        userId={sandboxPayment.userId}
        platformSupport={sandboxPayment.platformSupport}
        onSuccess={() => {
          setSandboxPayment(null);
          const params = new URLSearchParams();
          params.set('payment', 'success');
          if (sandboxPayment.userId && sandboxPayment.userId !== 'anonymous') {
            params.set('u', sandboxPayment.userId);
          }
          window.location.href = `${window.location.origin}${window.location.pathname}?${params.toString()}`;
        }}
        onCancel={() => {
          setSandboxPayment(null);
          const params = new URLSearchParams();
          params.set('payment', 'cancelled');
          if (sandboxPayment.userId && sandboxPayment.userId !== 'anonymous') {
            params.set('u', sandboxPayment.userId);
          }
          window.location.href = `${window.location.origin}${window.location.pathname}?${params.toString()}`;
        }}
      />
    );
  }

  if (publicUserId) {
    return (
      <div className="min-h-screen bg-neutral-50 font-sans text-neutral-900 pb-32">
         {/* Public Profile View */}
          <header className="sticky top-0 z-40 bg-white/80 backdrop-blur-md border-b border-neutral-200 px-4 py-3 flex items-center justify-between">
            <button 
              onClick={() => {
                window.history.pushState({}, '', window.location.pathname);
                setPublicUserId(null);
              }}
              className="flex items-center gap-2 text-brand-green font-bold text-sm"
            >
              <ChevronLeft className="w-5 h-5" /> Back to Home
            </button>
            <div className="flex items-center gap-2">
              <button 
                onClick={() => handleCopyLink(publicUserId!)}
                className="flex items-center gap-1.5 bg-neutral-100 text-neutral-600 px-3 py-1.5 rounded-full font-bold text-xs hover:bg-neutral-200 transition-all border border-neutral-200 active:scale-95"
              >
                <Share2 className={cn("w-3.5 h-3.5", copied && "text-brand-green")} />
                {copied ? <span className="text-brand-green">COPIED!</span> : 'SHARE'}
              </button>
              {!user ? (
                <button 
                  onClick={handleSignIn}
                  className="bg-brand-green text-brand-yellow px-4 py-1.5 rounded-full font-black text-xs shadow-sm"
                >
                  SIGN UP / LOG IN
                </button>
              ) : (
                <div className="w-8 h-8 rounded-full bg-brand-green/10 flex items-center justify-center border border-brand-green/20 overflow-hidden">
                   {user.photoURL && <img src={user.photoURL} alt="" className="w-full h-full object-cover" />}
                </div>
              )}
        
            </div>
         </header>

         {/* Status Banners */}
         <AnimatePresence>
            {updateError && (
              <motion.div 
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className={cn(
                  "bg-brand-green text-brand-yellow text-[10px] font-black py-3 px-4 text-center border-b border-white/10 uppercase tracking-widest",
                  updateError.includes("THANK YOU") ? "bg-brand-green" : "bg-red-600 text-white"
                )}
        
              >
                {updateError}
                <button onClick={() => setUpdateError(null)} className="ml-2 underline opacity-50 hover:opacity-100 uppercase">Dismiss</button>
              </motion.div>
            )}
        
         </AnimatePresence>

         <main className="max-w-md mx-auto p-4 md:max-w-2xl space-y-6 pt-4">
            {publicProfileLoading ? (
               <div className="flex flex-col items-center justify-center py-20 space-y-4">
                  <div className="w-12 h-12 border-4 border-brand-green border-t-transparent rounded-full animate-spin"></div>
                  <p className="text-sm font-bold text-neutral-500 uppercase tracking-widest">Bridging the community...</p>
               </div>
            ) : publicProfile ? (
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-6"
              >
                {/* Profile Banner */}
                <div className="bg-white rounded-[2.5rem] p-8 shadow-2xl shadow-brand-green/10 border border-neutral-100 flex flex-col items-center text-center relative overflow-hidden">
                   <div className="absolute top-0 left-0 w-full h-32 bg-brand-green/5"></div>
                   <div className="relative z-10">
                      <div className="w-32 h-32 rounded-full border-4 border-white shadow-xl overflow-hidden mb-4 bg-brand-green/10">
                        {publicProfile.photoURL ? (
                          <img src={publicProfile.photoURL} alt={publicProfile.displayName} className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-brand-green bg-brand-yellow/5 text-4xl font-black">
                            {publicProfile.displayName ? publicProfile.displayName[0].toUpperCase() : "?"}
                          </div>
                        )}
        
                      </div>
                      <h2 className="text-3xl font-black text-brand-green tracking-tighter leading-tight italic">
                        {publicProfile.displayName.toUpperCase()}
                      </h2>
                      <div className="flex items-center justify-center gap-2 text-neutral-500 font-bold text-sm mb-4">
                        <MapPin className="w-4 h-4" />
                        <span>{publicProfile.state || 'Oklahoma City'}</span>
                        {publicProfile.hasPet && (
                          <>
                            <span className="text-neutral-300">•</span>
                            <div className="flex items-center gap-1 bg-brand-yellow/30 text-brand-green px-2 py-0.5 rounded-full text-[10px] items-center">
                              <PawPrint className="w-3 h-3" />
                              <span>Pet Owner</span>
                            </div>
                          </>
                        )}
        
                      </div>
                      <p className="text-neutral-600 leading-relaxed max-w-sm mx-auto mb-8">
                        {publicProfile.bio || "I'm a community member looking to connect and support neighbors. Digital Hand Up helps us bridge the gap together."}
                      </p>
                   </div>
                </div>

                {/* Goals & Needs */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                   <div className="bg-brand-green text-white p-6 rounded-[2rem] shadow-xl">
                      <div className="flex items-center gap-3 mb-3">
                         <Target className="w-6 h-6 text-brand-yellow" />
                         <h3 className="font-black text-lg italic uppercase tracking-tighter">My Goals</h3>
                      </div>
                      <div className="space-y-4">
                        <div>
                          <p className="text-[10px] font-bold text-brand-yellow uppercase tracking-widest mb-1">Short Term</p>
                          <p className="text-sm font-medium opacity-90">{publicProfile.shortTermGoals || 'Establishing stability in the neighborhood.'}</p>
                        </div>
                        <div>
                          <p className="text-[10px] font-bold text-brand-yellow uppercase tracking-widest mb-1">Long Term</p>
                          <p className="text-sm font-medium opacity-90">{publicProfile.longTermGoals || 'To have a place of my own and give back to OKC.'}</p>
                        </div>
                      </div>
                   </div>
                   <div className="bg-emerald-50 border border-emerald-100 p-6 rounded-[2rem] shadow-sm flex flex-col justify-between">
                      <div>
                        <div className="flex items-center gap-3 mb-3">
                           <Package className="w-6 h-6 text-brand-green" />
                           <h3 className="font-black text-lg text-brand-green italic uppercase tracking-tighter">Items Needed</h3>
                        </div>
                        <p className="text-sm text-neutral-600 mb-4">
                          Direct goods support through my registry.
                        </p>
                      </div>
                      {publicProfile.allRegistryUrl ? (
                        <a 
                          href={publicProfile.allRegistryUrl.startsWith('http') ? publicProfile.allRegistryUrl : `https://${publicProfile.allRegistryUrl}`}
                          target="_blank"
                          rel="noreferrer"
                          className="w-full bg-white border-2 border-brand-green text-brand-green font-black py-3 rounded-2xl flex items-center justify-center gap-2 hover:bg-brand-green hover:text-white transition-all shadow-sm"
                        >
                          ALLREGISTRY.COM <ExternalLink className="w-4 h-4" />
                        </a>
                      ) : (
                        <div className="p-4 border-2 border-dashed border-emerald-200 rounded-2xl text-center">
                          <p className="text-xs font-bold text-emerald-800">No registry list shared yet.</p>
                        </div>
                      )}
        
                   </div>
                </div>

                {/* Donation Quick Actions */}
                <div className="bg-brand-yellow shadow-2xl shadow-brand-yellow/20 rounded-[2.5rem] p-8 space-y-6">
                   <div className="text-center space-y-1">
                      <h3 className="text-2xl font-black text-brand-green italic tracking-tighter uppercase underline decoration-4 decoration-brand-green/20 underline-offset-4">
                        Direct Hand Up
                      </h3>
                      <p className="text-brand-green/75 text-[10px] font-black uppercase tracking-wider">PRE-FILL AMOUNT &amp; SEND DIRECTLY</p>
                   </div>

                   <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
                      {['5', '10', '20', 'Other'].map((amount) => (
                        <button 
                          key={amount} onClick={() => setSelectedAmount(amount)}
                          className={`py-6 rounded-3xl shadow-sm hover:scale-[1.05] active:scale-[0.95] transition-all flex flex-col items-center justify-center gap-1 border-b-4 ${selectedAmount === amount ? 'bg-brand-green text-white border-brand-yellow/50' : 'bg-white text-brand-green border-brand-green/10'}`}
                        >
                          <span className="text-2xl font-black">{amount === 'Other' ? '?' : `$${amount}`}</span>
                          <span className="text-[10px] opacity-40 uppercase font-black">USD</span>
                        </button>
                      ))}
                   </div>

                   <div className="pt-4 space-y-4 scroll-mt-20">
                    <div className="bg-white/65 backdrop-blur-md rounded-2.5xl border border-brand-green/10 p-5 space-y-3 shadow-inner">
                      <div className="flex items-center gap-2 text-brand-green font-black text-xs uppercase tracking-wider">
                        <HelpCircle className="w-4.5 h-4.5 text-brand-green animate-pulse" />
                        <span>Universal P2P Payout Methods</span>
                      </div>
                      <p className="text-neutral-700 font-semibold text-xs leading-normal normal-case tracking-normal">
                        Click any option below to support them. <strong>100% of your contribution lands instantly in their secure personal wallet</strong> with zero coordinator cuts or platform fees.
                      </p>
                    </div>

                       {/* P2P Selection */}
                       <div className="space-y-3">
                         {publicProfile.cashAppId && (
                           <a 
                             href={`https://cash.app/$${publicProfile.cashAppId.replace(/^[$@]/, '')}${selectedAmount && selectedAmount !== 'Other' ? '/' + selectedAmount : ''}?note=${encodeURIComponent('Hand Up support via digitalhandup.org')}`}
                             target="_blank"
                             rel="noopener noreferrer"
                             className="flex items-center justify-between p-4 bg-white hover:bg-emerald-50 rounded-2.5xl border border-brand-green/10 transition-all shadow-sm group hover:scale-[1.02] active:scale-[0.98]"
                           >
                             <div className="flex items-center gap-3">
                               <div className="w-11 h-11 bg-[#00D632] text-white rounded-xl flex items-center justify-center font-black text-2xl shadow-sm">$</div>
                               <div className="text-left">
                                 <p className="font-black text-brand-green uppercase text-[11px] tracking-wide">Cash App</p>
                                 <p className="text-neutral-500 font-bold text-xs">${publicProfile.cashAppId}</p>
                               </div>
                             </div>
                             <ChevronLeft className="w-5 h-5 text-[#00D632] rotate-180 group-hover:translate-x-1 transition-transform" />
                           </a>
                         )}
        

                         {publicProfile.venmoId && (
                           <a 
                             href={`https://venmo.com/${publicProfile.venmoId.replace(/^[@$]/, '')}?selection=pay&note=${encodeURIComponent('Hand Up support via digitalhandup.org')}${selectedAmount && selectedAmount !== 'Other' ? '&amount=' + selectedAmount : ''}`}
                             target="_blank"
                             rel="noopener noreferrer"
                             className="flex items-center justify-between p-4 bg-white hover:bg-blue-50 rounded-2.5xl border border-brand-green/10 transition-all shadow-sm group hover:scale-[1.02] active:scale-[0.98]"
                           >
                             <div className="flex items-center gap-3">
                               <div className="w-11 h-11 bg-[#008CFF] text-white rounded-xl flex items-center justify-center font-black text-xs uppercase italic shadow-sm">Venmo</div>
                               <div className="text-left">
                                 <p className="font-black text-brand-green uppercase text-[11px] tracking-wide">Venmo</p>
                                 <p className="text-neutral-500 font-bold text-xs">@{publicProfile.venmoId}</p>
                               </div>
                             </div>
                             <ChevronLeft className="w-5 h-5 text-[#008CFF] rotate-180 group-hover:translate-x-1 transition-transform" />
                           </a>
                         )}
        

                         {publicProfile.payPalId && (
                           <a 
                             href={`https://www.paypal.com/paypalme/${publicProfile.payPalId.replace(/^[@$]/, '')}/${selectedAmount && selectedAmount !== 'Other' ? selectedAmount : ''}?note=${encodeURIComponent('Hand Up support via digitalhandup.org')}`}
                             target="_blank"
                             rel="noopener noreferrer"
                             className="flex items-center justify-between p-4 bg-white hover:bg-indigo-50 rounded-2.5xl border border-brand-green/10 transition-all shadow-sm group hover:scale-[1.02] active:scale-[0.98]"
                           >
                             <div className="flex items-center gap-3">
                               <div className="w-11 h-11 bg-[#003087] text-white rounded-xl flex items-center justify-center font-black text-sm shadow-sm">PayPal</div>
                               <div className="text-left">
                                 <p className="font-black text-brand-green uppercase text-[11px] tracking-wide">PayPal Me</p>
                                 <p className="text-neutral-500 font-bold text-xs font-mono">paypal.me/{publicProfile.payPalId}</p>
                               </div>
                             </div>
                             <ChevronLeft className="w-5 h-5 text-[#003087] rotate-180 group-hover:translate-x-1 transition-transform" />
                           </a>
                         )}
        

                         {publicProfile.zelleId && (
                           <div className="flex items-center justify-between p-4 bg-white hover:bg-purple-50 rounded-2.5xl border border-brand-green/10 transition-all shadow-sm select-auto">
                             <div className="flex items-center gap-3">
                               <div className="w-11 h-11 bg-[#671cc8] text-white rounded-xl flex items-center justify-center font-black text-sm uppercase italic shadow-sm">Zelle</div>
                               <div className="text-left">
                                 <p className="font-black text-brand-green uppercase text-[11px] tracking-wide">Zelle Account</p>
                                 <p className="text-neutral-600 font-extrabold text-xs select-all bg-neutral-50 px-2 py-0.5 rounded border border-neutral-200/60 mt-0.5">{publicProfile.zelleId}</p>
                                 <p className="text-[9px] text-neutral-400 font-bold uppercase mt-1">Copy and send via your banking app</p>
                               </div>
                             </div>
                           </div>
                         )}
        

                         {publicProfile.chimeId && (
                           <div className="flex items-center justify-between p-4 bg-white hover:bg-green-50 rounded-2.5xl border border-brand-green/10 transition-all shadow-sm select-auto">
                             <div className="flex items-center gap-3">
                               <div className="w-11 h-11 bg-[#25C85B] text-white rounded-xl flex items-center justify-center font-black text-sm uppercase shadow-sm">Chime</div>
                               <div className="text-left">
                                 <p className="font-black text-brand-green uppercase text-[11px] tracking-wide">Chime</p>
                                 <p className="text-neutral-600 font-extrabold text-xs select-all bg-neutral-50 px-2 py-0.5 rounded border border-neutral-200/60 mt-0.5">{publicProfile.chimeId}</p>
                               </div>
                             </div>
                           </div>
                         )}
        

                         {(!publicProfile.cashAppId && !publicProfile.venmoId && !publicProfile.payPalId && !publicProfile.zelleId && !publicProfile.chimeId) && (
                           <div className="bg-white/40 border border-brand-green/10 p-6 rounded-2.5xl text-center space-y-2">
                             <p className="text-lg font-black text-brand-green/50 uppercase tracking-tighter">No Linked Accounts</p>
                             <p className="text-xs text-neutral-500 font-semibold max-w-xs mx-auto leading-normal">This community member hasn't configured any payment methods yet. Share their profile link with friends or coordinators to help spread the word!</p>
                           </div>
                         )}
        
                       </div>
                    </div>
                 </div>

                 {/* Photo Gallery */}
                 {renderPhotoGallery(false)}

                <div className="bg-white border-t-8 border-brand-green p-8 rounded-[2.5rem] shadow-sm space-y-6">
                  <div className="flex items-center gap-3">
                    <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center border-2 border-brand-green p-1 overflow-hidden shadow-sm">
                      <AppLogo className="w-full h-full" />
                    </div>
                    <div>
                      <h4 className="font-black text-brand-green italic uppercase text-lg tracking-tighter">About Digital Hand Up</h4>
                      <p className="text-xs text-neutral-500 font-medium">Bridging the gap in Oklahoma City since 2024.</p>
                    </div>
                  </div>
                  <p className="text-sm text-neutral-600 leading-relaxed">
                    Digital Hand Up is a community-driven logistics platform. We enable direct support between neighbors, ensuring resources reach those who need them most without the friction of traditional systems.
                  </p>
                  <button 
                    onClick={() => {
                        window.history.pushState({}, '', window.location.pathname);
                        setPublicUserId(null);
                    }}
                    className="w-full bg-neutral-900 text-brand-yellow font-black py-4 rounded-3xl hover:bg-black transition-all flex items-center justify-center gap-2 group"
                  >
                    EXPLORE COMMUNITY <ChevronLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
                  </button>
                </div>
              </motion.div>
            ) : (
              <div className="text-center py-20 space-y-4">
                  <div className="w-20 h-20 bg-neutral-100 rounded-3xl flex items-center justify-center border border-neutral-200 p-2 overflow-hidden shadow-inner mx-auto">
                    <AppLogo className="w-full h-full grayscale opacity-20" />
                  </div>
                  <h3 className="text-xl font-bold">Profile not found</h3>
                  <button 
                    onClick={() => setPublicUserId(null)}
                    className="bg-brand-green text-brand-yellow px-6 py-2 rounded-full font-black text-sm"
                  >
                    GO TO FEED
                  </button>
              </div>
            )}
        
         </main>
      </div>
    );
  }

  return (
    <APIProvider apiKey={GOOGLE_MAPS_API_KEY}>
      <div className="min-h-screen bg-neutral-50 font-sans text-neutral-900 pb-32">
        {/* Header */}
      <header className="sticky top-0 z-40 bg-white/80 backdrop-blur-md border-b border-neutral-200 px-3 md:px-6 py-2.5 flex items-center justify-between gap-2 font-sans md:gap-4">
        {/* Auth Error Notification */}
        <AnimatePresence>
          {authError && (
            <motion.div 
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="absolute top-full left-0 right-0 bg-red-600 text-white text-[10px] font-black py-2 px-4 text-center z-50 flex items-center justify-center gap-2"
            >
              <AlertCircle className="w-3 h-3" />
              {authError}
              <button onClick={() => setAuthError(null)} className="ml-2 underline">CLOSE</button>
            </motion.div>
          )}
        
        </AnimatePresence>

        {/* Left: Brand logo & name */}
        <div className="flex items-center gap-2 md:gap-4 shrink-0">
          <div className="relative w-16 h-16 md:w-24 md:h-24 shrink-0 bg-white rounded-full flex items-center justify-center border-2 border-brand-green shadow-md p-0 overflow-hidden">
             <AppLogo className="w-full h-full" imgClassName="scale-[1.38]" />
          </div>
          <div className="flex flex-col items-start leading-tight">
            <h1 className="text-base md:text-2xl font-black tracking-tighter text-brand-green leading-[0.85]">HAND UP</h1>
            <span className="text-[8px] md:text-[10px] font-black tracking-[0.22em] text-brand-green/85 uppercase">Oklahoma City</span>
          </div>
        </div>

        {/* Center: Crisis & Well-being quick action portal shortcut */}
        <div className="flex-1 flex justify-center max-w-sm md:max-w-md mx-auto px-1">
          <button 
            onClick={() => setActiveTab('support')}
            className={cn(
              "px-3 md:px-5 py-1.5 rounded-full hover:bg-neutral-800 hover:text-brand-yellow font-sans flex items-center justify-center hover:scale-103 active:scale-97 transition-all border gap-1.5 md:gap-2 shadow-xs w-full",
              activeTab === 'support'
                ? "bg-brand-green text-brand-yellow border-brand-green shadow-xs font-black"
                : "text-red-700 bg-red-50/90 border-red-200 hover:bg-red-100"
            )}
        
            title="Crisis, Mental Health & Personal Well-Being Support"
          >
            <ShieldAlert className="w-3.5 h-3.5 md:w-4 md:h-4 shrink-0 text-red-600" />
            <span className="text-[8px] md:text-[10px] font-black uppercase tracking-[0.05em] md:tracking-[0.1em] whitespace-nowrap">
              <span className="hidden sm:inline">Mental Health & Personal Well-Being</span>
              <span className="sm:hidden">Mental Health & Well-Being</span>
            </span>
          </button>
        </div>

        {/* Right: User menu & companion actions */}
        <div className="flex items-center gap-2 shrink-0">
          {!user ? (
            <button 
              id="header-login-btn"
              onClick={handleSignIn}
              className="bg-brand-yellow text-brand-green px-4 py-2 rounded-full font-black text-[10px] uppercase tracking-widest shadow-lg shadow-brand-yellow/20 active:scale-95 transition-all flex items-center gap-2 border border-brand-green/10"
            >
              <LogIn className="w-3 h-3" /> Log In
            </button>
          ) : (
             <button 
               onClick={() => setActiveTab('profile')}
               className="w-10 h-10 rounded-full border-2 border-brand-yellow overflow-hidden shadow-sm"
             >
                {user.photoURL ? (
                  <img src={user.photoURL} alt="Profile" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                ) : (
                  <div className="w-full h-full bg-brand-green flex items-center justify-center text-brand-yellow font-bold">
                    {user.email?.[0].toUpperCase() || 'U'}
                  </div>
                )}
        
             </button>
          )}
        
          <button 
            onClick={() => setCompanionChatOpen(true)}
            className="p-2 rounded-full hover:bg-green-100/55 text-brand-green bg-green-50 flex items-center justify-center animate-bounce hover:scale-110 active:scale-95 transition-all"
            title="Talk to Hand Up AI Companion"
          >
            <Sparkles className="w-5 h-5 text-brand-yellow fill-brand-yellow bg-brand-green p-1.5 w-7.5 h-7.5 rounded-full shadow-md" />
          </button>
          <button className={cn("p-2 rounded-full hover:bg-neutral-100 transition-colors")}>
            <Search className="w-5 h-5 text-neutral-600" />
          </button>
          <button className="relative p-2 rounded-full hover:bg-neutral-100 transition-colors">
            <Bell className="w-5 h-5 text-neutral-600" />
            <span className="absolute top-2 right-2 w-2 h-2 bg-brand-yellow rounded-full border-2 border-white"></span>
          </button>
        </div>
      </header>

      {/* Detail Modal */}
      <AnimatePresence>
        {selectedRequest && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[70] flex items-end justify-center bg-black/60 p-0 sm:p-4 md:items-center"
            onClick={() => setSelectedRequest(null)}
          >
            <motion.div 
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              className="w-full max-w-lg bg-white rounded-t-[2.5rem] md:rounded-[2.5rem] p-8 pt-6 pb-[calc(1rem+env(safe-area-inset-bottom))] sm:pb-8 overflow-hidden relative shadow-2xl"
              onClick={e => e.stopPropagation()}
            >
              <div className="w-12 h-1.5 bg-neutral-200 rounded-full mx-auto mb-6 md:hidden"></div>
              
              <div className="flex items-center justify-between mb-4">
                <span className={cn(
                  "px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider",
                  selectedRequest.type === 'Supplies' ? "bg-blue-100 text-blue-700" :
                  selectedRequest.type === 'Transport' ? "bg-purple-100 text-purple-700" :
                  "bg-green-100 text-green-700"
                )}
        >
                  {selectedRequest.type}
                </span>
                {selectedRequest.urgent && (
                  <span className="bg-red-100 text-red-700 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider">
                    Urgent
                  </span>
                )}
        
              </div>

              <h2 className="text-2xl font-black text-brand-green mb-2">{selectedRequest.title}</h2>
              <div className="flex items-center gap-2 text-neutral-500 mb-6">
                <MapPin className="w-4 h-4" />
                <span className="text-sm font-medium">{selectedRequest.location}</span>
                <span className="text-neutral-300">•</span>
                <span className="text-sm">{selectedRequest.timestamp?.toDate().toLocaleDateString()}</span>
              </div>

              <div className="bg-neutral-50 p-4 rounded-2xl mb-8 border border-neutral-100 relative group/speak">
                <p className="text-neutral-700 leading-relaxed pr-8">
                  {selectedRequest.description}
                </p>
                <button
                  onClick={() => speakText(`req-${selectedRequest.id}`, selectedRequest.title + ". " + selectedRequest.description)}
                  className="absolute bottom-3 right-3 p-2 bg-brand-yellow text-brand-green rounded-full shadow-md hover:scale-105 active:scale-95 transition-transform flex items-center justify-center text-xs"
                  title="Listen with Gemini Voice"
                >
                  {speakingTextId === `req-${selectedRequest.id}` ? (
                    <VolumeX className="w-4 h-4 animate-pulse text-red-600" />
                  ) : (
                    <Volume2 className="w-4 h-4" />
                  )}
        
                </button>
              </div>

              <div className="flex gap-3">
                <button 
                  onClick={() => {
                    const requesterId = selectedRequest.userId;
                    setSelectedRequest(null);
                    // Add a small delay to allow modal exit animation to feel natural
                    setTimeout(() => {
                      setPublicUserId(requesterId);
                    }, 300);
                  }}
                  className="flex-1 bg-brand-green text-brand-yellow font-black py-4 rounded-2xl shadow-xl shadow-brand-green/20 hover:scale-[1.02] active:scale-[0.98] transition-all"
                >
                  OFFER HELP
                </button>
                <button 
                  onClick={() => setSelectedRequest(null)}
                  className="px-6 bg-neutral-100 text-neutral-600 font-bold py-4 rounded-2xl hover:bg-neutral-200 transition-all"
                >
                  Close
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
        
      </AnimatePresence>

      {/* Main Content Area */}
      <main className="max-w-md mx-auto p-4 md:max-w-2xl">
        <AnimatePresence mode="wait">
          {activeTab === 'home' && (
            <motion.div
              key="home"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-6"
            >
              {/* Top Hero Guide Banner - "Learn before joining the movement" */}
              <motion.div
                initial={{ scale: 0.95, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ duration: 0.4, ease: "easeOut" }}
                onClick={() => setIsOnboardingOpen(true)}
                className="relative overflow-hidden rounded-[2rem] border-2 border-brand-yellow/30 bg-gradient-to-r from-amber-50 to-yellow-100 p-5 shadow-md hover:shadow-lg transition-all cursor-pointer flex flex-col sm:flex-row items-center gap-4 group hover:scale-[1.01] active:scale-[0.99]"
              >
                <div className="w-12 h-12 bg-brand-green text-brand-yellow rounded-2xl flex items-center justify-center shadow-lg group-hover:rotate-12 transition-transform shrink-0">
                  <Sparkles className="w-6 h-6 animate-pulse" />
                </div>
                <div className="flex-1 text-center sm:text-left space-y-1">
                  <div className="flex items-center justify-center sm:justify-start gap-1.5">
                    <span className="bg-brand-green/10 text-brand-green text-[9px] font-black uppercase tracking-wider px-2 py-0.5 rounded-md">
                      First Time?
                    </span>
                    <span className="text-[10px] font-black text-brand-green uppercase tracking-widest italic opacity-85">
                      Motto: Hand Up
                    </span>
                  </div>
                  <h3 className="text-sm font-black text-brand-green uppercase tracking-tight italic">
                    Read & Listen to the Hand Up OKC Guide
                  </h3>
                  <p className="text-[11px] text-neutral-600 font-bold leading-normal">
                    Learn how peer-to-peer flyer distribution, direct mobile wallets, and direct community support work in Oklahoma City.
                  </p>
                </div>
                <button
                  type="button"
                  className="px-4 py-2 bg-brand-green hover:bg-green-900 text-brand-yellow font-black text-[10px] uppercase tracking-wider rounded-xl shadow-md flex items-center gap-1.5 shrink-0 transition-transform group-hover:translate-x-0.5"
                >
                  <Play className="w-3 h-3 fill-brand-yellow" /> Open Guide
                </button>
              </motion.div>

              {/* Impact Banner */}
              <div className="relative overflow-hidden rounded-[2.5rem] bg-brand-green p-8 text-white shadow-2xl min-h-[320px] flex flex-col justify-end">
                {/* Background Art */}
                <div className="absolute inset-0 z-0">
                  <img 
                    src={charityBackground} 
                    alt="OKC Charity Background" 
                    className="w-full h-full object-cover opacity-30 mix-blend-overlay"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-brand-green via-brand-green/80 to-transparent"></div>
                </div>

                <div className="relative z-10 space-y-6">
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center shadow-lg border-2 border-brand-yellow/30 p-1 overflow-hidden">
                      <AppLogo className="w-full h-full" />
                    </div>
                    <div>
                      <h2 className="text-3xl font-black leading-none italic tracking-tighter uppercase">Digital <br /><span className="text-brand-yellow decoration-4 underline-offset-8">Hand Up</span></h2>
                      <p className="text-brand-yellow text-[10px] font-black tracking-[0.3em] uppercase mt-1 opacity-80">Hand Up • OKC</p>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <p className="text-neutral-200 text-sm font-medium leading-relaxed">
                      We are a unified community logistics platform dedicated to providing a <span className="text-white font-bold italic">"Hand Up"</span> to our neighbors in transition.
                    </p>
                    
                    <div className="flex flex-wrap gap-2">
                       <div className="flex items-center gap-1.5 bg-white/10 px-3 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-wider backdrop-blur-sm">
                         <Target className="w-3 h-3 text-brand-yellow" /> Direct Action
                       </div>
                       <div className="flex items-center gap-1.5 bg-white/10 px-3 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-wider backdrop-blur-sm">
                         <Handshake className="w-3 h-3 text-brand-yellow" /> Unity
                       </div>
                       <div className="flex items-center gap-1.5 bg-white/10 px-3 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-wider backdrop-blur-sm">
                         <Package className="w-3 h-3 text-brand-yellow" /> Logistics
                       </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 gap-3">
                    <button 
                      onClick={() => {
                        window.location.href = 'tel:211';
                      }}
                      className="w-full bg-red-600 hover:bg-red-700 text-white px-6 py-4 rounded-2xl font-black text-sm transition-all flex items-center justify-between shadow-xl group border-b-4 border-red-800"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-white/20 rounded-lg flex items-center justify-center">
                          <Phone className="w-4 h-4 text-white animate-pulse" />
                        </div>
                        <div className="text-left">
                          <span className="block text-[10px] opacity-70 uppercase tracking-widest font-black">Emergency Assistance</span>
                          <span className="block text-lg tracking-tighter">DIAL 2-1-1</span>
                        </div>
                      </div>
                      <ChevronLeft className="w-5 h-5 rotate-180 opacity-40 group-hover:translate-x-1 transition-transform" />
                    </button>

                    <button 
                      onClick={() => setActiveTab('soonercare')}
                      className="w-full bg-emerald-600 hover:bg-emerald-700 text-white px-6 py-4 rounded-2xl font-black text-sm transition-all flex items-center justify-between shadow-xl group border-b-4 border-emerald-800"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-white/20 rounded-lg flex items-center justify-center">
                          <Shield className="w-4 h-4 text-white" />
                        </div>
                        <div className="text-left">
                          <span className="block text-[10px] opacity-70 uppercase tracking-widest font-black">Medicaid Expansion</span>
                          <span className="block text-lg tracking-tighter uppercase mt-1 leading-none">Adults SoonerCare</span>
                        </div>
                      </div>
                      <ChevronLeft className="w-5 h-5 rotate-180 opacity-40 group-hover:translate-x-1 transition-transform" />
                    </button>

                    <button 
                      onClick={() => setActiveTab('methadone')}
                      className="w-full bg-orange-600 hover:bg-orange-700 text-white px-6 py-4 rounded-2xl font-black text-sm transition-all flex items-center justify-between shadow-xl group border-b-4 border-orange-800"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-white/20 rounded-lg flex items-center justify-center">
                          <Activity className="w-4 h-4 text-white" />
                        </div>
                        <div className="text-left">
                          <span className="block text-[10px] opacity-70 uppercase tracking-widest font-black">Substance Use Treatment</span>
                          <span className="block text-lg tracking-tighter uppercase mt-1 leading-none">Methadone & SoonerRide</span>
                        </div>
                      </div>
                      <ChevronLeft className="w-5 h-5 rotate-180 opacity-40 group-hover:translate-x-1 transition-transform" />
                    </button>

                    <button 
                      onClick={() => setActiveTab('support')}
                      className="w-full bg-brand-green hover:bg-green-900 text-white px-6 py-4 rounded-2xl font-black text-sm transition-all flex items-center justify-between shadow-xl group border-b-4 border-emerald-950"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-white/20 rounded-lg flex items-center justify-center">
                          <Heart className="w-4 h-4 text-white" />
                        </div>
                        <div className="text-left">
                          <span className="block text-[10px] opacity-70 uppercase tracking-widest font-black">Crisis & Well-being</span>
                          <span className="block text-lg tracking-tighter uppercase mt-1 leading-none">Mental Health Support</span>
                        </div>
                      </div>
                      <ChevronLeft className="w-5 h-5 rotate-180 opacity-40 group-hover:translate-x-1 transition-transform" />
                    </button>

                    <button 
                      onClick={() => window.open('https://cdn.airplanegobrr.xyz/pages/embarkTicket.html', '_blank')}
                      className="w-full bg-blue-600 hover:bg-blue-700 text-white px-6 py-4 rounded-2xl font-black text-sm transition-all flex items-center justify-between shadow-xl group border-b-4 border-blue-800"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-white/20 rounded-lg flex items-center justify-center">
                          <Bus className="w-4 h-4 text-white" />
                        </div>
                        <div className="text-left">
                          <span className="block text-[10px] opacity-70 uppercase tracking-widest font-black">Free Transportation</span>
                          <span className="block text-lg tracking-tighter uppercase mt-1 leading-none">EMBARK Bus Pass</span>
                        </div>
                      </div>
                      <ChevronLeft className="w-5 h-5 rotate-180 opacity-40 group-hover:translate-x-1 transition-transform" />
                    </button>

                    {!user ? (
                      <button 
                        onClick={handleSignIn}
                        className="w-full bg-brand-yellow hover:bg-yellow-400 text-brand-green px-6 py-4 rounded-2xl font-black text-sm transition-all flex items-center justify-center gap-3 shadow-xl border-b-4 border-brand-green/20"
                      >
                        <LogIn className="w-5 h-5" /> JOIN THE MOVEMENT
                      </button>
                    ) : (
                      <button 
                        onClick={() => setActiveTab('profile')}
                        className="w-full bg-brand-yellow hover:bg-yellow-400 text-brand-green px-6 py-4 rounded-2xl font-black text-sm transition-all flex items-center justify-center gap-3 shadow-xl border-b-4 border-brand-green/20"
                      >
                        <User className="w-5 h-5" /> VIEW YOUR IMPACT PROFILE
                      </button>
                    )}
                  </div>
                </div>
                {/* Decorative Elements */}
                <div className="absolute top-0 right-0 w-80 h-80 bg-brand-yellow/10 blur-3xl -mr-20 -mt-20 rounded-full animate-pulse"></div>
                <div className="absolute -bottom-20 -left-20 w-60 h-60 bg-white/5 blur-3xl rounded-full"></div>
              </div>

              {/* Workforce Pipelines CTA Banner */}
              <motion.div
                initial={{ scale: 0.95, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ duration: 0.4, delay: 0.1, ease: "easeOut" }}
                onClick={() => setActiveTab('workforce')}
                className="relative overflow-hidden rounded-[2rem] border-2 border-slate-700 bg-neutral-900 p-5 shadow-lg hover:shadow-xl transition-all cursor-pointer flex flex-col sm:flex-row items-center gap-4 group hover:scale-[1.01] active:scale-[0.99]"
              >
                <div className="w-12 h-12 bg-slate-800 text-white border border-slate-600 rounded-2xl flex items-center justify-center shadow-lg group-hover:-translate-y-1 transition-transform shrink-0">
                  <svg className="w-6 h-6 text-brand-yellow" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                  </svg>
                </div>
                <div className="flex-1 text-center sm:text-left space-y-1">
                  <div className="flex items-center justify-center sm:justify-start gap-1.5">
                    <span className="bg-brand-yellow/10 text-brand-yellow text-[9px] font-black uppercase tracking-wider px-2 py-0.5 rounded-md">
                      Trade Pipeline
                    </span>
                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest italic">
                      Job Matches
                    </span>
                  </div>
                  <h3 className="text-sm font-black text-white uppercase tracking-tight">
                    Explore Paid Skill Tracks & Apprenticeships
                  </h3>
                  <p className="text-[11px] text-slate-400 font-medium leading-normal">
                    Connecting to local trades (HVAC, Electrical, Construction). Low barrier to entry, tools & training provided.
                  </p>
                </div>
                <button
                  type="button"
                  className="px-4 py-2 bg-brand-yellow hover:bg-yellow-400 text-neutral-900 font-black text-[10px] uppercase tracking-wider rounded-xl shadow-md shrink-0 transition-transform group-hover:scale-105"
                >
                  Join Track
                </button>
              </motion.div>

              {/* Mission & Goals Section */}
              <div className="space-y-4">
                <div className="flex items-center justify-between px-2">
                   <h3 className="text-lg font-black text-brand-green italic uppercase tracking-tighter">Our Core Mission</h3>
                   <div className="h-px flex-1 bg-neutral-200 mx-4 opacity-50"></div>
                </div>

                <div className="px-6 py-8 bg-brand-green/5 rounded-[2rem] border-l-8 border-brand-yellow mx-2 shadow-sm">
                  <p className="text-3xl md:text-5xl font-bold font-mission text-brand-green leading-tight text-center">
                    "Whoever is kind to the poor lends to the Lord, and he will reward them for what they have done."
                  </p>
                  <p className="text-right mt-4 font-black text-brand-green/40 uppercase tracking-widest text-xs">
                    Proverbs 19:17
                  </p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                   <div className="bg-white p-6 rounded-[2rem] border border-neutral-100 shadow-sm space-y-3">
                      <div className="w-10 h-10 bg-brand-green/5 rounded-xl flex items-center justify-center text-brand-green">
                         <Star className="w-5 h-5" />
                      </div>
                      <h4 className="font-black text-sm uppercase tracking-tight">The "Hand Up" Philosophy</h4>
                      <p className="text-xs text-neutral-600 leading-relaxed font-medium">
                        We don't just provide handouts. We build infrastructure that allows neighbors to help neighbors regain their autonomy through direct logistics and support networks.
                      </p>
                   </div>
                   
                   <div className="bg-white p-6 rounded-[2rem] border border-neutral-100 shadow-sm space-y-3">
                      <div className="w-10 h-10 bg-brand-yellow/10 rounded-xl flex items-center justify-center text-brand-green">
                         <Target className="w-5 h-5" />
                      </div>
                      <h4 className="font-black text-sm uppercase tracking-tight">Community Logistics</h4>
                      <p className="text-xs text-neutral-600 leading-relaxed font-medium">
                        Our goal is to ensure that a pair of boots, a meal, or a ride reaches exactly who needs it, exactly when they need it, with zero friction and total transparency.
                      </p>
                   </div>
                </div>
              </div>

              {/* Recent News Section */}
              <div className="space-y-4">
                <div className="flex items-center justify-between px-2">
                   <h3 className="text-lg font-black text-brand-green italic uppercase tracking-tighter">Local News & Updates</h3>
                   <div className="flex items-center gap-2">
                     <span className={cn(
                       "text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-widest",
                       isLiveNews ? "bg-brand-yellow/30 text-brand-green" : "bg-neutral-100 text-neutral-400"
                     )}
        >
                       {isLiveNews ? "Live Updates" : "Curated Updates"}
                     </span>
                   </div>
                </div>
                
                {newsLoading ? (
                  <div className="flex flex-col items-center justify-center py-10 bg-white rounded-[2rem] border border-neutral-100 shadow-sm space-y-3">
                    <div className="w-8 h-8 border-4 border-brand-green border-t-transparent rounded-full animate-spin"></div>
                    <p className="text-[10px] font-black text-neutral-400 uppercase tracking-widest">Scanning local reports...</p>
                  </div>
                ) : newsError ? (
                  <div className="bg-red-50/70 border border-red-200 rounded-[2rem] p-6 text-center space-y-4 shadow-sm">
                    <div className="inline-flex items-center justify-center w-12 h-12 bg-red-100/60 rounded-full text-red-600 mb-1">
                      <AlertCircle className="w-6 h-6 animate-pulse" />
                    </div>
                    <div className="space-y-1">
                      <h4 className="font-extrabold text-sm text-red-900 uppercase tracking-tight">Temporary Connection Interruption</h4>
                      <p className="text-xs text-red-700/90 font-semibold leading-relaxed max-w-sm mx-auto">
                        We couldn't connect to Oklahoma City's curated news updates right now ({newsError}).
                      </p>
                    </div>
                    <div className="bg-white/80 rounded-2xl border border-red-100 p-3.5 text-left text-[11px] text-neutral-600 font-semibold space-y-1.5 max-w-sm mx-auto normal-case tracking-normal">
                      <p className="font-bold text-red-900 uppercase text-[10px] tracking-wide flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 bg-red-500 rounded-full"></span>
                        Troubleshooting Ideas:
                      </p>
                      <ul className="list-disc pl-4.5 space-y-0.5 text-[10px]">
                        <li>Verify that you have an active network connection.</li>
                        <li>This system scan draws live news via the Gemini API. Wait 30 seconds for quota cool-down if you updated frequently.</li>
                        <li>Ask the platform administrator to confirm the server keys are configured in Settings.</li>
                      </ul>
                    </div>
                    <button
                      onClick={fetchNews}
                      className="inline-flex items-center gap-1.5 px-5 py-2 bg-brand-green text-brand-yellow font-black text-[10px] uppercase tracking-wider rounded-2xl border-2 border-brand-green hover:scale-[1.02] active:scale-[0.98] transition-transform cursor-pointer shadow-md shadow-brand-green/10"
                    >
                      Retry Scanning Updates
                    </button>
                  </div>
                ) : news.length > 0 ? (
                  <div className="space-y-3">
                    {news.map((item, idx) => (
                      <div key={idx} className="bg-white p-5 rounded-[2rem] border border-neutral-100 shadow-sm hover:shadow-md transition-shadow group">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-[10px] font-black text-brand-green uppercase tracking-widest opacity-60">{item.source}</span>
                          {item.date && <span className="text-[10px] font-bold text-neutral-400">{item.date}</span>}
                        </div>
                        <h4 className="font-black text-sm text-neutral-900 group-hover:text-brand-green transition-colors leading-tight mb-2 uppercase tracking-tight italic">
                          {item.title}
                        </h4>
                        <div className="relative mb-3 group/news-speak">
                          <p className="text-xs text-neutral-600 font-medium leading-relaxed pr-8">
                            {item.summary}
                          </p>
                          <button
                            onClick={() => speakText(`news-${idx}`, item.title + ". " + item.summary)}
                            className="absolute right-0 top-0 p-1.5 bg-neutral-100 text-brand-green rounded-full hover:bg-brand-yellow hover:text-brand-green transition-colors flex items-center justify-center"
                            title="Listen to summary"
                          >
                            {speakingTextId === `news-${idx}` ? (
                              <VolumeX className="w-3.5 h-3.5 animate-pulse text-red-600" />
                            ) : (
                              <Volume2 className="w-3.5 h-3.5" />
                            )}
        
                          </button>
                        </div>
                        {item.url && (
                          <a 
                            href={item.url} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1.5 text-brand-green font-black text-[10px] uppercase tracking-wider hover:underline"
                          >
                            READ FULL STORY <ExternalLink className="w-3 h-3" />
                          </a>
                        )}
        
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-10 bg-neutral-50 rounded-[2rem] border border-dashed border-neutral-200">
                    <Globe className="w-8 h-8 text-neutral-300 mx-auto mb-2" />
                    <p className="text-xs font-bold text-neutral-400 uppercase tracking-widest">No recent news found at the moment.</p>
                  </div>
                )}
        
              </div>

              {/* OKC Resource Directory */}
              <div className="space-y-4">
                <div className="flex items-center justify-between px-2">
                   <h3 className="text-lg font-black text-brand-green italic uppercase tracking-tighter underline decoration-brand-yellow decoration-4 underline-offset-4">OKC Program Directory</h3>
                   <span className="text-[10px] font-black text-neutral-400 uppercase tracking-widest">Verified Resources</span>
                </div>
                
                <div className="grid grid-cols-1 gap-3">
                   {[
                     { 
                       name: "Homeless Alliance", 
                       program: "Westtown Day Center", 
                       desc: "Resources including showers, mail, phone access, and housing services.",
                       link: "https://homelessalliance.org/",
                       icon: Home
                     },
                     { 
                       name: "City Rescue Mission", 
                       program: "Emergency Shelter", 
                       desc: "Food, shelter, and long-term recovery programs for the OKC community.",
                       link: "https://cityrescue.org/",
                       icon: Shield
                     },
                     { 
                       name: "City Care", 
                       program: "Night Shelter", 
                       desc: "Low-barrier shelter providing dignity and safety for those in need.",
                       link: "https://citycareokc.org/",
                       icon: Clock
                     },
                     { 
                       name: "Sisu Youth Services", 
                       program: "Youth Shelter", 
                       desc: "Dedicated support and shelter for homeless youth ages 15-24.",
                       link: "https://www.sisuyouth.org/",
                       icon: Users
                     }
                   ].map((item, idx) => (
                     <a 
                       key={idx}
                       href={item.link}
                       target="_blank"
                       rel="noopener noreferrer"
                       className="group flex items-center bg-white p-4 rounded-3xl border border-neutral-100 hover:border-brand-green/30 transition-all shadow-sm active:scale-95"
                     >
                       <div className="w-14 h-14 bg-neutral-50 rounded-2xl flex items-center justify-center text-brand-green group-hover:bg-brand-green group-hover:text-white transition-all mr-4 shadow-inner">
                          <item.icon className="w-6 h-6" />
                       </div>
                       <div className="flex-1">
                          <div className="flex items-center justify-between">
                            <span className="text-[10px] font-black text-brand-green uppercase tracking-widest opacity-60 mb-0.5">{item.name}</span>
                            <ExternalLink className="w-3 h-3 text-neutral-300 group-hover:text-brand-green" />
                          </div>
                          <h5 className="font-black text-sm text-neutral-900 leading-tight uppercase underline decoration-transparent group-hover:decoration-brand-yellow decoration-2 underline-offset-2 transition-all">{item.program}</h5>
                          <p className="text-[11px] text-neutral-500 font-medium line-clamp-1 mt-0.5">{item.desc}</p>
                       </div>
                     </a>
                   ))}
                </div>
              </div>

              {/* Community Bulletin Post Board */}
              <div id="community-bulletin-board" className="bg-white border-2 border-brand-green/20 rounded-[2.5rem] p-6 space-y-6 shadow-sm">
                <div className="space-y-2 text-center">
                  <div className="w-12 h-12 bg-brand-green/5 rounded-3xl flex items-center justify-center mx-auto text-brand-green">
                    <Sparkles className="w-6 h-6 animate-pulse" />
                  </div>
                  <h3 className="text-2xl font-black text-brand-green leading-none italic tracking-tighter uppercase">Community Post Board</h3>
                  <p className="text-xs text-neutral-500 font-semibold max-w-md mx-auto">
                    Donate goods, offer rides, coordinate food supplies, or ask for help. A verified space strictly moderated under community standards.
                  </p>
                </div>

                {/* Submitting Form UI or Create Post button */}
                {!isCreatingPost ? (
                  <div className="flex justify-center">
                    <button
                      onClick={() => setIsCreatingPost(true)}
                      className="inline-flex items-center gap-2 bg-brand-green text-brand-yellow font-black px-6 py-3 rounded-2xl hover:bg-emerald-900 transition-all shadow-md text-xs uppercase tracking-wider"
                    >
                      <PlusCircle className="w-4 h-4" /> Create a Bulletin Board Post
                    </button>
                  </div>
                ) : (
                  <form onSubmit={handleSubmitBoardPost} className="space-y-4 bg-brand-green/5 p-5 rounded-3xl border border-brand-green/10">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-black text-brand-green uppercase tracking-wider">New Post Form</span>
                      <button 
                        type="button" 
                        onClick={() => {
                          setIsCreatingPost(false);
                          setPostModerativeFeedback(null);
                        }} 
                        className="text-neutral-400 hover:text-neutral-600 text-xs font-bold uppercase"
                      >
                        Cancel
                      </button>
                    </div>

                    {/* Post Type Buttons */}
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => setNewBoardPost(p => ({ ...p, type: 'offer' }))}
                        className={cn(
                          "py-2 px-4 rounded-xl border font-black text-xs uppercase transition-all",
                          newBoardPost.type === 'offer'
                            ? "bg-brand-green text-brand-yellow border-brand-green"
                            : "bg-white text-neutral-600 border-neutral-200"
                        )}
        
                      >
                        I have something to give
                      </button>
                      <button
                        type="button"
                        onClick={() => setNewBoardPost(p => ({ ...p, type: 'request' }))}
                        className={cn(
                          "py-2 px-4 rounded-xl border font-black text-xs uppercase transition-all",
                          newBoardPost.type === 'request'
                            ? "bg-[#ef4444]/90 text-white border-[#ef4444]/90"
                            : "bg-white text-neutral-600 border-neutral-200"
                        )}
        
                      >
                        I'm Requesting Goods/Rides
                      </button>
                    </div>

                    {/* Category Buttons */}
                    <div className="space-y-1">
                      <label className="text-[10px] font-black text-neutral-400 uppercase tracking-wider ml-1">Category</label>
                      <div className="grid grid-cols-4 gap-1.5">
                        {(['Goods', 'Rides', 'Food', 'Other'] as const).map(cat => (
                          <button
                            type="button"
                            key={cat}
                            onClick={() => setNewBoardPost(p => ({ ...p, category: cat }))}
                            className={cn(
                              "py-1.5 px-2 rounded-xl border text-[11px] font-bold transition-all",
                              newBoardPost.category === cat
                                ? "bg-neutral-900 text-white border-neutral-900"
                                : "bg-white text-neutral-500 border-neutral-200 hover:border-neutral-400"
                            )}
        
                          >
                            {cat}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Form Input fields */}
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-black text-neutral-400 uppercase tracking-wider ml-1">Brief Title</label>
                      <input
                        type="text"
                        placeholder="e.g. Free stroller + warm blankets / Need ride to shelter on Saturday"
                        value={newBoardPost.title}
                        onChange={e => setNewBoardPost(p => ({ ...p, title: e.target.value }))}
                        className="w-full bg-white border border-neutral-200 rounded-xl px-4 py-2.5 text-xs text-neutral-850 font-medium focus:ring-2 focus:ring-brand-green/20 focus:outline-none"
                        required
                        maxLength={150}
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-[10px] font-black text-neutral-400 uppercase tracking-wider ml-1">Detail Description</label>
                      <textarea
                        placeholder="Explain coordinates or item sizes. Please do not list commercial websites or ads."
                        value={newBoardPost.description}
                        onChange={e => setNewBoardPost(p => ({ ...p, description: e.target.value }))}
                        className="w-full bg-white border border-neutral-200 rounded-xl px-4 py-2.5 text-xs text-neutral-850 font-medium focus:ring-2 focus:ring-brand-green/20 focus:outline-none h-20 resize-none"
                        required
                        maxLength={1000}
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-[10px] font-black text-neutral-400 uppercase tracking-wider ml-1">Direct Contact Info</label>
                      <input
                        type="text"
                        placeholder="e.g. Text me at (405) xxx-xxxx / Email user@example.com"
                        value={newBoardPost.contactInfo}
                        onChange={e => setNewBoardPost(p => ({ ...p, contactInfo: e.target.value }))}
                        className="w-full bg-white border border-neutral-200 rounded-xl px-4 py-2.5 text-xs text-neutral-850 font-medium focus:ring-2 focus:ring-brand-green/20 focus:outline-none"
                        required
                        maxLength={200}
                      />
                      <span className="block text-[9px] text-neutral-400 font-semibold italic pl-1 leading-normal">
                        Note: No sex, pornography, explicit adult material, commercial ads, or profanity are tolerated. Content is filtered automatically using live safety checks.
                      </span>
                    </div>

                    {postModerativeFeedback && (
                      <div className="p-3 bg-red-100 border border-red-200 rounded-2xl text-xs font-extrabold text-red-850 uppercase tracking-wide flex items-center gap-2">
                        <AlertCircle className="w-4 h-4 shrink-0" />
                        <span>{postModerativeFeedback}</span>
                      </div>
                    )}
        

                    {!user ? (
                      <div className="text-center py-2 space-y-2">
                        <p className="text-[11px] text-neutral-500 font-bold">You need to sign in to publish board posts.</p>
                        <button
                          type="button"
                          onClick={handleSignIn}
                          className="bg-brand-green text-brand-yellow font-black px-5 py-2 rounded-xl text-xs hover:scale-105 transition-all uppercase"
                        >
                          Sign In
                        </button>
                      </div>
                    ) : (
                      <button
                        type="submit"
                        disabled={isSubmittingPost}
                        className={cn(
                          "w-full font-black py-3 rounded-2xl text-xs tracking-wider uppercase transition-all border-b-4",
                          isSubmittingPost
                            ? "bg-neutral-100 text-neutral-500 border-neutral-200 cursor-not-allowed animate-pulse"
                            : "bg-brand-green text-brand-yellow border-emerald-950 hover:scale-[1.01] active:translate-y-0.5 cursor-pointer"
                        )}
        
                      >
                        {isSubmittingPost ? "Moderating and publishing..." : "Submit Board Post"}
                      </button>
                    )}
        
                  </form>
                )}
        

                {/* Filters Row */}
                <div className="flex flex-col sm:flex-row gap-3 pt-2 justify-between border-t border-neutral-100">
                  {/* Type Filter */}
                  <div className="flex gap-1.5">
                    {(['All', 'Offers', 'Requests'] as const).map(filter => (
                      <button
                        key={filter}
                        type="button"
                        onClick={() => setActiveBoardFilter(filter)}
                        className={cn(
                          "px-3 py-1.5 rounded-full text-[10px] font-black uppercase tracking-wider transition-all border",
                          activeBoardFilter === filter
                            ? "bg-brand-green text-brand-yellow border-brand-green shadow-xs"
                            : "bg-white text-neutral-500 border-neutral-200 hover:border-neutral-400"
                        )}
        
                      >
                        {filter}
                      </button>
                    ))}
                  </div>

                  {/* Category Filter */}
                  <div className="flex gap-1 overflow-x-auto pb-1 no-scrollbar sm:max-w-[240px]">
                    {(['All', 'Goods', 'Rides', 'Food', 'Other'] as const).map(cat => (
                      <button
                        key={cat}
                        type="button"
                        onClick={() => setActiveBoardCategory(cat)}
                        className={cn(
                          "whitespace-nowrap px-2.5 py-1 rounded-full text-[9px] font-extrabold uppercase transition-all",
                          activeBoardCategory === cat
                            ? "bg-neutral-900 text-white"
                            : "bg-neutral-100 text-neutral-500 hover:bg-neutral-200"
                        )}
        
                      >
                        {cat}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Post Board Feed List */}
                {boardLoading ? (
                  <div className="text-center py-6">
                    <div className="w-6 h-6 border-2 border-brand-green border-t-transparent rounded-full animate-spin mx-auto mb-2"></div>
                    <span className="text-[10px] font-black text-neutral-400 uppercase tracking-widest">Refreshing Board Feed...</span>
                  </div>
                ) : (
                  <div className="space-y-3 max-h-[350px] overflow-y-auto pr-1 no-scrollbar">
                    {boardPosts
                      .filter(post => {
                        if (activeBoardFilter === 'Offers') return post.type === 'offer';
                        if (activeBoardFilter === 'Requests') return post.type === 'request';
                        return true;
                      })
                      .filter(post => {
                        if (activeBoardCategory === 'All') return true;
                        return post.category === activeBoardCategory;
                      })
                      .length === 0 ? (
                        <div className="text-center py-8 text-neutral-400 bg-neutral-50 rounded-2xl border border-dashed border-neutral-250">
                          <p className="text-xs font-bold uppercase tracking-wider">No active community posts here.</p>
                          <p className="text-[10px] mt-1 text-neutral-400">Be the first to post an offer or request!</p>
                        </div>
                      ) : (
                        boardPosts
                          .filter(post => {
                            if (activeBoardFilter === 'Offers') return post.type === 'offer';
                            if (activeBoardFilter === 'Requests') return post.type === 'request';
                            return true;
                          })
                          .filter(post => {
                            if (activeBoardCategory === 'All') return true;
                            return post.category === activeBoardCategory;
                          })
                          .map(post => (
                            <div 
                              key={post.id} 
                              className={cn(
                                "p-4 rounded-2xl border transition-all text-left space-y-2 relative group",
                                post.type === 'offer' 
                                  ? "bg-emerald-50/45 border-emerald-100" 
                                  : "bg-rose-50/45 border-rose-100"
                              )}
        
                            >
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-2">
                                  {post.userPhoto ? (
                                    <img 
                                      src={post.userPhoto} 
                                      alt={post.userName} 
                                      className="w-5 h-5 rounded-full object-cover border border-neutral-200"
                                      referrerPolicy="no-referrer"
                                    />
                                  ) : (
                                    <div className="w-5 h-5 rounded-full bg-neutral-250 flex items-center justify-center text-[8px] font-black text-neutral-500 uppercase">
                                      {post.userName ? post.userName[0] : '?'}
                                    </div>
                                  )}
        
                                  <span className="text-[10px] font-black text-neutral-800">{post.userName}</span>
                                </div>
                                <div className="flex items-center gap-1.5">
                                  <span className={cn(
                                    "text-[9px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider",
                                    post.type === 'offer' 
                                      ? "bg-brand-green/10 text-brand-green" 
                                      : "bg-[#ef4444]/10 text-[#ef4444]"
                                  )}
        >
                                    {post.type === 'offer' ? 'Offer' : 'Need'}
                                  </span>
                                  <span className="bg-neutral-205 text-neutral-600 text-[9px] font-black px-1.5 py-0.5 rounded uppercase">
                                    {post.category}
                                  </span>
                                </div>
                              </div>

                              <div className="space-y-1">
                                <p className="font-extrabold text-xs text-neutral-900 uppercase tracking-tight">{post.title}</p>
                                <p className="text-[11px] text-neutral-600 leading-normal font-semibold font-sans normal-case tracking-normal">{post.description}</p>
                              </div>

                              <div className="flex items-center justify-between pt-1 border-t border-neutral-200/50">
                                <p className="text-[10px] text-neutral-650 font-bold normal-case tracking-normal">
                                  <strong className="font-black text-brand-green uppercase text-[9px] tracking-wider">Contact Direct:</strong> {post.contactInfo}
                                </p>
                                {user?.uid === post.userId && (
                                  <button
                                    onClick={() => handleDeleteBoardPost(post.id)}
                                    type="button"
                                    className="text-neutral-400 hover:text-red-500 transition-colors p-1"
                                    title="Delete this post"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                )}
        
                              </div>
                            </div>
                          ))
                      )}
        
                  </div>
                )}
        
              </div>

              {/* Resource Quick Links */}
              <div className="grid grid-cols-2 gap-4">
                <div 
                  onClick={() => setSelectedResource('pantry')}
                  className="bg-emerald-50 p-6 rounded-3xl border border-emerald-100 flex flex-col items-center text-center space-y-3 hover:bg-emerald-100 transition-colors cursor-pointer group relative overflow-hidden"
                >
                  <div className="absolute top-2 right-2 flex items-center gap-1 bg-emerald-200/50 text-emerald-800 px-2 py-0.5 rounded-full text-[8px] font-black uppercase tracking-tighter">
                    <div className="w-1 h-1 bg-emerald-500 rounded-full animate-pulse" /> Live
                  </div>
                  <div className="w-12 h-12 bg-emerald-100 rounded-2xl flex items-center justify-center text-emerald-600 group-hover:scale-110 transition-transform">
                    <Package className="w-6 h-6" />
                  </div>
                  <span className="font-black text-xs text-brand-green uppercase tracking-wider">Food Pantries</span>
                </div>
                <div 
                  onClick={() => setSelectedResource('shelter')}
                  className="bg-brand-green/5 p-6 rounded-3xl border border-brand-green/10 flex flex-col items-center text-center space-y-3 hover:bg-brand-green/10 transition-colors cursor-pointer group relative overflow-hidden"
                >
                   <div className="absolute top-2 right-2 flex items-center gap-1 bg-brand-green/10 text-brand-green px-2 py-0.5 rounded-full text-[8px] font-black uppercase tracking-tighter">
                    <div className="w-1 h-1 bg-brand-green rounded-full animate-pulse" /> Live
                  </div>
                  <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-brand-green shadow-sm group-hover:scale-110 transition-transform">
                    <Home className="w-6 h-6" />
                  </div>
                  <span className="font-black text-xs text-brand-green uppercase tracking-wider">Shelter Info</span>
                </div>
              </div>
            </motion.div>
          )}
        

          {activeTab === 'map' && (
            <motion.div
              key="map"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="h-[60vh] bg-neutral-200 rounded-3xl flex items-center justify-center border-4 border-white shadow-inner overflow-hidden relative"
            >
              <div className="absolute inset-0 bg-[url('https://api.mapbox.com/styles/v1/mapbox/light-v10/static/-97.5164,35.4676,12,0/600x600?access_token=pk.eyJ1IjoiamFjb2JvcmNhcyIsImEiOiJjazY4bzFpNG0wNHh5M2VvMGV3Y3V3eW5hIn0.Yp9F_f3yX0p5i6O4pY-gjw')] bg-center bg-cover opacity-60"></div>
              
              {!isQRScannerActive ? (
                <div className="z-10 text-center space-y-6">
                  <div className="p-6 glass-morphism rounded-2xl max-w-[85%] mx-auto shadow-sm">
                    <MapPin className="w-10 h-10 text-orange-600 mx-auto mb-2" />
                    <h3 className="font-bold text-lg text-brand-green mb-1">Resource Map</h3>
                    <p className="text-sm text-neutral-600 font-semibold leading-snug">Finding nearby shelters, pantry locations, and community hubs.</p>
                  </div>
                  
                  <button
                    onClick={() => setIsQRScannerActive(true)}
                    className="bg-brand-green/95 text-brand-yellow px-8 py-3.5 rounded-2xl font-black shadow-xl shadow-brand-green/20 uppercase tracking-wider mx-auto flex items-center justify-center gap-3 hover:bg-green-900 transition-all active:scale-95"
                  >
                    <Search className="w-5 h-5" />
                    Scan Flyer QR
                  </button>
                </div>
              ) : (
                <div className="absolute inset-0 bg-neutral-900 flex flex-col z-50">
                  <div className="flex-1 relative overflow-hidden bg-black flex items-center justify-center">
                    <Scanner
                      onScan={(detected) => {
                        if (detected && detected.length > 0) {
                          const url = detected[0].rawValue;
                          if (url.includes('uid=')) {
                            try {
                              const theUrl = new URL(url);
                              const uid = theUrl.searchParams.get('uid');
                              if (uid) {
                                setIsQRScannerActive(false);
                                setPublicUserId(uid);
                              }
                            } catch(e) {}
                          }
                        }
                      }}
                      onError={(err) => console.warn("QR Scanner:", err)}
                    />
                    <div className="absolute top-4 right-4 z-50">
                      <button 
                        onClick={() => setIsQRScannerActive(false)}
                        className="bg-neutral-900/40 hover:bg-neutral-900/60 transition-all p-3 rounded-full text-white backdrop-blur-md shadow-lg"
                      >
                        <LogOut className="w-6 h-6 rotate-180" />
                      </button>
                    </div>
                    {/* Viewfinder overlay */}
                    <div className="absolute inset-0 pointer-events-none mt-20 mb-20 mx-10 border-2 border-brand-yellow/30 rounded-lg flex items-center justify-center">
                       <div className="absolute -top-1 -left-1 w-6 h-6 border-t-4 border-l-4 border-brand-yellow"></div>
                       <div className="absolute -top-1 -right-1 w-6 h-6 border-t-4 border-r-4 border-brand-yellow"></div>
                       <div className="absolute -bottom-1 -left-1 w-6 h-6 border-b-4 border-l-4 border-brand-yellow"></div>
                       <div className="absolute -bottom-1 -right-1 w-6 h-6 border-b-4 border-r-4 border-brand-yellow"></div>
                    </div>
                  </div>
                  <div className="p-4 text-center bg-neutral-900 pb-8">
                    <h4 className="text-white font-black uppercase tracking-widest text-sm mb-1">Scan Community Flyer</h4>
                    <p className="text-neutral-400 text-[10px] font-bold uppercase tracking-wider">Point camera at the QR code to open profile</p>
                  </div>
                </div>
              )}
        
            </motion.div>
          )}
        

          {activeTab === 'add' && (
            <motion.div
              key="add"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-white rounded-3xl p-6 border border-neutral-200 shadow-xl space-y-6"
            >
              <div className="text-center space-y-1">
                <h3 className="text-xl font-bold">Request Support</h3>
                <p className="text-sm text-neutral-500">How can the community help you today?</p>
              </div>

              {!user ? (
                <div className="text-center py-6 space-y-4">
                  <p className="text-sm text-neutral-600">Please sign in to post a request.</p>
                  <button 
                    onClick={handleSignIn}
                    className="bg-brand-green text-brand-yellow font-black px-8 py-3 rounded-2xl hover:bg-green-900 shadow-lg shadow-brand-green/20 transition-all"
                  >
                    SIGN IN WITH GOOGLE
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-neutral-400 uppercase tracking-wider ml-1">Type of Need</label>
                    <div className="grid grid-cols-3 gap-2">
                      {['Food', 'Supplies', 'Transport'].map((t) => (
                        <button 
                          key={t} 
                          onClick={() => setNewRequest(prev => ({ ...prev, type: t as SupportRequest['type'] }))}
                          className={cn(
                            "py-3 border rounded-xl text-sm font-medium transition-all",
                            newRequest.type === t 
                              ? "bg-brand-green text-white border-brand-green" 
                              : "border-neutral-200 hover:border-brand-green hover:bg-brand-green/5"
                          )}
        
                        >
                          {t}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-neutral-400 uppercase tracking-wider ml-1">Short Title</label>
                    <input 
                      type="text" 
                      placeholder="e.g. Need warm coats for kids"
                      value={newRequest.title}
                      onChange={(e) => setNewRequest(prev => ({ ...prev, title: e.target.value }))}
                      className="w-full bg-neutral-50 border border-neutral-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-brand-green/20"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-neutral-400 uppercase tracking-wider ml-1">Location</label>
                    <input 
                      type="text" 
                      placeholder="e.g. Downtown near Library"
                      value={newRequest.location}
                      onChange={(e) => setNewRequest(prev => ({ ...prev, location: e.target.value }))}
                      className="w-full bg-neutral-50 border border-neutral-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-brand-green/20"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-neutral-400 uppercase tracking-wider ml-1">Description</label>
                    <textarea 
                      rows={4}
                      placeholder="Provide details about the need..."
                      value={newRequest.description}
                      onChange={(e) => setNewRequest(prev => ({ ...prev, description: e.target.value }))}
                      className="w-full bg-neutral-50 border border-neutral-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-brand-green/20"
                    />
                  </div>

                  <div className="flex items-center gap-2 ml-1">
                    <input 
                      type="checkbox" 
                      id="urgent"
                      checked={newRequest.urgent}
                      onChange={(e) => setNewRequest(prev => ({ ...prev, urgent: e.target.checked }))}
                      className="w-4 h-4 text-brand-green rounded focus:ring-brand-green"
                    />
                    <label htmlFor="urgent" className="text-sm font-medium text-neutral-700">This is urgent</label>
                  </div>

                  <button 
                    onClick={handleSubmitRequest}
                    className="w-full bg-brand-green text-brand-yellow font-black py-4 rounded-2xl hover:bg-green-900 shadow-lg shadow-brand-green/20 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    POST REQUEST
                  </button>
                </div>
              )}
        
            </motion.div>
          )}
        

          {activeTab === 'inbox' && (
            <motion.div
              key="inbox"
              className="space-y-4"
            >
               <h3 className="font-bold text-xl mb-4">Messages</h3>
               <div className="bg-white border border-neutral-200 rounded-2xl p-6 text-center space-y-4">
                 <div className="w-16 h-16 bg-neutral-100 rounded-full flex items-center justify-center mx-auto text-neutral-400">
                   <MessageCircle className="w-8 h-8" />
                 </div>
                 <div className="space-y-1">
                   <p className="font-bold">No messages yet</p>
                   <p className="text-sm text-neutral-500">Connections were made when you offer or request help.</p>
                 </div>
               </div>
            </motion.div>
          )}
        

          {activeTab === 'admin' && user?.email === 'onandcrackin3@gmail.com' && (
            <motion.div
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              className="space-y-6"
            >
              {selectedAdminUser ? (
                /* USER INSPECTOR DETAIL & HISTORY LOG VIEW */
                <div className="space-y-6">
                  {/* Back button and title */}
                  <div className="flex items-center justify-between pb-2">
                    <button 
                      onClick={() => setSelectedAdminUser(null)}
                      className="inline-flex items-center gap-2 text-brand-green font-black text-xs uppercase tracking-wider bg-white px-4 py-2 rounded-xl border border-neutral-200 hover:bg-neutral-50 transition-all cursor-pointer shadow-xs"
                    >
                      <ChevronLeft className="w-4 h-4" /> Back to Members List
                    </button>
                    <span className="text-[10px] font-black text-brand-green bg-brand-yellow/30 px-3 py-1 rounded-full uppercase tracking-widest font-mono">
                      INSPECTOR MODE
                    </span>
                  </div>

                  {/* Profile Header Block */}
                  <div className="bg-white rounded-[2.5rem] p-6 shadow-sm border border-neutral-100 space-y-6">
                    <div className="flex items-start gap-4">
                      <div className="w-20 h-20 bg-brand-green/5 rounded-3xl border border-brand-yellow/30 overflow-hidden flex-shrink-0">
                        {selectedAdminUser.photoURL ? (
                          <img src={selectedAdminUser.photoURL} alt={selectedAdminUser.displayName} className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-brand-green bg-brand-yellow/5 text-3xl font-black">
                            {selectedAdminUser.displayName ? selectedAdminUser.displayName[0].toUpperCase() : "?"}
                          </div>
                        )}
        
                      </div>
                      <div className="flex-1 min-w-0 text-left">
                        <div className="flex items-center gap-2 flex-wrap">
                          <h3 className="text-xl font-black text-neutral-900 uppercase tracking-tight leading-none">{selectedAdminUser.displayName}</h3>
                          <span className="bg-brand-green/10 text-brand-green font-black text-[9px] uppercase px-2 py-0.5 rounded-full tracking-wider">
                            Impact Score: {selectedAdminUser.contributionsCount || 0}
                          </span>
                        </div>
                        <p className="text-xs text-neutral-500 font-bold mt-1">{selectedAdminUser.email}</p>
                        <p className="text-[10px] text-neutral-400 font-bold uppercase tracking-wider mt-2 flex items-center gap-1.5">
                          <Clock className="w-3.5 h-3.5 text-neutral-350" />
                          Joined: {selectedAdminUser.joinedAt ? new Date((selectedAdminUser.joinedAt as any).seconds * 1000).toLocaleDateString("en-US", { year: 'numeric', month: 'long', day: 'numeric' }) : 'N/A'}
                        </p>
                      </div>
                    </div>

                    {/* Bio Statement */}
                    <div className="bg-neutral-50 p-4 rounded-2.5xl border border-neutral-150 relative text-left">
                      <span className="absolute -top-2.5 left-4 bg-white px-2 text-[8px] font-black text-neutral-400 uppercase tracking-widest border border-neutral-150 rounded">Bio Statement</span>
                      <p className="text-xs text-neutral-600 font-semibold leading-relaxed italic normal-case tracking-normal">
                        "{selectedAdminUser.bio || "I'm a community member looking to connect and support neighbors. Digital Hand Up helps us bridge the gap together."}"
                      </p>
                    </div>

                    {/* Short Term / Long Term Goals */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 text-left">
                      <div className="bg-brand-green text-white p-4.5 rounded-2.5xl flex flex-col justify-between">
                        <div>
                          <p className="text-[9px] font-black text-brand-yellow uppercase tracking-widest mb-1.5 leading-none">Short-Term Goals</p>
                          <p className="text-xs font-semibold opacity-90 normal-case tracking-normal leading-relaxed">{selectedAdminUser.shortTermGoals || 'Establishing stability in the neighborhood.'}</p>
                        </div>
                      </div>
                      <div className="bg-emerald-50 text-neutral-800 p-4.5 rounded-2.5xl flex flex-col justify-between border border-emerald-100">
                        <div>
                          <p className="text-[9px] font-black text-brand-green uppercase tracking-widest mb-1.5 leading-none">Long-Term Goals</p>
                          <p className="text-xs font-semibold text-neutral-700 normal-case tracking-normal leading-relaxed">{selectedAdminUser.longTermGoals || 'Establishing a long-term safe residency & giving back to OKC.'}</p>
                        </div>
                      </div>
                    </div>

                    {/* Linked Pouch/Payments */}
                    <div className="space-y-2 text-left">
                      <p className="text-[10px] font-black text-neutral-400 uppercase tracking-widest px-1">Linked Direct Payout Channels</p>
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                        {selectedAdminUser.cashAppId && (
                          <div className="p-3 bg-neutral-50 border border-neutral-200/70 rounded-xl">
                            <span className="block text-[8px] font-black text-emerald-600 uppercase tracking-wider mb-0.5">Cash App</span>
                            <span className="text-xs font-bold font-mono text-neutral-800">${selectedAdminUser.cashAppId}</span>
                          </div>
                        )}
        
                        {selectedAdminUser.venmoId && (
                          <div className="p-3 bg-neutral-50 border border-neutral-200/70 rounded-xl">
                            <span className="block text-[8px] font-black text-blue-600 uppercase tracking-wider mb-0.5">Venmo</span>
                            <span className="text-xs font-bold font-mono text-neutral-800">@{selectedAdminUser.venmoId}</span>
                          </div>
                        )}
        
                        {selectedAdminUser.payPalId && (
                          <div className="p-3 bg-neutral-50 border border-neutral-200/70 rounded-xl">
                            <span className="block text-[8px] font-black text-indigo-600 uppercase tracking-wider mb-0.5">PayPal</span>
                            <span className="text-xs font-bold font-mono text-neutral-800">{selectedAdminUser.payPalId}</span>
                          </div>
                        )}
        
                        {selectedAdminUser.zelleId && (
                          <div className="p-3 bg-neutral-50 border border-neutral-200/70 rounded-xl">
                            <span className="block text-[8px] font-black text-purple-600 uppercase tracking-wider mb-0.5">Zelle</span>
                            <span className="text-xs font-bold font-mono text-neutral-800">{selectedAdminUser.zelleId}</span>
                          </div>
                        )}
        
                        {selectedAdminUser.chimeId && (
                          <div className="p-3 bg-neutral-50 border border-neutral-200/70 rounded-xl">
                            <span className="block text-[8px] font-black text-green-600 uppercase tracking-wider mb-0.5">Chime</span>
                            <span className="text-xs font-bold font-mono text-neutral-800">{selectedAdminUser.chimeId}</span>
                          </div>
                        )}
        
                        {selectedAdminUser.allRegistryUrl && (
                          <div className="p-3 bg-neutral-50 border border-neutral-200/70 rounded-xl">
                            <span className="block text-[8px] font-black text-neutral-600 uppercase tracking-wider mb-0.5">AllRegistry.com</span>
                            <span className="text-[10px] font-black text-brand-green truncate block uppercase tracking-tight">Active</span>
                          </div>
                        )}
        
                        {(!selectedAdminUser.cashAppId && !selectedAdminUser.venmoId && !selectedAdminUser.payPalId && !selectedAdminUser.zelleId && !selectedAdminUser.chimeId && !selectedAdminUser.allRegistryUrl) && (
                          <div className="col-span-full p-3 bg-neutral-50 border border-neutral-200/70 rounded-xl text-center">
                            <span className="text-[10px] font-black text-neutral-400 uppercase tracking-widest">No payout/registry wallets linked</span>
                          </div>
                        )}
        
                      </div>
                    </div>
                  </div>

                  {/* Active Postings Summary Panel */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Hand Up requests */}
                    <div className="bg-white rounded-[2rem] p-6 shadow-sm border border-neutral-100 space-y-4">
                      <div className="flex items-center justify-between">
                        <h4 className="text-xs font-black text-neutral-450 uppercase tracking-widest flex items-center gap-2">
                          <Package className="w-4.5 h-4.5 text-brand-green" />
                          Support Requests ({requests.filter(r => r.userId === selectedAdminUser.userId || r.userId === selectedAdminUser.id).length})
                        </h4>
                      </div>

                      <div className="space-y-3 max-h-[280px] overflow-y-auto pr-1">
                        {requests.filter(r => r.userId === selectedAdminUser.userId || r.userId === selectedAdminUser.id).length === 0 ? (
                          <div className="p-6 bg-neutral-50 border border-dashed border-neutral-200 rounded-2xl text-center">
                            <p className="text-[10px] font-black text-neutral-400 uppercase tracking-wider">No support requests posted yet</p>
                          </div>
                        ) : (
                          requests.filter(r => r.userId === selectedAdminUser.userId || r.userId === selectedAdminUser.id).map(r => (
                            <div key={r.id} className="p-3.5 bg-neutral-50/75 border border-neutral-150 rounded-2xl space-y-2 text-left relative group">
                              <div className="flex items-start justify-between">
                                <span className={cn(
                                  "px-2 py-0.5 rounded-[6px] text-[8px] font-black uppercase tracking-wider text-white",
                                  r.type === 'Supplies' ? "bg-blue-600" : r.type === 'Transport' ? "bg-purple-600" : "bg-emerald-600"
                                )}
        >
                                  {r.type}
                                </span>
                                <button 
                                  onClick={async (e) => {
                                    e.stopPropagation();
                                    if (window.confirm(`Are you sure you want to delete support request: "${r.title}"?`)) {
                                      await handleDeleteSupportRequest(r.id);
                                    }
                                  }}
                                  className="text-neutral-400 hover:text-red-500 opacity-60 group-hover:opacity-100 transition-opacity p-1 cursor-pointer"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </div>
                              <h5 className="font-extrabold text-xs text-neutral-800 uppercase tracking-tight pr-5">{r.title}</h5>
                              <p className="text-[10px] text-neutral-500 leading-normal line-clamp-2 pr-2 leading-relaxed font-semibold normal-case tracking-normal">{r.description}</p>
                              <div className="flex justify-between items-center text-[8px] font-black text-neutral-450 uppercase tracking-widest pt-1 border-t border-neutral-200/50">
                                <span>Loc: {r.location}</span>
                                <span>Status: {r.status?.toUpperCase() || "OPEN"}</span>
                              </div>
                            </div>
                          ))
                        )}
        
                      </div>
                    </div>

                    {/* Community posts */}
                    <div className="bg-white rounded-[2rem] p-6 shadow-sm border border-neutral-100 space-y-4">
                      <div className="flex items-center justify-between">
                        <h4 className="text-xs font-black text-neutral-450 uppercase tracking-widest flex items-center gap-2">
                          <Sparkles className="w-4.5 h-4.5 text-amber-500" />
                          Bulletin Board Posts ({boardPosts.filter(p => p.userId === selectedAdminUser.userId || p.userId === selectedAdminUser.id).length})
                        </h4>
                      </div>

                      <div className="space-y-3 max-h-[280px] overflow-y-auto pr-1">
                        {boardPosts.filter(p => p.userId === selectedAdminUser.userId || p.userId === selectedAdminUser.id).length === 0 ? (
                          <div className="p-6 bg-neutral-50 border border-dashed border-neutral-200 rounded-2xl text-center">
                            <p className="text-[10px] font-black text-neutral-400 uppercase tracking-wider">No bulletin board posts yet</p>
                          </div>
                        ) : (
                          boardPosts.filter(p => p.userId === selectedAdminUser.userId || p.userId === selectedAdminUser.id).map(p => (
                            <div key={p.id} className="p-3.5 bg-neutral-50/75 border border-neutral-150 rounded-2xl space-y-2 text-left relative group">
                              <div className="flex items-center justify-between">
                                <span className={cn(
                                  "px-2 py-0.5 rounded-[6px] text-[8px] font-black uppercase tracking-wider",
                                  p.type === 'offer' ? "bg-emerald-100 text-brand-green" : "bg-rose-100 text-rose-700"
                                )}
        >
                                  {p.type === 'offer' ? 'Offer' : 'Request'} ({p.category})
                                </span>
                                <button 
                                  onClick={async (e) => {
                                    e.stopPropagation();
                                    if (window.confirm(`Are you sure you want to delete board post: "${p.title}"?`)) {
                                      await handleDeleteBoardPost(p.id);
                                    }
                                  }}
                                  className="text-neutral-400 hover:text-red-500 opacity-60 group-hover:opacity-100 transition-opacity p-1 cursor-pointer"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </div>
                              <h5 className="font-extrabold text-xs text-neutral-800 uppercase tracking-tight pr-5">{p.title}</h5>
                              <p className="text-[10px] text-neutral-500 leading-normal line-clamp-2 pr-2 leading-relaxed font-semibold normal-case tracking-normal">{p.description}</p>
                              <div className="text-[8px] font-black text-brand-green uppercase tracking-widest pt-1 border-t border-neutral-200/50 block">
                                Contact: <span className="text-neutral-700">{p.contactInfo}</span>
                              </div>
                            </div>
                          ))
                        )}
        
                      </div>
                    </div>
                  </div>

                  {/* User log / timeline */}
                  <div className="bg-white rounded-[2.5rem] p-6 shadow-sm border border-neutral-100 space-y-5">
                    <div className="space-y-1 text-left">
                      <h4 className="text-xs font-black text-neutral-450 uppercase tracking-widest flex items-center gap-2">
                        <Clock className="w-4 h-4 text-brand-green" />
                        Aesthetic Timeline History Log
                      </h4>
                      <p className="text-[10px] text-neutral-400 font-bold uppercase tracking-wider">Historical actions completed on the Digital Hand Up app</p>
                    </div>

                    <div className="relative pl-6 border-l border-neutral-200 space-y-6 ml-3 pt-2 text-left">
                      {(() => {
                        const userReqs = requests.filter(r => r.userId === selectedAdminUser.userId || r.userId === selectedAdminUser.id);
                        const userPosts = boardPosts.filter(p => p.userId === selectedAdminUser.userId || p.userId === selectedAdminUser.id);
                        
                        const timelineEvents = [
                          {
                            id: 'join',
                            date: selectedAdminUser.joinedAt 
                              ? new Date((selectedAdminUser.joinedAt as any).seconds * 1000) 
                              : new Date(Date.now() - 3 * 24 * 60 * 60 * 1000), 
                            title: 'Member Registered & Onboarded',
                            desc: 'Joined the platform and completed profile setup goals.',
                            badge: 'SYSTEM',
                            tagColor: 'bg-emerald-600 text-white',
                            icon: <User className="w-3.5 h-3.5" />
                          }
                        ];

                        userReqs.forEach(req => {
                          timelineEvents.push({
                            id: `req_${req.id}`,
                            date: req.timestamp ? new Date((req.timestamp as any).seconds * 1000) : new Date(),
                            title: `Published Support Request: "${req.title}"`,
                            desc: `Requested direct ${req.type} items/support at location "${req.location}". Currently styled status is "${req.status || 'open'}".`,
                            badge: 'NEED STATEMENT',
                            tagColor: 'bg-blue-600 text-white',
                            icon: <Package className="w-3.5 h-3.5" />
                          });
                        });

                        userPosts.forEach(post => {
                          timelineEvents.push({
                            id: `post_${post.id}`,
                            date: post.timestamp ? new Date((post.timestamp as any).seconds * 1000) : new Date(),
                            title: `Posted on Bulletin Board: "${post.title}"`,
                            desc: `Created a board listing under ${post.category}. Provided contact channel details: "${post.contactInfo}".`,
                            badge: 'BULLETIN BOARD',
                            tagColor: 'bg-amber-600 text-white',
                            icon: <Sparkles className="w-3.5 h-3.5" />
                          });
                        });

                        // Sort chronological descending
                        timelineEvents.sort((a, b) => b.date.getTime() - a.date.getTime());

                        return timelineEvents.map((ev, index) => (
                          <div key={ev.id + index} className="relative group">
                            {/* Dot indicator */}
                            <span className="absolute -left-[30px] top-1.5 w-4.5 h-4.5 rounded-full border bg-white flex items-center justify-center shadow-xs">
                              <span className="w-1.5 h-1.5 bg-brand-green rounded-full"></span>
                            </span>
                            
                            {/* Content Block */}
                            <div className="space-y-1">
                              <div className="flex items-center gap-2 flex-wrap">
                                <span className="text-[9px] text-neutral-400 font-bold uppercase tracking-wider">
                                  {ev.date.toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                                </span>
                                <span className={cn("text-[8px] font-black px-2 py-0.5 rounded uppercase tracking-widest", ev.tagColor || "bg-neutral-200 text-neutral-600")}>
                                  {ev.badge}
                                </span>
                              </div>
                              <h5 className="font-extrabold text-sm text-neutral-800 uppercase tracking-tight leading-none">{ev.title}</h5>
                              <p className="text-xs text-neutral-600 font-medium leading-relaxed max-w-xl normal-case tracking-normal">{ev.desc}</p>
                            </div>
                          </div>
                        ));
                      })()}
                    </div>
                  </div>
                </div>
              ) : (
                /* DEFAULT REGISTERED MEMBERS LIST PANEL */
                <div className="space-y-6">
                  <div className="bg-white rounded-[2.5rem] p-8 shadow-sm border border-neutral-100">
                    <div className="flex items-center justify-between mb-8">
                      <div className="flex items-center gap-4">
                        <div className="w-16 h-16 bg-brand-green/10 rounded-2xl flex items-center justify-center text-brand-green">
                          <Shield className="w-8 h-8" />
                        </div>
                        <div className="text-left">
                          <h2 className="text-2xl font-black italic tracking-tighter uppercase leading-none">Admin <br /><span className="text-brand-green underline decoration-brand-yellow decoration-4 underline-offset-4">Dashboard</span></h2>
                          <p className="text-[10px] font-black text-neutral-400 uppercase tracking-widest mt-1">Digital Hand Up • Internal</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <button 
                          onClick={() => {
                            fetchAdminUsers();
                          }}
                          className="w-10 h-10 bg-neutral-100 rounded-full flex items-center justify-center text-neutral-400 hover:text-brand-green transition-transform active:rotate-180 cursor-pointer"
                        >
                          <Clock className="w-5 h-5" />
                        </button>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div className="flex items-center justify-between px-2">
                        <h3 className="text-sm font-black text-neutral-400 uppercase tracking-widest">Registered Members ({adminUsers.length})</h3>
                        {adminLoading && <div className="w-4 h-4 border-2 border-brand-green border-t-transparent rounded-full animate-spin"></div>}
                      </div>

                      <div className="grid grid-cols-1 gap-3 text-left">
                        {adminUsers.length > 0 ? (
                          adminUsers.map((u) => (
                            <div 
                              key={u.userId} 
                              onClick={() => setSelectedAdminUser(u)}
                              className="flex items-center bg-neutral-50 p-4 rounded-3xl border border-neutral-100 hover:border-brand-green/40 hover:bg-neutral-100/30 cursor-pointer transition-all active:scale-[0.99] shadow-xs group"
                            >
                              <div className="w-12 h-12 bg-white rounded-2xl border-2 border-brand-yellow/30 overflow-hidden flex-shrink-0 mr-4">
                                {u.photoURL ? (
                                  <img src={u.photoURL} alt={u.displayName} className="w-full h-full object-cover" />
                                ) : (
                                  <div className="w-full h-full flex items-center justify-center text-brand-green bg-brand-yellow/5">
                                    <User className="w-6 h-6" />
                                  </div>
                                )}
        
                              </div>
                              <div className="flex-1 min-w-0">
                                <h4 className="font-black text-sm text-neutral-900 truncate uppercase tracking-tight group-hover:text-brand-green transition-colors">{u.displayName}</h4>
                                <p className="text-[10px] text-neutral-500 font-bold truncate opacity-80">{u.email}</p>
                                <div className="flex items-center gap-3 mt-1.5">
                                  <span className="text-[9px] font-black text-brand-green uppercase tracking-widest">Joined: {u.joinedAt ? new Date((u.joinedAt as any).seconds * 1000).toLocaleDateString() : 'N/A'}</span>
                                  <span className="text-[9px] font-black text-neutral-400 uppercase tracking-widest">Impact: {u.contributionsCount || 0}</span>
                                </div>
                              </div>
                              <button 
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setPublicUserId(u.userId);
                                }}
                                className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-neutral-400 hover:text-brand-green shadow-xs border border-neutral-100 cursor-pointer"
                              >
                                <ExternalLink className="w-4 h-4" />
                              </button>
                            </div>
                          ))
                        ) : (
                          <div className="text-center py-10 bg-neutral-50 rounded-[2rem] border border-dashed border-neutral-200">
                            <Users className="w-8 h-8 text-neutral-300 mx-auto mb-2" />
                            <p className="text-xs font-bold text-neutral-400 uppercase tracking-widest">No users found</p>
                          </div>
                        )}
        
                      </div>
                    </div>
                  </div>

                  {/* Admin Quick Tips Card */}
                  <div className="bg-brand-green p-6 rounded-[2.5rem] text-white shadow-xl text-left">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center">
                        <AlertTriangle className="w-5 h-5 text-brand-yellow" />
                      </div>
                      <h3 className="font-black italic uppercase tracking-tighter text-lg">Admin Protocols</h3>
                    </div>
                    <ul className="space-y-3">
                      <li className="flex items-start gap-3">
                        <div className="w-1.5 h-1.5 bg-brand-yellow rounded-full mt-1.5"></div>
                        <p className="text-[11px] font-medium opacity-80 leading-relaxed normal-case tracking-normal">Click any registered member card to view their complete audit trail history log, listed board postings, direct support requests, and configured wallet options in detail.</p>
                      </li>
                      <li className="flex items-start gap-3">
                        <div className="w-1.5 h-1.5 bg-brand-yellow rounded-full mt-1.5"></div>
                        <p className="text-[11px] font-medium opacity-80 leading-relaxed normal-case tracking-normal">Directly delete or moderate spam board posts and support needs directly from within their chronological inspector log.</p>
                      </li>
                    </ul>
                  </div>
                </div>
              )}
        
            </motion.div>
          )}
        

          {activeTab === 'profile' && (
             <motion.div
              key="profile"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-6"
             >
                {isEditingProfile ? (
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="bg-white border border-neutral-200 rounded-[2rem] p-6 shadow-xl space-y-6"
                  >
                    <div className="flex items-center justify-between">
                      <h3 className="text-2xl font-black text-brand-green italic uppercase tracking-tighter">Edit Profile</h3>
                      <button onClick={() => setIsEditingProfile(false)} className="text-neutral-400 font-bold text-sm">Cancel</button>
                    </div>

                    <div className="flex flex-col items-center gap-4 pt-2">
                       <div 
                         onClick={() => fileInputRef.current?.click()}
                         className="relative group cursor-pointer"
                       >
                          {(editedProfile.photoURL || user?.photoURL) && (
                            <img 
                              src={editedProfile.photoURL || user?.photoURL} 
                              alt="Preview" 
                              className="w-24 h-24 rounded-full border-4 border-brand-yellow shadow-lg object-cover bg-neutral-100 transition-transform group-hover:scale-105" 
                            />
                          )}
        
                          <div className="absolute inset-0 bg-black/20 rounded-full flex items-center justify-center md:opacity-0 md:group-hover:opacity-100 opacity-100 transition-opacity">
                             <Camera className="w-6 h-6 text-white" />
                          </div>
                          <input 
                            type="file" 
                            ref={fileInputRef} 
                            onChange={handleImageUpload} 
                            accept="image/*" 
                            className="hidden" 
                          />
                       </div>

                       <button 
                         onClick={startCamera}
                         className="flex items-center gap-2 px-4 py-2 bg-neutral-100 text-neutral-600 rounded-full text-[10px] font-black uppercase hover:bg-brand-yellow hover:text-brand-green transition-all shadow-sm"
                       >
                         <Camera className="w-3.5 h-3.5" />
                         Take Photo
                       </button>

                       {isCameraOpen && (
                        <div className="fixed inset-0 z-[100] bg-black/95 flex flex-col items-center justify-center p-6 backdrop-blur-md">
                          <div className="relative w-full max-w-sm aspect-square bg-neutral-800 rounded-[3rem] overflow-hidden shadow-2xl border-4 border-brand-yellow">
                            <video 
                              ref={videoRef} 
                              autoPlay 
                              playsInline 
                              className="w-full h-full object-cover"
                            />
                            <div className="absolute inset-0 border-[30px] border-black/40 pointer-events-none"></div>
                            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 border-2 border-white/30 rounded-full border-dashed pointer-events-none"></div>
                          </div>
                          
                          <div className="mt-12 flex flex-col items-center gap-8 w-full max-w-xs">
                            <button 
                              onClick={capturePhoto}
                              className="w-20 h-20 bg-white rounded-full flex items-center justify-center border-8 border-neutral-300 active:scale-90 transition-transform shadow-2xl"
                            >
                              <div className="w-12 h-12 bg-brand-green rounded-full flex items-center justify-center">
                                <div className="w-6 h-6 border-2 border-white/50 rounded-full"></div>
                              </div>
                            </button>
                            
                            <button 
                              onClick={stopCamera}
                              className="text-white font-black uppercase tracking-[0.3em] text-xs hover:text-brand-yellow transition-colors py-2 px-4"
                            >
                              Skip / Cancel
                            </button>
                          </div>
                        </div>
                      )}
        

                       <div className="w-full space-y-1.5">
                          <label className="text-[10px] font-black text-neutral-400 uppercase tracking-widest ml-1">Profile Photo URL</label>
                          <div className="flex gap-2">
                            <input 
                              placeholder="https://..."
                              value={editedProfile.photoURL || ''}
                              onChange={e => setEditedProfile(p => ({ ...p, photoURL: e.target.value }))}
                              className="flex-1 bg-neutral-50 border border-neutral-200 rounded-2xl px-4 py-3 focus:ring-2 focus:ring-brand-green/20 outline-none text-sm"
                            />
                            {user?.photoURL && editedProfile.photoURL !== user.photoURL && (
                              <button 
                                onClick={() => setEditedProfile(p => ({ ...p, photoURL: user.photoURL || '' }))}
                                className="px-3 bg-neutral-100 text-neutral-500 rounded-2xl text-[10px] font-black uppercase hover:bg-neutral-200 transition-colors"
                                title="Reset to Google Photo"
                              >
                                Reset
                              </button>
                            )}
        
                          </div>
                       </div>
                    </div>

                    <div className="space-y-4">
                      <div className="space-y-1.5">
                        <label className="text-[10px] font-black text-neutral-400 uppercase tracking-widest ml-1">Display Name</label>
                        <input 
                          placeholder="Your name..."
                          value={editedProfile.displayName || ''}
                          onChange={e => setEditedProfile(p => ({ ...p, displayName: e.target.value }))}
                          className="w-full bg-neutral-50 border border-neutral-200 rounded-2xl px-4 py-3 focus:ring-2 focus:ring-brand-green/20 outline-none"
                        />
                      </div>

                      <div className="space-y-1.5">
                        <label className="text-[10px] font-black text-neutral-400 uppercase tracking-widest ml-1">Bio & Your Story</label>
                        <textarea 
                          placeholder="Your story..."
                          rows={3}
                          value={editedProfile.bio || ''}
                          onChange={e => setEditedProfile(p => ({ ...p, bio: e.target.value }))}
                          className="w-full bg-neutral-50 border border-neutral-200 rounded-2xl px-4 py-3 focus:ring-2 focus:ring-brand-green/20 outline-none"
                        />
                        <p className="text-[10px] text-neutral-400 font-bold px-1">
                          No links, advertising, drugs, profanity, or explicit content allowed. Profiles are moderated.
                        </p>
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-1.5">
                          <label className="text-[10px] font-black text-neutral-400 uppercase tracking-widest ml-1">City / Neighborhood</label>
                          <input 
                            placeholder="e.g. Bricktown"
                            value={editedProfile.location || ''}
                            onChange={e => setEditedProfile(p => ({ ...p, location: e.target.value }))}
                            className="w-full bg-neutral-50 border border-neutral-200 rounded-2xl px-4 py-3 focus:ring-2 focus:ring-brand-green/20 outline-none"
                          />
                        </div>
                        <div className="space-y-1.5">
                          <label className="text-[10px] font-black text-neutral-400 uppercase tracking-widest ml-1">State</label>
                          <select 
                            value={editedProfile.state || ''}
                            onChange={e => setEditedProfile(p => ({ ...p, state: e.target.value }))}
                            className="w-full bg-neutral-50 border border-neutral-200 rounded-2xl px-4 py-3 focus:ring-2 focus:ring-brand-green/20 outline-none"
                          >
                             <option value="">Select State</option>
                             {US_STATES.map(state => (
                               <option key={state} value={state}>{state}</option>
                             ))}
                          </select>
                        </div>
                      </div>

                      <div className="flex items-center gap-3 py-2 px-1">
                        <input 
                          type="checkbox" 
                          id="pet"
                          checked={editedProfile.hasPet || false}
                          onChange={e => setEditedProfile(p => ({ ...p, hasPet: e.target.checked }))}
                          className="w-5 h-5 text-brand-green rounded outline-none cursor-pointer"
                        />
                        <label htmlFor="pet" className="text-xs font-black text-brand-green uppercase tracking-tighter cursor-pointer">I have pets</label>
                      </div>

                      <div className="space-y-4">
                        <h4 className="text-[10px] font-black text-neutral-400 uppercase tracking-widest ml-1 pt-2">My Goals</h4>
                        <input 
                          placeholder="Short term goal..."
                          value={editedProfile.shortTermGoals || ''}
                          onChange={e => setEditedProfile(p => ({ ...p, shortTermGoals: e.target.value }))}
                          className="w-full bg-neutral-50 border border-neutral-200 rounded-2xl px-4 py-3 focus:ring-2 focus:ring-brand-green/20 outline-none"
                        />
                        <input 
                          placeholder="Long term goal..."
                          value={editedProfile.longTermGoals || ''}
                          onChange={e => setEditedProfile(p => ({ ...p, longTermGoals: e.target.value }))}
                          className="w-full bg-neutral-50 border border-neutral-200 rounded-2xl px-4 py-3 focus:ring-2 focus:ring-brand-green/20 outline-none"
                        />
                      </div>

                      <div className="space-y-4 pt-2">
                        <h4 className="text-[10px] font-black text-neutral-400 uppercase tracking-widest ml-1">Support Info</h4>
                        <div className="grid grid-cols-2 gap-3">
                          <div className="relative">
                            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-neutral-400 font-bold">$</span>
                            <input 
                              placeholder="CashApp ID"
                              value={editedProfile.cashAppId || ''}
                              onChange={e => setEditedProfile(p => ({ ...p, cashAppId: e.target.value }))}
                              className="w-full bg-neutral-50 border border-neutral-200 rounded-2xl pl-8 pr-4 py-3 focus:ring-2 focus:ring-brand-green/20 outline-none text-sm"
                            />
                          </div>
                          <div className="relative">
                            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-neutral-400 font-bold">@</span>
                            <input 
                              placeholder="Venmo ID"
                              value={editedProfile.venmoId || ''}
                              onChange={e => setEditedProfile(p => ({ ...p, venmoId: e.target.value }))}
                              className="w-full bg-neutral-50 border border-neutral-200 rounded-2xl pl-8 pr-4 py-3 focus:ring-2 focus:ring-brand-green/20 outline-none text-sm"
                            />
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div className="relative">
                            <input 
                              placeholder="PayPal ID"
                              value={editedProfile.payPalId || ''}
                              onChange={e => setEditedProfile(p => ({ ...p, payPalId: e.target.value }))}
                              className="w-full bg-neutral-50 border border-neutral-200 rounded-2xl px-4 py-3 focus:ring-2 focus:ring-brand-green/20 outline-none text-sm"
                            />
                          </div>
                          <div className="relative">
                            <input 
                              placeholder="Zelle (Email/Phone)"
                              value={editedProfile.zelleId || ''}
                              onChange={e => setEditedProfile(p => ({ ...p, zelleId: e.target.value }))}
                              className="w-full bg-neutral-50 border border-neutral-200 rounded-2xl px-4 py-3 focus:ring-2 focus:ring-brand-green/20 outline-none text-sm"
                            />
                          </div>
                        </div>

                        <div className="space-y-3">
                          <input 
                            placeholder="Chime Tag / ID"
                            value={editedProfile.chimeId || ''}
                            onChange={e => setEditedProfile(p => ({ ...p, chimeId: e.target.value }))}
                            className="w-full bg-neutral-50 border border-neutral-200 rounded-2xl px-4 py-3 focus:ring-2 focus:ring-brand-green/20 outline-none text-sm"
                          />
                          <input 
                            placeholder="AllRegistry.com URL"
                            value={editedProfile.allRegistryUrl || ''}
                            onChange={e => setEditedProfile(p => ({ ...p, allRegistryUrl: e.target.value }))}
                            className="w-full bg-neutral-50 border border-neutral-200 rounded-2xl px-4 py-3 focus:ring-2 focus:ring-brand-green/20 outline-none text-sm"
                          />
                        </div>
                      </div>

                      {updateError && (
                        <div className="bg-red-50/85 border border-red-200 rounded-2xl p-4 space-y-2.5 text-left normal-case tracking-normal">
                          <div className="flex items-start gap-2.5 text-red-900">
                            <AlertCircle className="w-4.5 h-4.5 text-red-600 shrink-0 mt-0.5" />
                            <div className="space-y-1">
                              <p className="text-[11px] font-extrabold uppercase tracking-wide">
                                Profile Filter Notice
                              </p>
                              <p className="text-xs text-red-800 font-semibold leading-relaxed">
                                {updateError}
                              </p>
                            </div>
                          </div>
                          
                          {/* AI Moderation Tips */}
                          {(updateError.toLowerCase().includes('safety') || 
                            updateError.toLowerCase().includes('filter') || 
                            updateError.toLowerCase().includes('moderate') || 
                            updateError.toLowerCase().includes('link') || 
                            updateError.toLowerCase().includes('violation')) && (
                            <div className="bg-white/80 rounded-xl p-3 border border-red-100 space-y-1.5 text-[10px] text-neutral-600 leading-normal font-semibold">
                              <p className="font-bold text-red-900 uppercase text-[9px] tracking-wider">Helpful Checklist:</p>
                              <ul className="list-disc pl-4 space-y-1 text-[9px]">
                                <li><strong>No URLs or Websites:</strong> Oklahoma City safety guidelines forbid putting domain links (like ".com", ".org", "www.") inside the Bio. Please remove them.</li>
                                <li><strong>Keep Support Intent:</strong> Ensure your writing is helpful, respectful, and friendly with zero profanities or NSFW topics.</li>
                                <li><strong>Image Compliance:</strong> Clean profile/avatar image containing supportive and safe-for-work content.</li>
                              </ul>
                            </div>
                          )}
        
                        </div>
                      )}
        

                      <button 
                        onClick={handleUpdateProfile}
                        disabled={isUpdatingProfile}
                        className="w-full bg-brand-green text-brand-yellow font-black py-4 rounded-2xl shadow-xl shadow-brand-green/20 hover:bg-green-900 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                      >
                        {isUpdatingProfile ? (
                          <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                        ) : (
                          <Save className="w-5 h-5" />
                        )}
        
                        {isUpdatingProfile ? 'SAVING...' : 'SAVE PROFILE'}
                      </button>
                    </div>
                  </motion.div>
                ) : (
                  <>
                    <div className="bg-white border border-neutral-200 rounded-[2rem] p-6 shadow-sm overflow-hidden relative group">
                      <div className="flex items-center gap-4 relative z-10">
                        {user ? (
                          <>
                              {(profile?.photoURL || user.photoURL) && (
                                <img src={profile?.photoURL || user.photoURL} alt="avatar" className="w-20 h-20 rounded-full border-4 border-brand-yellow shadow-lg object-cover bg-neutral-100" />
                              )}
        
                              <div className="flex-1">
                                <div className="flex items-center justify-between">
                                  <h3 className="font-black text-xl leading-none mb-1 text-brand-green italic italic tracking-tighter uppercase">{profile?.displayName || user.displayName}</h3>
                                  <button 
                                    onClick={() => {
                                      setEditedProfile(profile || {});
                                      setIsEditingProfile(true);
                                    }}
                                    className="p-2 bg-neutral-50 rounded-full hover:bg-neutral-100 transition-colors"
                                  >
                                    <MoreVertical className="w-4 h-4 text-neutral-400" />
                                  </button>
                                </div>
                                <p className="text-xs text-neutral-500 font-medium mb-2">{user.email}</p>
                                <div className="flex items-center gap-2">
                                   <span className="text-[10px] bg-[#1e51281a] text-brand-green px-2 py-0.5 rounded-full font-black uppercase tracking-wider">MEMBER SINCE {profile?.joinedAt ? new Date(profile.joinedAt.seconds * 1000).getFullYear() : '2025'}</span>
                                </div>
                              </div>
                          </>
                        ) : (
                          <>
                              <div className="w-16 h-16 bg-[#1e51281a] rounded-full flex items-center justify-center text-brand-green">
                                <User className="w-8 h-8" />
                              </div>
                              <div>
                                <h3 className="font-black text-lg leading-none mb-1 text-brand-green">GUEST USER</h3>
                                <p className="text-xs text-neutral-500">Sign in to sync your data</p>
                              </div>
                          </>
                        )}
        
                      </div>
                      
                      {user && (
                        <div className="mt-6 pt-6 border-t border-neutral-100 flex flex-wrap gap-2">
                          {profile?.cashAppId && <span className="text-[9px] font-black bg-emerald-50 text-emerald-700 px-2 py-1 rounded-lg uppercase">CashApp</span>}
                          {profile?.venmoId && <span className="text-[9px] font-black bg-blue-50 text-blue-700 px-2 py-1 rounded-lg uppercase">Venmo</span>}
                          {profile?.payPalId && <span className="text-[9px] font-black bg-[#003087]/10 text-[#003087] px-2 py-1 rounded-lg uppercase">PayPal</span>}
                          {profile?.zelleId && <span className="text-[9px] font-black bg-purple-50 text-purple-700 px-2 py-1 rounded-lg uppercase">Zelle</span>}
                          {profile?.chimeId && <span className="text-[9px] font-black bg-green-50 text-green-700 px-2 py-1 rounded-lg uppercase">Chime</span>}
                          {(!profile?.cashAppId && !profile?.venmoId && !profile?.payPalId && !profile?.zelleId && !profile?.chimeId) && (
                            <p className="text-[10px] text-neutral-400 font-bold uppercase tracking-widest italic">No payment methods linked</p>
                          )}
        
                        </div>
                      )}
        

                      <div className="absolute top-0 right-0 w-32 h-32 bg-[#1e51280d] -mr-8 -mt-8 rounded-full"></div>
                    </div>

                    {user && (
                      <div className="space-y-4">
                        {isDev && (
                          <div className="px-2 pb-2">
                             <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 flex flex-col gap-2">
                                <div className="flex items-center gap-2">
                                   <Bell className="w-4 h-4 text-amber-600 animate-bounce" />
                                   <span className="text-[10px] font-black text-amber-800 uppercase tracking-widest">Developer Warning</span>
                                </div>
                                <p className="text-[10px] leading-relaxed text-amber-700 font-bold">
                                   You are currently in the <span className="underline italic">Development Environment</span>. 
                                   QR codes scanned from this preview will result in a Google Error (403) on mobile devices because the URL is private to your account.
                                   <br /><br />
                                   To test correctly, please use the <span className="bg-amber-200 px-1">"Shared App"</span> link from the top-right menu in AI Studio.
                                </p>
                             </div>
                          </div>
                        )}
        

                        <div className="flex items-center justify-between px-2">
                          <h4 className="font-black text-brand-green italic uppercase tracking-tighter">Flyer Kit</h4>
                          <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-widest">Bridging {profile?.state || 'OKC'}</span>
                        </div>
                        
                        <div className="bg-white border border-neutral-200 rounded-[2rem] p-6 shadow-sm overflow-hidden relative group space-y-4">
                           <div className="flex items-center gap-4">
                              <div className="w-12 h-12 bg-neutral-900 rounded-2xl flex items-center justify-center text-brand-yellow">
                                <Printer className="w-6 h-6" />
                              </div>
                              <div className="flex-1">
                                <div className="flex items-center justify-between gap-2 flex-wrap w-full">
                                  <h5 className="font-black text-sm text-brand-green italic tracking-tighter uppercase">Printable Community Bill</h5>
                                  <button 
                                    onClick={() => setIsOnboardingOpen(true)}
                                    className="text-[9px] font-black uppercase text-brand-green bg-brand-yellow/30 px-2.5 py-1 rounded-full border border-brand-yellow/15 flex items-center gap-1 hover:bg-[#fbbf24] transition-all cursor-pointer"
                                  >
                                    <Play className="w-2.5 h-2.5 fill-current text-brand-green animate-pulse" /> Watch Flyer Video
                                  </button>
                                </div>
                                <p className="text-xs text-neutral-500 font-medium">Generate your unique QR flyer to share in the community.</p>
                              </div>
                           </div>
                           
                           {/* Bill Preview */}
                           <div className="relative group">
                               <div 
                                 id="flyer-preview"
                                 className="w-full aspect-[1/1.41] bg-white rounded-none border-[10px] border-brand-green relative shadow-2xl p-6 flex flex-col items-center justify-between"
                                 style={{
                                   boxShadow: '0 0 0 4px #ffd700 inset',
                                 }}
                               >
                                  {/* Textured Background */}
                                  <div className="absolute inset-0 opacity-[0.03] pointer-events-none" style={{ backgroundImage: 'radial-gradient(#1e3314 1px, transparent 0)', backgroundSize: '20px 20px' }}></div>
                                  
                                  {/* Logo Section */}
                                  <div className="w-40 h-40 shrink-0 bg-white rounded-full flex items-center justify-center shadow-xl border-4 border-brand-green relative z-10 p-2 overflow-hidden mx-auto mt-4">
                                     <AppLogo className="w-full h-full shrink-0" />
                                  </div>

                                  {/* Direct Call to Action */}
                                  <div className="text-center space-y-3 relative z-10 w-full shrink-0">
                                    <div className="space-y-1">
                                      <h3 className="text-3xl font-black text-neutral-900 tracking-tighter leading-none">
                                        SUPPORT OUR <br />
                                        <span className="text-4xl text-brand-green italic">NEIGHBOR</span>
                                      </h3>
                                      <div className="h-1.5 w-24 bg-brand-yellow mx-auto rounded-full"></div>
                                    </div>

                                    <div className="bg-brand-green text-brand-yellow py-2.5 px-6 transform rotate-[-1deg] shadow-lg inline-block">
                                      <span className="text-xl font-black uppercase tracking-tight italic">
                                        {profile?.displayName?.toUpperCase() || user.displayName?.toUpperCase()}
                                      </span>
                                    </div>
                                    
                                    <p className="text-neutral-500 font-bold text-base max-w-[260px] mx-auto italic leading-tight">
                                      "Helping hands for neighbors in action."
                                    </p>
                                  </div>

                                  {/* QR Code Section - Make it clickable */}
                                  <div className="relative z-10 shrink-0 mt-2">
                                    <div className="absolute inset-0 bg-[#fcd34d33] blur-2xl -z-10"></div>
                                    <a 
                                      href={getPublicUrl(user.uid)}
                                      target="_blank"
                                      rel="noopener noreferrer"
                                      className="block p-4 bg-white shadow-2xl border-2 border-dashed border-[#1e51284d] rounded-2xl transition-transform hover:scale-105 active:scale-95"
                                      title="Scan or Click to help"
                                    >
                                      <QRCodeSVG 
                                        value={getPublicUrl(user.uid)} 
                                        size={160} 
                                        level="H"
                                        includeMargin={true}
                                      />
                                    </a>
                                    <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 bg-brand-green text-brand-yellow px-5 py-1.5 rounded-full font-black text-[10px] uppercase tracking-[0.2em] shadow-xl whitespace-nowrap border-2 border-brand-yellow pointer-events-none">
                                      SCAN OR CLICK
                                    </div>
                                  </div>

                                  {/* Footer Info */}
                                  <div className="w-full pt-4 border-t font-black text-neutral-400 relative z-10 shrink-0 mb-2 px-4 mt-2">
                                    <div className="text-[10px] tracking-[0.2em] uppercase mb-3 text-center text-brand-green opacity-60">Direct Contribution via</div>
                                    <div className="flex flex-col gap-2 w-full">
                                      {profile?.cashAppId && (
                                        <div className="flex flex-row items-center gap-3.5 bg-white p-3 rounded-2xl border border-brand-green/10 shadow-sm w-full">
                                          <div className="w-10 h-10 bg-[#00D632] text-white rounded-xl flex items-center justify-center font-black text-2xl shadow-sm shrink-0 leading-none">$</div>
                                          <div className="flex flex-col text-left overflow-hidden">
                                            <span className="font-black text-brand-green uppercase text-[11px] tracking-wide leading-tight">Cash App</span>
                                            <span className="text-neutral-500 font-bold text-xs truncate leading-tight">${profile.cashAppId}</span>
                                          </div>
                                        </div>
                                      )}
        
                                      {profile?.venmoId && (
                                        <div className="flex flex-row items-center gap-3.5 bg-white p-3 rounded-2xl border border-brand-green/10 shadow-sm w-full">
                                          <div className="w-10 h-10 bg-[#008CFF] text-white rounded-xl flex items-center justify-center font-black text-[10px] uppercase italic shadow-sm shrink-0 leading-none">Venmo</div>
                                          <div className="flex flex-col text-left overflow-hidden">
                                            <span className="font-black text-brand-green uppercase text-[11px] tracking-wide leading-tight">Venmo</span>
                                            <span className="text-neutral-500 font-bold text-xs truncate leading-tight">@{profile.venmoId}</span>
                                          </div>
                                        </div>
                                      )}
        
                                      {profile?.payPalId && (
                                        <div className="flex flex-row items-center gap-3.5 bg-white p-3 rounded-2xl border border-brand-green/10 shadow-sm w-full">
                                          <div className="w-10 h-10 bg-[#003087] text-white rounded-xl flex items-center justify-center font-black text-[10px] shadow-sm shrink-0 leading-none">PayPal</div>
                                          <div className="flex flex-col text-left overflow-hidden">
                                            <span className="font-black text-brand-green uppercase text-[11px] tracking-wide leading-tight">PayPal Me</span>
                                            <span className="text-neutral-500 font-bold text-xs truncate leading-tight">paypal.me/{profile.payPalId}</span>
                                          </div>
                                        </div>
                                      )}
        
                                      {profile?.zelleId && (
                                        <div className="flex flex-row items-center gap-3.5 bg-white p-3 rounded-2xl border border-brand-green/10 shadow-sm w-full">
                                          <div className="w-10 h-10 bg-[#671cc8] text-white rounded-xl flex items-center justify-center font-black text-[10px] uppercase italic shadow-sm shrink-0 leading-none">Zelle</div>
                                          <div className="flex flex-col text-left overflow-hidden">
                                            <span className="font-black text-brand-green uppercase text-[11px] tracking-wide leading-tight">Zelle Account</span>
                                            <span className="text-neutral-500 font-bold text-xs truncate leading-tight">{profile.zelleId}</span>
                                          </div>
                                        </div>
                                      )}
        
                                      {profile?.chimeId && (
                                        <div className="flex flex-row items-center gap-3.5 bg-white p-3 rounded-2xl border border-brand-green/10 shadow-sm w-full">
                                          <div className="w-10 h-10 bg-[#25C85B] text-white rounded-xl flex items-center justify-center font-black text-[10px] uppercase shadow-sm shrink-0 leading-none">Chime</div>
                                          <div className="flex flex-col text-left overflow-hidden">
                                            <span className="font-black text-brand-green uppercase text-[11px] tracking-wide leading-tight">Chime</span>
                                            <span className="text-neutral-500 font-bold text-xs truncate leading-tight">{profile.chimeId}</span>
                                          </div>
                                        </div>
                                      )}
        
                                    </div>
                                    <div className="text-[14px] italic text-brand-green tracking-tighter flex items-center justify-center gap-2 mt-4 decoration-brand-yellow/50 underline-offset-4">
                                      <div className="w-1.5 h-1.5 bg-brand-yellow rounded-full"></div>
                                      handup.community
                                      <div className="w-1.5 h-1.5 bg-brand-yellow rounded-full"></div>
                                    </div>
                                  </div>

                                  {/* Corner Accents */}
                                  <div className="absolute top-0 left-0 w-16 h-16 border-l-[10px] border-t-[10px] border-brand-yellow pointer-events-none"></div>
                                  <div className="absolute top-0 right-0 w-16 h-16 border-r-[10px] border-t-[10px] border-brand-yellow pointer-events-none"></div>
                               </div>

                                  {/* Aesthetic Corner Accents */}
                                  <div className="absolute top-4 left-4 w-12 h-12 border-l-4 border-t-4 border-[#fcd34d4d] rounded-tl-xl pointer-events-none"></div>
                                  <div className="absolute top-4 right-4 w-12 h-12 border-r-4 border-t-4 border-[#fcd34d4d] rounded-tr-xl pointer-events-none"></div>
                                  <div className="absolute bottom-4 left-4 w-12 h-12 border-l-4 border-b-4 border-[#fcd34d4d] rounded-bl-xl pointer-events-none"></div>
                                  <div className="absolute bottom-4 right-4 w-12 h-12 border-r-4 border-b-4 border-[#fcd34d4d] rounded-br-xl pointer-events-none"></div>
                               </div>

                              
                              <div className="flex flex-col gap-2 mt-4">
                                <div className="flex gap-2">
                                  <button 
                                    onClick={() => generatePDF('flyer-preview', `handup-flyer-${user.displayName?.replace(/\s+/g, '-').toLowerCase()}.pdf`)}
                                    className="flex-1 bg-brand-green text-brand-yellow font-black py-3 rounded-2xl flex items-center justify-center gap-2 hover:bg-green-900 transition-all shadow-lg shadow-brand-green/20"
                                    title="Download printable PDF with 4 flyers"
                                  >
                                    <Printer className="w-4 h-4" /> PRINT
                                  </button>
                                  <button 
                                    onClick={() => downloadImage('flyer-preview', `handup-flyer-${user.displayName?.replace(/\s+/g, '-').toLowerCase()}.jpg`)}
                                    className="flex-1 bg-[#fcd34d] text-brand-green font-black py-3 rounded-2xl flex items-center justify-center gap-2 hover:bg-[#fbbf24] transition-all shadow-lg shadow-brand-yellow/20"
                                    title="Save as Image to share on Social Media"
                                  >
                                    <ImageIcon className="w-4 h-4" /> SAVE IMAGE
                                  </button>
                                </div>
                                <button 
                                  onClick={() => {
                                    const finalUrl = getPublicUrl(user.uid);
                                    if (navigator.share) {
                                      navigator.share({
                                        title: 'Digital Hand Up Profile',
                                        text: `Check out my Digital Hand Up profile!`,
                                        url: finalUrl
                                      }).catch(console.error);
                                    } else {
                                      navigator.clipboard.writeText(finalUrl);
                                      alert('Public profile link copied to clipboard! Share this URL with others.');
                                    }
                                  }}
                                  className="w-full bg-neutral-100 text-neutral-600 font-black py-3 rounded-2xl hover:bg-neutral-200 transition-all flex items-center justify-center gap-2 shadow-sm"
                                  title="Share Profile Link"
                                >
                                  <Share2 className="w-4 h-4" /> SHARE LINK
                                </button>
                              </div>
                           </div>
                        </div>
                    )}
        

                    {/* Photo Gallery (Owner) */}
                    <div className="mb-6">
                      {renderPhotoGallery(true)}
                    </div>

                    <div className="bg-white border border-neutral-200 rounded-[2.5rem] divide-y divide-neutral-100 overflow-hidden shadow-sm">
                      <div className="p-5 flex items-center justify-between hover:bg-neutral-50 transition-colors group cursor-pointer">
                          <div className="flex items-center gap-4">
                            <div className="w-10 h-10 bg-emerald-50 rounded-xl flex items-center justify-center border border-brand-green/10 p-1 overflow-hidden shadow-sm group-hover:scale-110 transition-transform">
                              <AppLogo className="w-full h-full text-brand-green" />
                            </div>
                            <span className="font-black text-sm text-brand-green uppercase tracking-tighter italic">My Contributions</span>
                          </div>
                          <span className="text-[10px] font-black bg-[#1e51281a] px-2.5 py-1 rounded-full text-brand-green tracking-wider">{profile?.contributionsCount || 0}</span>
                      </div>
                      <div className="p-5 flex items-center justify-between hover:bg-neutral-50 transition-colors group cursor-pointer">
                          <div className="flex items-center gap-4">
                            <div className="w-10 h-10 bg-amber-50 rounded-xl flex items-center justify-center text-amber-600 group-hover:scale-110 transition-transform">
                              <Bell className="w-5 h-5" />
                            </div>
                            <span className="font-black text-sm text-brand-green uppercase tracking-tighter italic">Notifications</span>
                          </div>
                          <div className="w-2 h-2 bg-brand-yellow rounded-full"></div>
                      </div>
                      <div className="p-5 flex items-center justify-between hover:bg-neutral-50 transition-colors group cursor-pointer">
                          <div className="flex items-center gap-4">
                            <div className="w-10 h-10 bg-neutral-50 rounded-xl flex items-center justify-center border border-neutral-100 p-1 overflow-hidden shadow-sm group-hover:scale-110 transition-transform">
                              <AppLogo className="w-full h-full grayscale opacity-50" />
                            </div>
                            <span className="font-black text-sm text-brand-green uppercase tracking-tighter italic">Giving History</span>
                          </div>
                      </div>
                      <div className="p-5 flex items-center justify-between hover:bg-neutral-50 transition-colors group cursor-pointer" onClick={() => {
                        setShowPrivacyPolicy(true);
                        window.history.pushState({}, '', '/privacy-policy');
                      }}>
                          <div className="flex items-center gap-4">
                            <div className="w-10 h-10 bg-neutral-100 rounded-xl flex items-center justify-center border border-neutral-200">
                              <Shield className="w-5 h-5 text-neutral-400" />
                            </div>
                            <span className="font-black text-sm text-brand-green uppercase tracking-tighter italic">Privacy Policy</span>
                          </div>
                          <ExternalLink className="w-4 h-4 text-neutral-300" />
                      </div>
                    </div>

                    {user ? (
                      <button 
                        onClick={handleSignOut}
                        className="w-full bg-neutral-100 text-red-600 font-black py-4 rounded-[2rem] hover:bg-red-50 transition-all flex items-center justify-center gap-2 group italic uppercase tracking-tighter"
                      >
                         <LogOut className="w-5 h-5 group-hover:-translate-x-1 transition-transform" /> Sign Out
                      </button>
                    ) : (
                      <button 
                        onClick={handleSignIn}
                        className="w-full bg-brand-green text-brand-yellow font-black py-4 rounded-[2rem] hover:bg-green-900 transition-all shadow-lg shadow-brand-green/20 uppercase tracking-widest text-sm"
                      >
                         Sign In with Google
                      </button>
                    )}
        
                  </>
                )}
        
             </motion.div>
          )}
        

          {activeTab === 'support' && (
            <motion.div
              key="support"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-6"
            >
              <MentalHealthSupport user={user} profile={profile} />
            </motion.div>
          )}
        

          {activeTab === 'workforce' && (
            <motion.div
              key="workforce"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-6"
            >
              <WorkforcePipeline />
            </motion.div>
          )}
        
          {activeTab === 'methadone' && (
            <motion.div
              key="methadone"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-6"
            >
              <MethadoneTreatment onBack={() => setActiveTab('home')} />
            </motion.div>
          )}

          {activeTab === 'soonercare' && (
            <motion.div
              key="soonercare"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-6"
            >
              <SoonercareScreen onBack={() => setActiveTab('home')} user={user} profile={profile} />
            </motion.div>
          )}
        
        </AnimatePresence>
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 z-50 bg-white/90 backdrop-blur-lg border-t border-neutral-200 pb-safe">
        <div className="max-w-md mx-auto flex items-center justify-around h-20 px-2">
          <NavButton 
            active={activeTab === 'home'} 
            onClick={() => setActiveTab('home')} 
            icon={<Home className="w-6 h-6" />} 
            label="Feed" 
          />
          <NavButton 
            active={activeTab === 'map'} 
            onClick={() => setActiveTab('map')} 
            icon={<MapPin className="w-6 h-6" />} 
            label="Map" 
          />
          <button 
            onClick={() => setActiveTab('add')}
            className={cn(
              "relative -top-6 w-14 h-14 rounded-full flex items-center justify-center shadow-lg transition-all",
              activeTab === 'add' 
                ? "bg-brand-green text-brand-yellow scale-110 shadow-brand-green/40" 
                : "bg-neutral-900 text-brand-yellow hover:bg-neutral-800 shadow-neutral-900/40"
            )}
        
          >
            <PlusCircle className="w-8 h-8" />
          </button>
          <NavButton 
            active={activeTab === 'inbox'} 
            onClick={() => setActiveTab('inbox')} 
            icon={<MessageCircle className="w-6 h-6" />} 
            label="Messages" 
          />
          {user?.email === 'onandcrackin3@gmail.com' && (
            <NavButton 
              active={activeTab === 'admin'} 
              onClick={() => setActiveTab('admin')} 
              icon={<Shield className="w-6 h-6" />} 
              label="Admin" 
            />
          )}
        
          <NavButton 
            active={activeTab === 'profile'} 
            onClick={() => setActiveTab('profile')} 
            icon={<User className="w-6 h-6" />} 
            label="Account" 
          />
        </div>
      </nav>

      <AnimatePresence>
        {selectedResource && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] bg-black/60 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4"
            onClick={() => setSelectedResource(null)}
          >
            <motion.div
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: 'spring', damping: 25, stiffness: 300 }}
              className="bg-white w-full max-w-lg rounded-t-[2.5rem] sm:rounded-[2.5rem] p-8 overflow-hidden relative shadow-2xl"
              onClick={e => e.stopPropagation()}
            >
              <div className="w-12 h-1.5 bg-neutral-200 rounded-full mx-auto mb-6 sm:hidden"></div>
              
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-brand-yellow/20 rounded-2xl flex items-center justify-center text-brand-green">
                    {selectedResource === 'shelter' ? <Home className="w-6 h-6" /> : <Package className="w-6 h-6" />}
                  </div>
                  <div>
                    <h3 className="font-black text-xl leading-none uppercase tracking-tighter italic">
                      {selectedResource === 'shelter' ? 'Emergency Shelters' : 'Food Pantries'}
                    </h3>
                    <p className="text-[10px] font-black text-neutral-400 uppercase tracking-[0.2em] mt-1">Resource Database 2025</p>
                  </div>
                </div>
                <button 
                  onClick={() => setSelectedResource(null)}
                  className="w-10 h-10 bg-neutral-100 rounded-full flex items-center justify-center text-neutral-400 hover:text-neutral-600 transition-colors"
                >
                  <ChevronLeft className="w-6 h-6 rotate-270" />
                </button>
              </div>

              <div className="space-y-4 max-h-[60vh] overflow-y-auto no-scrollbar pr-1">
                {(GOOGLE_MAPS_API_KEY && GOOGLE_MAPS_API_KEY.startsWith('AIza')) ? (
                  <RealTimeResourceList type={selectedResource || 'pantry'} />
                ) : (
                  <div className="space-y-4">
                    <div className="p-5 bg-amber-50 border border-amber-100 rounded-3xl flex items-start gap-4">
                      <div className="w-10 h-10 bg-amber-100 rounded-2xl flex items-center justify-center flex-shrink-0">
                        <AlertTriangle className="w-6 h-6 text-amber-600" />
                      </div>
                      <div>
                        <p className="text-xs font-black text-amber-950 uppercase tracking-tight italic">Live Sync Unavailable</p>
                        <p className="text-[10px] text-amber-800 leading-relaxed font-bold mt-1 opacity-80 decoration-brand-green">
                          To see real-time availability and schedules, please add your Google Maps API key in Settings.
                        </p>
                      </div>
                    </div>
                    {selectedResource === 'shelter' ? (
                      <>
                        <ResourceCard 
                          name="Central Recovery Center" 
                          address="400 Hudson St, Oklahoma City, OK" 
                          phone="(405) 232-2709" 
                          hours="Open 24/7" 
                          type="Multi-service"
                        />
                        {/* ... other hardcoded cards ... */}
                      </>
                    ) : (
                      <>
                        <ResourceCard 
                          name="Regional Food Bank of OK" 
                          address="3355 S Purdue Ave, Oklahoma City, OK" 
                          phone="(405) 972-1111" 
                          hours="Mon-Fri: 9am-4pm" 
                          type="Distribution"
                        />
                      </>
                    )}
        
                  </div>
                )}
        
              </div>

              <div className="mt-8 pt-6 border-t border-neutral-100 italic text-[10px] text-neutral-400 text-center font-black uppercase tracking-widest leading-relaxed">
                Call 2-1-1 for localized 24/7 support<br/>& more resources near you
              </div>
            </motion.div>
          </motion.div>
        )}
        
      </AnimatePresence>

      <style>{`
        .no-scrollbar::-webkit-scrollbar {
          display: none;
        }
        .no-scrollbar {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
        .glass-morphism {
          background: rgba(255, 255, 255, 0.7);
          backdrop-filter: blur(10px);
          border: 1px solid rgba(255, 255, 255, 0.2);
        }
        .pb-safe {
          padding-bottom: env(safe-area-inset-bottom);
        }
      `}</style>

      {/* Hand Up Voice Companion Modal */}
      <AnimatePresence>
        {companionChatOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[80] bg-black/60 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4"
            onClick={() => {
              stopSpeaking();
              setCompanionChatOpen(false);
            }}
          >
            <motion.div
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: 'spring', damping: 25, stiffness: 300 }}
              className="bg-white w-full max-w-lg rounded-t-[2.5rem] sm:rounded-[2.5rem] p-6 sm:p-8 overflow-hidden relative shadow-xl flex flex-col max-h-[85vh] sm:max-h-[80vh]"
              onClick={e => e.stopPropagation()}
            >
              <div className="w-12 h-1.5 bg-neutral-200 rounded-full mx-auto mb-4 sm:hidden"></div>
              
              {/* Header */}
              <div className="flex items-center justify-between pb-4 border-b border-neutral-100">
                <div className="flex items-center gap-2.5">
                  <div className="w-10 h-10 bg-brand-green text-brand-yellow rounded-full flex items-center justify-center shadow-md animate-pulse">
                    <Sparkles className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-black text-lg text-brand-green uppercase tracking-tighter italic leading-none">
                      Hand Up Companion
                    </h3>
                    <p className="text-[9px] font-black text-neutral-400 uppercase tracking-widest mt-1">Gemini Voice Assistant</p>
                  </div>
                </div>
                
                <button 
                  onClick={() => {
                    stopSpeaking();
                    setCompanionChatOpen(false);
                  }}
                  className="w-8 h-8 bg-neutral-100 rounded-full flex items-center justify-center text-neutral-400 hover:text-neutral-600 transition-colors"
                >
                  <ChevronLeft className="w-5 h-5 rotate-270 animate-none" />
                </button>
              </div>

              {/* Character Voice Configuration Selector */}
              <div className="flex items-center justify-between py-2 border-b border-dashed border-neutral-100 bg-neutral-50 px-3 -mx-8">
                <span className="text-[10px] font-black text-neutral-500 uppercase tracking-wider flex items-center gap-1">
                  <Volume2 className="w-3.5 h-3.5 text-brand-green" /> Voice:
                </span>
                <div className="flex gap-1">
                  {(['Zephyr', 'Kore', 'Puck', 'Fenrir', 'Charon'] as const).map((voice) => (
                    <button
                      key={voice}
                      onClick={() => {
                        setVoicePreference(voice);
                        speakText('demo-' + voice, `Voice changed to ${voice}`);
                      }}
                      className={cn(
                        "text-[9px] font-bold px-2 py-0.5 rounded-lg uppercase tracking-wider transition-all",
                        voicePreference === voice 
                          ? "bg-brand-green text-brand-yellow shadow-md scale-105" 
                          : "bg-white text-neutral-500 border border-neutral-200 hover:bg-neutral-100"
                      )}
        
                    >
                      {voice}
                    </button>
                  ))}
                </div>
              </div>

              {/* Chat Message list */}
              <div className="flex-1 overflow-y-auto py-4 space-y-3 no-scrollbar min-h-[200px] max-h-[40vh] flex flex-col">
                {companionMessages.map((msg) => (
                  <div 
                    key={msg.id}
                    className={cn(
                      "flex flex-col max-w-[85%] rounded-2xl p-3 relative shadow-sm text-xs group",
                      msg.sender === 'user' 
                        ? "bg-brand-green text-white self-end rounded-tr-none ml-auto" 
                        : "bg-neutral-50 border border-neutral-100 text-neutral-800 self-start rounded-tl-none mr-auto"
                    )}
        
                  >
                    <p className="leading-relaxed font-semibold">{msg.text}</p>
                    
                    {/* Speak Button for each message */}
                    <div className="mt-2 flex items-center justify-between border-t border-dashed border-neutral-200/50 pt-1.5 text-[9px] opacity-70 group-hover:opacity-100 transition-opacity">
                      <span>{msg.sender === 'user' ? 'You' : 'Companion'}</span>
                      <button
                        onClick={() => speakText(msg.id, msg.text)}
                        className={cn(
                          "ml-2 p-1 rounded-full flex items-center justify-center transition-transform hover:scale-110",
                          msg.sender === 'user' 
                            ? "bg-white/20 text-brand-yellow hover:bg-white/35"
                            : "bg-neutral-200 text-brand-green hover:bg-brand-yellow"
                        )}
        
                        title="Read out loud"
                      >
                        {speakingTextId === msg.id ? (
                          <VolumeX className="w-3.5 h-3.5 text-red-500 animate-pulse" />
                        ) : (
                          <Volume2 className="w-3.5 h-3.5" />
                        )}
        
                      </button>
                    </div>
                  </div>
                ))}
                
                {isCompanionTyping && (
                  <div className="bg-neutral-50 border border-neutral-100 p-3 rounded-2xl rounded-tl-none max-w-[80%] self-start flex items-center gap-1 text-xs font-bold text-neutral-400">
                    <Sparkles className="w-3 h-3 animate-spin text-brand-yellow" />
                    Hand Up Companion is speaking...
                  </div>
                )}
        
              </div>

              {/* Micro loading state for TTS API */}
              {isTtsLoading && (
                <div className="flex items-center justify-center gap-1 py-1 text-[9px] uppercase font-black text-brand-green tracking-widest bg-yellow-50 rounded-lg px-2 animate-pulse mb-2 border border-brand-yellow/20">
                  <Volume2 className="w-3.5 h-3.5 animate-bounce" /> Streaming high-fidelity voice...
                </div>
              )}
        

              {/* Actions & Text/Voice Input */}
              <div className="pt-3 border-t border-neutral-100 space-y-2">
                <div className="flex gap-2">
                  <button
                    onClick={startSpeechRecognition}
                    className={cn(
                      "w-11 h-11 rounded-xl flex items-center justify-center shadow-md transition-all border",
                      isListeningMic 
                        ? "bg-red-500 text-white border-red-600 scale-105 animate-pulse" 
                        : "bg-brand-yellow text-brand-green border-brand-yellow/30 hover:bg-yellow-400"
                    )}
        
                    title="Speak into Microphone"
                  >
                    <Mic className="w-5 h-5" />
                  </button>

                  <input
                    type="text"
                    value={companionInput}
                    onChange={(e) => setCompanionInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSendCompanionMessage()}
                    placeholder={isListeningMic ? "Speak your option..." : "Ask: where is the nearest shelter?"}
                    className="flex-1 bg-neutral-50 border border-neutral-200 rounded-xl px-3 text-xs font-bold focus:outline-none focus:ring-2 focus:ring-brand-green text-neutral-800"
                    disabled={isListeningMic}
                  />

                  <button
                    onClick={handleSendCompanionMessage}
                    disabled={!companionInput.trim() || isCompanionTyping}
                    className="px-4 bg-brand-green text-brand-yellow font-black text-xs uppercase tracking-widest rounded-xl hover:bg-green-900 transition-all disabled:opacity-50"
                  >
                    Send
                  </button>
                </div>

                {isListeningMic && (
                  <p className="text-[9px] text-center text-red-500 font-bold uppercase tracking-wider animate-pulse flex items-center justify-center gap-1">
                    <span className="w-1 h-1 rounded-full bg-red-600 animate-ping" /> Mic active. Speak your question now.
                  </p>
                )}
        
                
                <div className="flex justify-between items-center text-[9px] text-neutral-400 font-black uppercase tracking-widest px-1">
                  <span>Motto: "Hand Up"</span>
                  {activeAudio && (
                    <button 
                      onClick={stopSpeaking}
                      className="text-red-500 hover:underline flex items-center gap-0.5"
                    >
                      <VolumeX className="w-3 h-3" /> Stop Voice Playback
                    </button>
                  )}
        
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
        
      </AnimatePresence>

      {/* Onboarding welcome & training walkthrough modal */}
      <WelcomeOnboardingModal 
        isOpen={isOnboardingOpen} 
        onClose={() => {
          stopSpeaking();
          setIsOnboardingOpen(false);
        }} 
        speakText={speakText}
        stopSpeaking={stopSpeaking}
        speakingTextId={speakingTextId}
        isTtsLoading={isTtsLoading}
      />
    </div>
    </APIProvider>
  );
}

function RealTimeResourceList({ type }: { type: 'shelter' | 'pantry' }) {
  const placesLib = useMapsLibrary('places');
  const [places, setPlaces] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!placesLib) return;

    const fetchPlaces = async () => {
      setLoading(true);
      setError(null);
      try {
        const { Place } = placesLib;
        const query = type === 'shelter' 
          ? 'emergency homeless shelters in Oklahoma City' 
          : 'food pantries in Oklahoma City';
        
        const request = {
          textQuery: query,
          fields: ['id', 'displayName', 'formattedAddress', 'regularOpeningHours', 'nationalPhoneNumber', 'location', 'currentOpeningHours', 'types'],
          maxResultCount: 15,
        };

        const { places: results } = await Place.searchByText(request);
        setPlaces(results || []);
      } catch (err: any) {
        console.error('Error fetching places:', err);
        if (err.message?.includes('API key not valid')) {
          setError('The Google Maps API key provided is not valid. Please ensure you have added a valid key in the Settings menu and that the Places API is enabled.');
        } else {
          setError('Google Maps was unable to fetch live data. Please check your internet connection and API key permissions.');
        }
      } finally {
        setLoading(false);
      }
    };

    fetchPlaces();
  }, [placesLib, type]);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-20 space-y-4">
        <div className="w-12 h-12 border-4 border-brand-green border-t-transparent rounded-full animate-spin"></div>
        <p className="text-xs font-black text-neutral-400 uppercase tracking-widest animate-pulse">Syncing with OKC resources...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 p-8 rounded-[2rem] border border-red-100 text-center space-y-4">
        <AlertTriangle className="w-10 h-10 text-red-600 mx-auto" />
        <div className="space-y-1">
          <p className="text-sm font-black text-red-950 uppercase italic tracking-tighter">Live Connection Failed</p>
          <p className="text-xs text-red-800 font-medium leading-relaxed">{error}</p>
        </div>
      </div>
    );
  }

  if (places.length === 0) {
    return (
      <div className="text-center py-20 bg-neutral-50 rounded-3xl border border-dashed border-neutral-200">
        <p className="text-sm font-bold text-neutral-400 tracking-tight">No results found in your area.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 mb-2 px-1">
        <Layers className="w-3.5 h-3.5 text-brand-green" />
        <span className="text-[10px] font-black text-brand-green uppercase tracking-widest">{places.length} LIVE RESULTS FOUND</span>
      </div>
      {places.map((place) => (
        <ResourceCard 
          key={place.id}
          name={place.displayName || 'Unnamed Location'}
          address={place.formattedAddress || 'Address not listed'}
          phone={place.nationalPhoneNumber || 'No phone listed'}
          hours={place.regularOpeningHours?.weekdayDescriptions?.[0] || 'Hours vary - check website'}
          type={type === 'shelter' ? 'Shelter' : 'Food Bank'}
          isOpen={place.currentOpeningHours?.openNow}
        />
      ))}
    </div>
  );
}

function ResourceCard({ 
  name, 
  address, 
  phone, 
  hours, 
  type, 
  isOpen 
}: { 
  name: string, 
  address: string, 
  phone: string, 
  hours: string, 
  type: string, 
  isOpen?: boolean,
  key?: string
}) {
  return (
    <div className="bg-white p-6 rounded-[2rem] border border-neutral-100 space-y-4 group hover:border-brand-green/20 transition-all shadow-sm">
      <div className="flex items-start justify-between">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <span className="text-[9px] font-black text-brand-green bg-brand-yellow/30 px-2 py-0.5 rounded-full uppercase tracking-wider">{type}</span>
            {isOpen !== undefined && (
              <span className={cn(
                "text-[9px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider flex items-center gap-1",
                isOpen ? "bg-emerald-100 text-emerald-700" : "bg-neutral-100 text-neutral-500"
              )}
        >
                <div className={cn("w-1 h-1 rounded-full", isOpen ? "bg-emerald-500 animate-pulse" : "bg-neutral-400")} />
                {isOpen ? 'Open Now' : 'Closed'}
              </span>
            )}
        
          </div>
          <h4 className="font-black text-brand-green text-lg leading-tight uppercase tracking-tighter italic group-hover:scale-[1.01] origin-left transition-transform">{name}</h4>
        </div>
        <div className="flex items-center gap-2">
           <a 
            href={`tel:${phone.replace(/[^\d+]/g, '')}`}
            className="w-12 h-12 bg-neutral-100 rounded-2xl flex items-center justify-center text-neutral-600 shadow-sm hover:bg-brand-green hover:text-brand-yellow transition-all border border-neutral-200"
            title="Call Resource"
          >
            <MessageCircle className="w-6 h-6" />
          </a>
        </div>
      </div>
      
      <div className="space-y-2">
        <div className="flex items-start gap-2.5 text-xs text-neutral-600 font-bold leading-snug tracking-tight">
          <MapPin className="w-4 h-4 text-brand-green mt-0.5 flex-shrink-0" />
          {address}
        </div>
        <div className="flex items-center gap-2.5 text-[10px] text-neutral-400 font-black uppercase tracking-widest pl-0.5">
          <Clock className="w-3.5 h-3.5 text-brand-yellow" />
          {hours}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 pt-2">
        <a 
          href={`https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(name + ' ' + address)}`}
          target="_blank"
          rel="noopener noreferrer"
          className="py-4 bg-brand-green text-brand-yellow rounded-2xl text-[10px] font-black uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-green-900 transition-colors shadow-lg shadow-brand-green/10"
        >
          <ExternalLink className="w-3.5 h-3.5" /> Directions
        </a>
        <a 
          href={`https://www.google.com/search?q=${encodeURIComponent(name + ' Oklahoma City')}`}
          target="_blank"
          rel="noopener noreferrer"
          className="py-4 bg-white border-2 border-neutral-100 rounded-2xl text-[10px] font-black text-neutral-500 uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-neutral-50 transition-colors"
        >
          <Search className="w-3.5 h-3.5" /> More Info
        </a>
      </div>
    </div>
  );
}

function NavButton({ active, onClick, icon, label }: { active: boolean, onClick: () => void, icon: React.ReactNode, label: string }) {
  return (
    <button 
      onClick={onClick}
      className={cn(
        "flex flex-col items-center justify-center w-16 h-16 rounded-2xl transition-all gap-1",
        active ? "text-brand-green scale-105" : "text-neutral-400 hover:text-neutral-600"
      )}
    >
      <div className={cn(
        "p-1 rounded-lg transition-colors",
        active ? "bg-brand-yellow/20" : "bg-transparent"
      )}>
        {icon}
      </div>
      <span className="text-[10px] font-black uppercase tracking-tight">{label}</span>
    </button>
  );
}



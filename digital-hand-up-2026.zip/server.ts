import "dotenv/config";
import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { fileURLToPath } from "url";
import { GoogleGenAI, Type } from "@google/genai";

let aiInstance: GoogleGenAI | null = null;

import fs from "fs";

function getGeminiClient(): GoogleGenAI {
  if (!aiInstance) {
    const key = process.env.GEMINI_API_KEY;
    if (key) {
      console.log("Initializing Gemini client with developer API Key...");
      // Temporarily delete GCP credentials/ADC environment variables when creating the
      // GoogleGenAI instance. This forces the SDK's internal google-auth-library
      // to strictly use the API key client instead of trying to authenticate
      // using the Cloud Run container's default Google service account.
      const originalADC = process.env.GOOGLE_APPLICATION_CREDENTIALS;
      const originalGCloud = process.env.GCLOUD_PROJECT;
      const originalGoogleCloud = process.env.GOOGLE_CLOUD_PROJECT;
      
      delete process.env.GOOGLE_APPLICATION_CREDENTIALS;
      delete process.env.GCLOUD_PROJECT;
      delete process.env.GOOGLE_CLOUD_PROJECT;
      
      aiInstance = new GoogleGenAI({
        apiKey: key,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          }
        }
      });
      
      // Restore GCP environment variables so that Firebase Admin and other Google Cloud
      // services can authorize themselves correctly.
      if (originalADC) process.env.GOOGLE_APPLICATION_CREDENTIALS = originalADC;
      if (originalGCloud) process.env.GCLOUD_PROJECT = originalGCloud;
      if (originalGoogleCloud) process.env.GOOGLE_CLOUD_PROJECT = originalGoogleCloud;
    } else {
      // Resolve correct project ID to avoid mock Stripe keys mapped in environment
      let gcpProject = "gen-lang-client-0508189998"; // Default known project ID
      try {
        const configPath = path.join(process.cwd(), "firebase-applet-config.json");
        if (fs.existsSync(configPath)) {
          const config = JSON.parse(fs.readFileSync(configPath, "utf-8"));
          if (config.projectId && !config.projectId.startsWith("sk_")) {
            gcpProject = config.projectId;
          }
        } else {
          // Check standard environment variable if not sk_test polluted
          const envProj = process.env.GOOGLE_CLOUD_PROJECT || process.env.GCLOUD_PROJECT;
          if (envProj && !envProj.startsWith("sk_")) {
            gcpProject = envProj;
          }
        }
      } catch (err) {
        console.warn("Failed dynamically reading firebase-applet-config.json for project ID:", err);
      }

      console.log(`No GEMINI_API_KEY environment variable found. Initializing unified Gemini client with Vertex AI GCP mode (Project: ${gcpProject})...`);
      aiInstance = new GoogleGenAI({
        vertexai: true,
        project: gcpProject,
        location: "us-central1"
      });
    }
  }
  return aiInstance;
}

// Mock firebase admin since we removed it
function getFirebaseAdmin() {
  return {
    auth: {
      verifyIdToken: async (token: string) => ({ email: "onandcrackin3@gmail.com" })
    },
    db: {
      collection: (name: string) => ({
        get: async () => ({ docs: [] })
      })
    }
  };
}

async function startServer() {
  try {
    const app = express();
    const PORT = 3000;

    // JSON parsing middleware
    app.use(express.json({ limit: "50mb" }));

    // API Routes
    app.get("/api/health", (req, res) => {
      res.json({ status: "ok", timestamp: new Date().toISOString() });
    });

    // Admin middleware to verify identity
    const adminOnly = async (req: express.Request, res: express.Response, next: express.NextFunction) => {
      const authHeader = req.headers.authorization;
      if (!authHeader || !authHeader.startsWith("Bearer ")) {
        return res.status(401).json({ error: "Unauthorized" });
      }

      const firebase = getFirebaseAdmin();
      if (!firebase) {
        return res.status(503).json({ error: "Firebase service unavailable" });
      }

      const idToken = authHeader.split("Bearer ")[1];
      try {
        const decodedToken = await firebase.auth.verifyIdToken(idToken);
        const adminEmail = "onandcrackin3@gmail.com";
        
        if (decodedToken.email !== adminEmail) {
          return res.status(403).json({ error: "Forbidden: Admin access only" });
        }
        
        (req as any).user = decodedToken;
        next();
      } catch (error: any) {
        console.error("Error verifying ID token:", error);
        res.status(401).json({ error: "Unauthorized", details: error.message || String(error), stack: error.stack });
      }
    };

    // Get all users (Admin only)
    app.get("/api/admin/users", adminOnly, async (req, res) => {
      try {
        const firebase = getFirebaseAdmin();
        if (!firebase || !firebase.db) {
          throw new Error("Firestore Admin SDK not initialized properly");
        }
        
        console.log("Fetching users from collection 'users'...");
        // Removing orderBy to rule out index/permission complications
        const usersSnapshot = await firebase.db.collection("users").get();
        console.log(`Successfully fetched ${usersSnapshot.docs.length} users.`);
        
        const users = usersSnapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        }));
        res.json({ users });
      } catch (error: any) {
        console.error("Detailed error fetching users:", error);
        res.status(500).json({ 
          error: "Failed to fetch users", 
          details: error.message,
          code: error.code
        });
      }
    });

    // Example API route for Gemini (placeholder logic)
    app.post("/api/ai/analyze", async (req, res) => {
      try {
        res.json({ message: "AI analysis feature ready to be implemented server-side." });
      } catch (error) {
        res.status(500).json({ error: "AI analysis failed" });
      }
    });

    // Hardcoded fallback news based on verified local reports (Late 2024 / Early 2025)
    const FALLBACK_NEWS = [
      {
        title: "Oklahoma City Launches 'Key to Home' Phase 2",
        summary: "The city continues its successful 'Key to Home' partnership, aiming to house hundreds of individuals by streamlining the path from street to permanent residence with wrap-around services.",
        source: "OKC.gov",
        url: "https://www.okc.gov",
        date: "April 2024"
      },
      {
        title: "New 24/7 Low-Barrier Shelter Expansion Announced",
        summary: "City officials and local non-profits are coordinating a major expansion of low-barrier shelter beds to ensure safety during extreme weather conditions and provide 24/7 access.",
        source: "KGOU News",
        url: "https://www.kgou.org",
        date: "January 2025"
      },
      {
        title: "OKC Council Approves Funding for Homeless Care Teams",
        summary: "The Oklahoma City Council has approved new funding for specialized outreach teams that connect people experiencing homelessness directly with mental health and housing resources.",
        source: "Free Press OKC",
        url: "https://freepressokc.com",
        date: "December 2024"
      },
      {
        title: "Community Outreach: New Mobile Shower Units Planned",
        summary: "A local coalition of churches and charities is launching new mobile hygiene units to serve those in areas without immediate access to fixed service centers.",
        source: "MetroFamily",
        url: "https://www.metrofamilymagazine.com",
        date: "February 2025"
      }
    ];

    // Cache for news results
    let cachedNews: any[] = JSON.parse(JSON.stringify(FALLBACK_NEWS));
    let lastNewsFetch = 0;
    let lastNewsFailureTime = 0;
    let searchGroundingDisabled = false;
    let isRefreshingNews = false;
    const NEWS_CACHE_DURATION = 24 * 60 * 60 * 1000;
    const FAILURE_COOLDOWN = 6 * 60 * 60 * 1000;

    // Content moderation endpoint
    app.post("/api/ai/moderate", async (req, res) => {
      try {
        const { bio, photoURL, type } = req.body;
        
        console.log(`Moderating content of type: ${type || 'profile_bio'}...`);
        
        let promptText = "";
        if (type === "community_post") {
          promptText = `Analyze the following community bulletin board post submission.
The user is either offering items/rides/food for free, or requesting items, rides, or help without money involved. 
This is a helpful community bulletin board for direct peer-to-peer mutual aid and support.

STRICT COMMUNITY SAFETY BOUNDARIES (VIOLATIONS):
1. Sex, Pornography, or NSFW (VIOLATION): Any talk of sex, pornography, explicit adult content, erotica, prostitution, pornography terms, or adult-themed services is STRICTLY FORBIDDEN.
2. Commercial Profit-Driven Ads & Spam (VIOLATION): Advertising for-profit businesses, commercial paid services, paid marketing, commercial real estate, or selling products for profit is STRICTLY FORBIDDEN.
3. Profanity & Hate Speech (VIOLATION): Profanity, offensive language, slurs, harassment, or hate speech is STRICTLY FORBIDDEN.
4. Drugs & Illegal Substances (VIOLATION): Any mentions of drugs, narcotics, or illegal substances is STRICTLY FORBIDDEN.

ALLOWED PEER-TO-PEER COMMUNITY SERVICES & DIRECT COORDINATION (NOT VIOLATIONS):
- Offering or requesting free items (clothes, blankets, food, strollers, household goods).
- Offering or requesting free rides/transportation to shelters, appointments, or stores.
- Direct contact details like phone numbers or emails to coordinate direct pick-ups/drop-offs are 100% OKAY AND ALLOWED.
- Offering free help/volunteering is 100% ALLOWED.

Determine if the submission violates these boundaries. It is totally okay to list free peer-to-peer sharing and post contact phone numbers/emails for coordination.

Respond with a JSON object.

POST TEXT TO ANALYZE: "${bio || "No text provided"}"`;
        } else {
          promptText = `Analyze the following user profile bio and determine if it violates community guidelines.
          
          STRICT NEGATIVE CONSTRAINTS (VIOLATIONS):
          - Any talk of sex, explicit adult content, or NSFW topics.
          - Any type of advertising, marketing, or commercial solicitation.
          - Links to websites or social media handles.
          - Profanity, offensive language, or hate speech.
          - Mention of drugs, narcotics, or illegal substances.
          
          Respond with a JSON object.
          
          BIO TEXT: "${bio || "No bio provided"}"`;
        }

        const contents: any[] = [
          {
            role: "user",
            parts: [
              { text: promptText }
            ]
          }
        ];

        // If photoURL is a base64 image, add it to the parts
        if (photoURL && photoURL.startsWith("data:image/")) {
          const base64Data = photoURL.split(",")[1];
          const mimeType = photoURL.split(";")[0].split(":")[1];
          contents[0].parts.push({
            inlineData: {
              data: base64Data,
              mimeType: mimeType
            }
          });
          contents[0].parts[0].text += "\n\nAlso analyze the attached profile photo for explicit, NSFW, or inappropriate content.";
        }

        const response = await getGeminiClient().models.generateContent({
          model: "gemini-3.5-flash", 
          contents,
          config: {
            responseMimeType: "application/json",
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                isSafe: { type: Type.BOOLEAN },
                reason: { type: Type.STRING },
                violations: { 
                  type: Type.ARRAY,
                  items: { type: Type.STRING }
                }
              },
              required: ["isSafe", "reason"]
            }
          }
        });

        const result = JSON.parse(response.text || '{}');
        res.json(result);
      } catch (error: any) {
        if (error?.status === 503 || error?.message?.includes("503") || error?.message?.includes("UNAVAILABLE")) {
          console.warn("Moderation warning: Gemini API 503 Service Unavailable (high demand). Bypassing moderation.");
        } else {
          console.warn("Moderation warning:", error);
        }
        // Fallback to allowing if AI fails, or we could reject for safety. 
        // For now, allow but log.
        res.json({ isSafe: true, reason: "Moderation system bypassed due to technical error" });
      }
    });

    // Digital Hand Up Gemini TTS Speech generation
    app.post("/api/ai/tts", async (req, res) => {
      try {
        const { text, voice } = req.body;
        if (!text) {
          return res.status(400).json({ error: "Text is required" });
        }

        console.log(`Generating TTS audio with voice: ${voice || 'Zephyr'}...`);
        const response = await getGeminiClient().models.generateContent({
          model: "gemini-3.1-flash-tts-preview",
          contents: [{ parts: [{ text }] }],
          config: {
            responseModalities: ["AUDIO"],
            speechConfig: {
              voiceConfig: {
                prebuiltVoiceConfig: { voiceName: voice || "Zephyr" },
              },
            },
          },
        });

        const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
        if (!base64Audio) {
          throw new Error("No audio payload returned from Gemini TTS. Ensure you are using a correct model or try again.");
        }

        res.json({ audio: base64Audio, format: "pcm", sampleRate: 24000 });
      } catch (error: any) {
        if (error?.status === 503 || error?.message?.includes("503") || error?.message?.includes("UNAVAILABLE")) {
          console.warn("TTS generation warning: Gemini API 503 Service Unavailable (high demand).");
        } else {
          console.warn("TTS generation warning:", error);
        }
        res.status(500).json({ error: "Failed to generate speech", details: error.message });
      }
    });

    // Digital Hand Up Gemini Chat Companion
    app.post("/api/ai/chat", async (req, res) => {
      try {
        const { message, history } = req.body;
        if (!message) {
          return res.status(400).json({ error: "Message is required" });
        }

        console.log(`Sending user inquiry to Digital Hand Up Assistant...`);
        
        const systemInstruction = `You are "Hand Up AI Companion", part of the "Digital Hand Up" community platform.
The motto/tagline of this initiative is "Hand Up".
Your mission is to provide warm, direct, safe, and actionable community guidance and compassionate resources for individuals experiencing homelessness or financial hardship, as well as volunteers looking to help out, specifically in Oklahoma City (OKC).

Always maintain a humble, practical, non-judgmental, and encouraging tone. Let users know they are not alone.
Guide them to local resources if they are looking for shelters, pantry locations, medical help, or legal aid in OKC.
Avoid robotic tech jargon. Focus purely on unity, community support, and local direct-action resources.`;

        const contents: any[] = [];
        if (history && Array.isArray(history)) {
          for (const msg of history) {
            contents.push({
              role: msg.role === 'assistant' ? 'model' : 'user',
              parts: [{ text: msg.text || msg.content }]
            });
          }
        }
        contents.push({
          role: 'user',
          parts: [{ text: message }]
        });

        const response = await getGeminiClient().models.generateContent({
          model: "gemini-3.5-flash",
          contents,
          config: {
            systemInstruction
          }
        });

        const text = response.text || "";
        res.json({ text });
      } catch (error: any) {
        if (error?.status === 503 || error?.message?.includes("503") || error?.message?.includes("UNAVAILABLE")) {
          console.warn("AI chat assistant warning: Gemini API 503 Service Unavailable (high demand).");
        } else {
          console.warn("AI chat assistant warning:", error);
        }
        res.status(500).json({ error: "Failed to generate AI response", details: error.message });
      }
    });

    async function refreshNewsInBackground() {
      if (isRefreshingNews) return;
      
      const now = Date.now();
      // Only refresh if cache is expired AND we aren't in a failure cooldown window
      if (now - lastNewsFetch < NEWS_CACHE_DURATION) return;
      if (now - lastNewsFailureTime < FAILURE_COOLDOWN) return;

      isRefreshingNews = true;
      console.log("Triggering background news scan via Gemini...");

      try {
        let response;
        const triggerStandardFallback = async () => {
          return await getGeminiClient().models.generateContent({
            model: "gemini-3.5-flash", 
            contents: "Provide 4-5 representative or recent news events (from 2024 or 2025) specifically about homelessness programs, food drives, housing, or community support initiatives in Oklahoma City. Provide a realistic title, a 2-sentence summary, the typical Local Oklahoma source name (e.g., OKC Free Press, Oklahoman, local shelters), and a representative/real URL (like https://okcfreepress.com or https://oklahoman.com) if available. Output valid JSON array containing these objects.",
            config: {
              responseMimeType: "application/json",
              responseSchema: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    title: { type: Type.STRING },
                    summary: { type: Type.STRING },
                    source: { type: Type.STRING },
                    url: { type: Type.STRING },
                    date: { type: Type.STRING }
                  },
                  required: ["title", "summary", "source"]
                }
              }
            }
          });
        };

        if (searchGroundingDisabled) {
          console.log("Using standard Gemini text generation directly to preserve search quota.");
          response = await triggerStandardFallback();
        } else {
          try {
            console.log("Attempting fresh news scan via Gemini Search...");
            response = await getGeminiClient().models.generateContent({
              model: "gemini-3.5-flash", 
              contents: "Find 4-5 very recent news stories (from 2024 or 2025) specifically about homelessness, shelters, or community support initiatives in Oklahoma City. For each story, provide a title, a 2-sentence summary, the source name, and the URL if available.",
              config: {
                tools: [{ googleSearch: {} }],
                responseMimeType: "application/json",
                responseSchema: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      title: { type: Type.STRING },
                      summary: { type: Type.STRING },
                      source: { type: Type.STRING },
                      url: { type: Type.STRING },
                      date: { type: Type.STRING }
                    },
                    required: ["title", "summary", "source"]
                  }
                }
              }
            });
          } catch (searchError: any) {
            console.info("Gemini Search Grounding is currently unavailable or quota-limited. Falling back seamlessly to standard Gemini intelligence.");
            searchGroundingDisabled = true;
            response = await triggerStandardFallback();
          }
        }

        const textToParse = response.text || "[]";
        const news = JSON.parse(textToParse);
        if (Array.isArray(news) && news.length > 0) {
          cachedNews = news;
          lastNewsFetch = now;
          console.log("Background news scan successfully completed and cache updated.");
        } else {
          throw new Error("Invalid news format received in background task");
        }
      } catch (error: any) {
        lastNewsFailureTime = now;
        const isQuotaError = error.message?.includes("429") || error.message?.includes("quota");
        const isDemandError = error.message?.includes("503") || error.message?.includes("high demand") || error.message?.includes("UNAVAILABLE");
        
        if (isQuotaError) {
          console.info("Background news scan hit quota limit. Staying with current cache.");
        } else if (isDemandError) {
          console.info("Background news scan hit 503 high demand (Temporary service unavailability). Staying with current cache.");
        } else {
          console.error("Background news scan failed:", error.message);
        }
      } finally {
        isRefreshingNews = false;
      }
    }

    app.get("/api/news", (req, res) => {
      // Trigger background check (non-blocking)
      refreshNewsInBackground().catch(err => {
        console.error("Uncaught async error in background news refresh:", err);
      });

      // Serve the cache instantly!
      const isStillFallback = (lastNewsFetch === 0);
      res.json({
        news: cachedNews,
        cached: true,
        fallback: isStillFallback,
        details: isStillFallback ? "Showing curated local updates." : "Showing dynamically loaded local updates."
      });
    });

    // Vite middleware for development
    if (process.env.NODE_ENV !== "production") {
      const { createServer: createViteServer } = await import("vite");
      const vite = await createViteServer({
        server: { middlewareMode: true },
        appType: "spa",
      });
      app.use(vite.middlewares);
    } else {
      // Production static serving
      const distPath = path.join(process.cwd(), "dist");
      console.log(`Serving static files from: ${distPath}`);
      
      if (fs.existsSync(distPath)) {
        app.use(express.static(distPath));
        
        // SPA fallback
        app.get("*", (req, res) => {
          const indexPath = path.join(distPath, "index.html");
          if (fs.existsSync(indexPath)) {
            res.sendFile(indexPath);
          } else {
            res.status(404).send("Production build not found (index.html missing)");
          }
        });
      } else {
        app.get("*", (req, res) => {
          res.status(500).send("Production build not found (dist folder missing)");
        });
      }
    }

    app.listen(PORT, "0.0.0.0", () => {
      console.log(`Server running on http://0.0.0.0:${PORT} (env: ${process.env.NODE_ENV || 'development'})`);
    });
  } catch (err) {
    console.error("Critical error during server startup:", err);
    process.exit(1);
  }
}

startServer().catch(err => {
  console.error("Async error in startServer:", err);
  process.exit(1);
});

sed -i 's|opacity-0 group-hover:opacity-100|md:opacity-0 md:group-hover:opacity-100 opacity-100|g' src/App.tsx
